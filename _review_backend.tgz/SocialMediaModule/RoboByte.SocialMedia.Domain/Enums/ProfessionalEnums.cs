namespace RoboByte.SocialMedia.Domain.Enums
{
    public enum ConnectionStatusEnum { Pending = 0, Accepted = 1 }

    public enum EmploymentTypeEnum
    {
        FullTime = 0, PartTime = 1, Contract = 2, Internship = 3,
        Freelance = 4, SelfEmployed = 5, Temporary = 6
    }

    public enum WorkplaceTypeEnum { OnSite = 0, Remote = 1, Hybrid = 2 }

    public enum JobApplicationStatusEnum
    {
        Submitted = 0, Reviewed = 1, Shortlisted = 2, Interviewing = 3, Rejected = 4, Accepted = 5
    }
}
