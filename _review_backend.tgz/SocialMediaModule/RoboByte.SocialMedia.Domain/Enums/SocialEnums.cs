namespace RoboByte.SocialMedia.Domain.Enums
{
    public enum ViewContextEnum
    {
        Story,
        Post,
        Reel
    }
    public enum FollowStatusEnum { Pending = 0, Accepted = 1 }
    /// <summary>What kind of account a profile is — chosen at sign-up.
    /// Distinct from Auth's <c>UserTypeEnum</c> (SystemAdmin/Admin/User), which is a permission
    /// role: this is what the account IS, and Auth's contact record has no field for it.</summary>
    public enum AccountTypeEnum { Individual = 0, Company = 1 }

    public enum PostVisibilityEnum { Public = 0, Followers = 1, Private = 2 }
    public enum MediaKindEnum { Image = 0, Video = 1 }
    public enum MentionSourceTypeEnum { Post = 0, Comment = 1 }
    public enum ConversationTypeEnum { Direct = 0, Group = 1 }

    public enum NotificationTypeEnum
    {
        Follow = 0, FollowRequest = 1, FollowAccepted = 2,
        Like = 3, Comment = 4, Mention = 5, Message = 6, Reply = 7,
        ConnectionRequest = 8, ConnectionAccepted = 9, JobApplication = 10, Share = 11,
        IncomingCall = 12, MissedCall = 13
    }

    public enum CallTypeEnum { Audio = 0, Video = 1 }

    /// <summary>
    /// Lifecycle of a call as a whole. <c>Missed</c> is set by the ring-timeout sweep, not by a
    /// client, so a caller who simply disappears still resolves the call.
    /// </summary>
    public enum CallStatusEnum
    {
        Ringing = 0,
        /// <summary>At least one invitee answered and media is (or was) flowing.</summary>
        Active = 1,
        /// <summary>Answered, then finished normally.</summary>
        Ended = 2,
        /// <summary>Every invitee declined.</summary>
        Declined = 3,
        /// <summary>Nobody answered before the ring timeout.</summary>
        Missed = 4,
        /// <summary>The initiator hung up before anyone answered.</summary>
        Cancelled = 5
    }

    public enum CallParticipantStatusEnum
    {
        Invited = 0, Joined = 1, Declined = 2, Left = 3, Missed = 4
    }

    public enum PostOrderByEnum { Newest = 0, MostLiked = 1, MostCommented = 2, MostViewed = 3 }
    public enum ReelOrderByEnum { Newest = 0, MostLiked = 1, MostPlayed = 2, MostViewed = 3 }
    public enum ProfileOrderByEnum { Newest = 0, MostFollowers = 1, Username = 2 }
    public enum CommentOrderByEnum { Newest = 0, Oldest = 1, MostLiked = 2 }
    public enum StoryOrderByEnum { Newest = 0, Oldest = 1 }
    public enum JobOrderByEnum { Newest = 0, MostApplied = 1 }
    public enum MessageOrderByEnum { Newest = 0, Oldest = 1 }

    #region Moderation

    public enum ReportTargetTypeEnum { Post = 0, Reel = 1, Comment = 2, Message = 3, Story = 4, Profile = 5 }

    public enum ReportReasonEnum
    {
        Spam = 0, Harassment = 1, HateSpeech = 2, Violence = 3, NudityOrSexual = 4,
        Misinformation = 5, SelfHarm = 6, Impersonation = 7, IntellectualProperty = 8, Other = 9
    }

    public enum ReportStatusEnum
    {
        Pending = 0,
        UnderReview = 1,
        /// <summary>Upheld — the content was actioned.</summary>
        ActionTaken = 2,
        /// <summary>Reviewed and found not to break the rules.</summary>
        Dismissed = 3,
        /// <summary>The target was already gone by the time anyone looked.</summary>
        TargetMissing = 4
    }

    public enum ModerationActionTypeEnum { TakeDown = 0, Restore = 1, Dismiss = 2 }

    #endregion

    /// <summary>Whether a "not interested" hides one item or everything from that author.</summary>
    public enum FeedHideScopeEnum { Item = 0, Author = 1 }

    /// <summary>What an <c>OutboxEventModel</c> row represents — which Postgres aggregate to re-load and fan out.</summary>
    public enum OutboxEventTypeEnum { PostPublished = 0, ReelPublished = 1 }


    public enum AdContextEnum
    {
        Post,
        Ad,
        Reel, 
        Job
    }
    public enum BoostStatusEnum
    {
        Pending,
        Active, 
        Completed,
        Paused
    }
}
