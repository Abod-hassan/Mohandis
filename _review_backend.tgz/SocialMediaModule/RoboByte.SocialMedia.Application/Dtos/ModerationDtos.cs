using RoboByte.SocialMedia.Domain.Enums;

namespace RoboByte.SocialMedia.Application.Dtos
{
    public class CreateReportDto
    {
        public ReportTargetTypeEnum TargetType { get; set; }

        /// <summary>PostId / ReelId / CommentId / MessageId / StoryId / ProfileId, per <see cref="TargetType"/>.</summary>
        public Guid TargetId { get; set; }

        public ReportReasonEnum Reason { get; set; }
        public string? Details { get; set; }
    }

    public class ContentReportDto
    {
        public Guid Id { get; set; }
        public Guid ReporterProfileId { get; set; }
        public ReportTargetTypeEnum TargetType { get; set; }
        public Guid TargetId { get; set; }
        public Guid? TargetAuthorProfileId { get; set; }
        public ReportReasonEnum Reason { get; set; }
        public string? Details { get; set; }
        public ReportStatusEnum Status { get; set; }
        public Guid? ResolvedByProfileId { get; set; }
        public DateTimeOffset? ResolvedAt { get; set; }
        public string? ResolutionNote { get; set; }
        public DateTime ReportedAt { get; set; }
    }

    public class ReportFilter
    {
        public ReportStatusEnum? Status { get; set; }
        public ReportTargetTypeEnum? TargetType { get; set; }
        public Guid? TargetId { get; set; }

        /// <summary>Everything reported against one author — the "is this a repeat offender" view.</summary>
        public Guid? TargetAuthorProfileId { get; set; }
    }

    public class ModerationActionDto
    {
        public ReportTargetTypeEnum TargetType { get; set; }
        public Guid TargetId { get; set; }
        public string? Reason { get; set; }
    }
}
