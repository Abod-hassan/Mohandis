namespace RoboByte.SocialMedia.Application.Dtos
{
    /// <summary>Request for one home-feed page. Omit <see cref="Bucket"/>/<see cref="BeforeEventTime"/>
    /// for the first page (most recent); echo back <see cref="FeedPageDto.Bucket"/>/
    /// <see cref="FeedPageDto.NextBeforeEventTime"/> to fetch the next one.</summary>
    public class FeedPageRequest
    {
        public string? Bucket { get; set; }
        public string? BeforeEventTime { get; set; }
        public int PageSize { get; set; } = 10;

        /// <summary>How far into the recommendation pool this page starts. Recommendations come
        /// from Postgres, not the fan-out store, so they need their own cursor — without it every
        /// page re-serves the same top-ranked posts. Echo back
        /// <see cref="FeedPageDto.NextRecommendationOffset"/>.</summary>
        public int RecommendationOffset { get; set; }
    }

    public class FeedMediaItemDto
    {
        public string Url { get; set; } = string.Empty;
        public string? ThumbnailUrl { get; set; }
        public sbyte Kind { get; set; }
        public int Position { get; set; }
        public int? Width { get; set; }
        public int? Height { get; set; }
        public double? DurationSeconds { get; set; }
    }

    /// <summary>Where a feed row came from — informational for the client, doesn't change rendering rules.</summary>
    public static class FeedItemSource
    {
        public const string FanoutWrite = "FanoutWrite";
        public const string FanoutRead = "FanoutRead";
        public const string Ad = "Ad";
        public const string Recommendation = "Recommendation";
    }

    public class FeedItemDto
    {
        public string Source { get; set; } = FeedItemSource.FanoutWrite;

        /// <summary>0=post, 1=repost, 2=reel, 3=job, 4=ad.</summary>
        public sbyte ItemType { get; set; }
        public Guid ItemId { get; set; }
        public Guid AuthorId { get; set; }
        public string? AuthorName { get; set; }
        public string? AuthorAvatar { get; set; }
        public string? Content { get; set; }
        public List<FeedMediaItemDto> Media { get; set; } = new();
        public Guid? SharedPostId { get; set; }
        public sbyte Visibility { get; set; }

        /// <summary>Set only when <see cref="Source"/> is <see cref="FeedItemSource.Ad"/>.</summary>
        public int? BoostId { get; set; }
        public string? DestinationUrl { get; set; }

        /// <summary>Set only for job items/job ads.</summary>
        public string? Title { get; set; }
        public string? CompanyName { get; set; }

        // Engagement counters and viewer-relative flags. Deliberately NOT stored in the feed
        // store (CQL note 2) — they'd go stale the moment anyone likes the post and would mean
        // rewriting every fanned-out copy. Filled per page by one batched Postgres read.
        public int LikeCount { get; set; }
        public int CommentCount { get; set; }
        public int ViewCount { get; set; }
        public int ShareCount { get; set; }
        public int PlayCount { get; set; }
        public int SaveCount { get; set; }
        public bool IsLiked { get; set; }
        public bool IsSaved { get; set; }

        // ---- Ranking inputs. Server-side only; harmless to expose but not meant for display. ----

        /// <summary>When the underlying post/reel was created — the recency signal.</summary>
        public DateTimeOffset? CreatedAt { get; set; }

        /// <summary>Affinity stamped onto the fanned-out row at publish time (0 for other sources).</summary>
        public int RankPriority { get; set; }

        /// <summary>Whether this viewer already explicitly viewed the item.</summary>
        public bool Seen { get; set; }
    }

    public class FeedPageDto
    {
        public List<FeedItemDto> Items { get; set; } = new();
        public string Bucket { get; set; } = string.Empty;
        public string? NextBeforeEventTime { get; set; }

        /// <summary>Pass back as <see cref="FeedPageRequest.RecommendationOffset"/> on the next page.</summary>
        public int NextRecommendationOffset { get; set; }

        public bool HasMore { get; set; }
    }
}
