using RoboByte.SocialMedia.Domain.Enums;

namespace RoboByte.SocialMedia.Application.Dtos
{
    public class StartCallDto
    {
        /// <summary>Who to ring. The initiator is added automatically and must not be listed.</summary>
        public List<Guid> ParticipantProfileIds { get; set; } = new();

        public CallTypeEnum Type { get; set; } = CallTypeEnum.Audio;

        /// <summary>Optional — threads the call into an existing conversation's history.</summary>
        public Guid? ConversationId { get; set; }
    }

    /// <summary>
    /// Everything a client needs to join the media channel. The token is scoped to this channel and
    /// this participant's uid, and expires — call the token endpoint again to refresh mid-call.
    /// </summary>
    public class CallCredentialsDto
    {
        public string AppId { get; set; } = string.Empty;
        public string ChannelName { get; set; } = string.Empty;
        public int AgoraUid { get; set; }
        public string Token { get; set; } = string.Empty;
        public int ExpiresInSeconds { get; set; }
    }

    public class CallParticipantDto
    {
        public Guid ProfileId { get; set; }
        public string DisplayName { get; set; } = string.Empty;
        public string? AvatarUrl { get; set; }
        public CallParticipantStatusEnum Status { get; set; }
        public int AgoraUid { get; set; }
        public DateTimeOffset? JoinedAt { get; set; }
        public DateTimeOffset? LeftAt { get; set; }
    }

    public class CallDto
    {
        public Guid Id { get; set; }
        public Guid InitiatorProfileId { get; set; }
        public Guid? ConversationId { get; set; }
        public CallTypeEnum Type { get; set; }
        public CallStatusEnum Status { get; set; }
        public DateTimeOffset StartedAt { get; set; }
        public DateTimeOffset? AnsweredAt { get; set; }
        public DateTimeOffset? EndedAt { get; set; }
        public int? DurationSeconds { get; set; }
        public List<CallParticipantDto> Participants { get; set; } = new();

        /// <summary>Populated only on start/answer/token — never on history reads.</summary>
        public CallCredentialsDto? Credentials { get; set; }
    }

    public class CallFilter
    {
        /// <summary>Always the caller; history is scoped to calls they took part in.</summary>
        public Guid? ViewerProfileId { get; set; }
        public Guid? Id { get; set; }
        public CallStatusEnum? Status { get; set; }
        public bool? MissedOnly { get; set; }
    }
}
