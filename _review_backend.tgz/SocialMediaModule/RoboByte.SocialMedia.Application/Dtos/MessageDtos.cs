using RoboByte.SocialMedia.Domain.Enums;

namespace RoboByte.SocialMedia.Application.Dtos
{
    public class ConversationDto
    {
        public Guid Id { get; set; }
        public ConversationTypeEnum Type { get; set; }
        public string? Title { get; set; }
        public List<ProfileSimplifiedDto> Participants { get; set; } = new();
        public string? LastMessagePreview { get; set; }
        public DateTime? LastMessageAt { get; set; }
        public int UnreadCount { get; set; }

        /// <summary>Whether the *caller* has muted this thread.</summary>
        public bool IsMuted { get; set; }

        /// <summary>Whether the caller may rename the thread or change its membership.</summary>
        public bool IsAdmin { get; set; }
    }

    public class MessageAttachmentDto
    {
        public string Url { get; set; } = string.Empty;
        public string? ThumbnailUrl { get; set; }
        public MediaKindEnum Kind { get; set; }
        public int Position { get; set; }
        public int? Width { get; set; }
        public int? Height { get; set; }
        public double? DurationSeconds { get; set; }
    }

    /// <summary>One emoji and who used it, aggregated for display.</summary>
    public class MessageReactionDto
    {
        public string Emoji { get; set; } = string.Empty;
        public int Count { get; set; }
        public List<Guid> ProfileIds { get; set; } = new();

        /// <summary>True when the caller is one of them.</summary>
        public bool ReactedByMe { get; set; }
    }

    public class MessageDto
    {
        public Guid Id { get; set; }
        public Guid ConversationId { get; set; }
        public Guid SenderId { get; set; }
        public string? SenderName { get; set; }
        public string? SenderAvatarUrl { get; set; }
        public string? Content { get; set; }
        public DateTime SentAt { get; set; }

        public List<MessageAttachmentDto> Attachments { get; set; } = new();
        public List<MessageReactionDto> Reactions { get; set; } = new();

        public Guid? ReplyToMessageId { get; set; }
        /// <summary>Short preview of the quoted message, so a reply renders without a second fetch.</summary>
        public string? ReplyToPreview { get; set; }
        public Guid? ReplyToSenderId { get; set; }

        public DateTimeOffset? EditedAt { get; set; }

        /// <summary>Unsent by its sender — render a tombstone; Content and Attachments are cleared.</summary>
        public bool IsRetracted { get; set; }

        /// <summary>
        /// Participants (other than the sender) whose read position is at or past this message.
        /// Derived from ConversationParticipant.LastReadAt rather than stored per message.
        /// </summary>
        public List<Guid> ReadByProfileIds { get; set; } = new();

        /// <summary>True when every other participant has read it — the sender's double tick.</summary>
        public bool IsReadByAll { get; set; }
    }

    public class SendMessageDto
    {
        public string? Content { get; set; }
        public List<MessageAttachmentDto>? Attachments { get; set; }
        public Guid? ReplyToMessageId { get; set; }
    }

    public class EditMessageDto
    {
        public string Content { get; set; } = string.Empty;
    }

    public class ReactToMessageDto
    {
        /// <summary>The emoji to apply. Send null or empty to remove your reaction.</summary>
        public string? Emoji { get; set; }
    }

    public class UpdateConversationDto
    {
        public string? Title { get; set; }
    }

    public class ConversationParticipantsDto
    {
        public List<Guid> ProfileIds { get; set; } = new();
    }
}
