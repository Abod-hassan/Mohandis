using RoboByte.SocialMedia.Domain.Enums;

namespace RoboByte.SocialMedia.Application.Dtos
{
    public class ExperienceDto
    {
        public int Id { get; set; }
        public Guid ProfileId { get; set; }
        public string Title { get; set; } = string.Empty;
        public string CompanyName { get; set; } = string.Empty;
        public EmploymentTypeEnum? EmploymentType { get; set; }
        public string? Location { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public bool IsCurrent { get; set; }
        public string? Description { get; set; }
    }

    public class EducationDto
    {
        public int Id { get; set; }
        public Guid ProfileId { get; set; }
        public string School { get; set; } = string.Empty;
        public string? Degree { get; set; }
        public string? FieldOfStudy { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string? Description { get; set; }
    }

    public class SkillDto
    {
        public int Id { get; set; }
        public Guid ProfileId { get; set; }
        public string Name { get; set; } = string.Empty;
        public int EndorsementCount { get; set; }
        public bool IsEndorsedByMe { get; set; }
    }

    public class ConnectionStateDto
    {
        public bool Connected { get; set; }
        public bool Incoming { get; set; }
        public bool Outgoing { get; set; }
        public int ConnectionCount { get; set; }
    }
}
