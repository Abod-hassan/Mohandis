namespace RoboByte.SocialMedia.Application.Dtos.Filters
{
    public class ExperienceFilter { public Guid ProfileId { get; set; } }

    public class EducationFilter { public Guid ProfileId { get; set; } }

    public class SkillFilter
    {
        public Guid ProfileId { get; set; }
        public Guid? ViewerProfileId { get; set; }
    }

    public class ConnectionFilter
    {
        public Guid ProfileId { get; set; }
        /// <summary>When true, returns pending incoming requests for ProfileId (owner only).</summary>
        public bool Pending { get; set; }
        public string? Search { get; set; }
    }
}
