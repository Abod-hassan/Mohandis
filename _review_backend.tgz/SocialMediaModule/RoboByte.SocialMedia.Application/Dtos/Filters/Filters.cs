using RoboByte.SocialMedia.Domain.Enums;

namespace RoboByte.SocialMedia.Application.Dtos.Filters
{
    /// <summary>Every filter's <c>ViewerProfileId</c> is the caller (set by the controller from
    /// the resolved current profile); other id fields are the subject being queried.</summary>
    public class ProfileFilter
    {
        public Guid? ViewerProfileId { get; set; }
        public Guid? Id { get; set; }
        public string? Username { get; set; }
        public string? Search { get; set; }
        public ProfileOrderByEnum OrderBy { get; set; } = ProfileOrderByEnum.Newest;
        public bool? Descending { get; set; } = true;
    }

    public class PostFilter
    {
        public Guid? ViewerProfileId { get; set; }
        public Guid? Id { get; set; }
        public List<Guid>? AuthorIds { get; set; }
        public bool? FollowedOnly { get; set; }
        public bool? OnlyLiked { get; set; }
        public string? Hashtag { get; set; }
        public string? Search { get; set; }
        public PostOrderByEnum OrderBy { get; set; } = PostOrderByEnum.Newest;
        public bool? Descending { get; set; } = true;
    }

    public class ReelFilter
    {
        public Guid? ViewerProfileId { get; set; }
        public Guid? Id { get; set; }
        public List<Guid>? AuthorIds { get; set; }
        public bool? FollowedOnly { get; set; }
        public bool? OnlyLiked { get; set; }
        public bool? OnlySaved { get; set; }
        public string? Search { get; set; }
        public ReelOrderByEnum OrderBy { get; set; } = ReelOrderByEnum.Newest;
        public bool? Descending { get; set; } = true;
    }

    public class CommentFilter
    {
        public Guid? ViewerProfileId { get; set; }
        public Guid? Id { get; set; }
        public Guid? PostId { get; set; }
        public Guid? ParentCommentId { get; set; }
        public bool? TopLevelOnly { get; set; }
        public CommentOrderByEnum OrderBy { get; set; } = CommentOrderByEnum.Newest;
        public bool? Descending { get; set; } = true;
    }

    public class StoryFilter
    {
        public Guid? ViewerProfileId { get; set; }
        public Guid? Id { get; set; }
        public List<Guid>? AuthorIds { get; set; }
        public bool? ActiveOnly { get; set; } = true;
        public bool? FollowedOnly { get; set; }
        public StoryOrderByEnum OrderBy { get; set; } = StoryOrderByEnum.Newest;
        public bool? Descending { get; set; } = true;
    }

    public class FollowListFilter
    {
        public Guid? ViewerProfileId { get; set; }
        public Guid ProfileId { get; set; }
        public bool Followers { get; set; } = true;
        public bool Pending { get; set; }
        public string? Search { get; set; }
    }

    public class JobFilter
    {
        public Guid? ViewerProfileId { get; set; }
        public Guid? Id { get; set; }
        public string? Search { get; set; }
        public string? Location { get; set; }
        public EmploymentTypeEnum? EmploymentType { get; set; }
        public WorkplaceTypeEnum? WorkplaceType { get; set; }
        public Guid? PostedById { get; set; }
        public bool? OpenOnly { get; set; } = true;
        public JobOrderByEnum OrderBy { get; set; } = JobOrderByEnum.Newest;
        public bool? Descending { get; set; } = true;
    }

    public class JobApplicationFilter
    {
        public Guid? JobId { get; set; }
        public Guid? ApplicantId { get; set; }
    }

    public class NotificationFilter
    {
        public Guid? ViewerProfileId { get; set; }
        public bool? UnreadOnly { get; set; }
        public bool? Descending { get; set; } = true;
    }

    public class ConversationFilter
    {
        public Guid? ViewerProfileId { get; set; }
        public Guid? Id { get; set; }
    }

    public class MessageFilter
    {
        public Guid? ViewerProfileId { get; set; }
        public Guid ConversationId { get; set; }
        public MessageOrderByEnum OrderBy { get; set; } = MessageOrderByEnum.Newest;
        public bool? Descending { get; set; } = true;
    }
}
