using RoboByte.SocialMedia.Domain.Enums;

namespace RoboByte.SocialMedia.Application.Dtos
{
    public class ProfileSimplifiedDto
    {
        /// <summary>The ProfileId — the module's user key everywhere.</summary>
        public Guid Id { get; set; }
        public string Username { get; set; } = string.Empty;
        public string DisplayName { get; set; } = string.Empty;
        public string? Headline { get; set; }
        public string? AvatarUrl { get; set; }
        public bool IsVerified { get; set; }

        /// <summary>Live — true while the profile holds an open realtime connection.</summary>
        public bool IsOnline { get; set; }

        /// <summary>When they were last connected. Null if never, or omitted while they're online.</summary>
        public DateTimeOffset? LastSeenAt { get; set; }
    }

    public class ProfileDto
    {
        /// <summary>The ProfileId — the module's user key everywhere.</summary>
        public Guid Id { get; set; }
        public string Username { get; set; } = string.Empty;
        public string DisplayName { get; set; } = string.Empty;
        public string? Bio { get; set; }
        public string? AvatarUrl { get; set; }
        public string? CoverUrl { get; set; }
        public string? Website { get; set; }
        public string? Location { get; set; }

        // Professional (LinkedIn-style)
        public string? Headline { get; set; }
        public string? Industry { get; set; }
        public string? About { get; set; }
        public string? CvUrl { get; set; }
        public bool IsOpenToWork { get; set; }
        public bool IsHiring { get; set; }

        /// <summary>Individual or company — see <see cref="AccountTypeEnum"/>.</summary>
        public AccountTypeEnum AccountType { get; set; }

        public bool IsPrivate { get; set; }
        public bool IsVerified { get; set; }

        /// <summary>Live — true while the profile holds an open realtime connection.</summary>
        public bool IsOnline { get; set; }
        public DateTimeOffset? LastSeenAt { get; set; }
        public int FollowerCount { get; set; }
        public int FollowingCount { get; set; }
        public int ConnectionCount { get; set; }
        public int PostCount { get; set; }

        public bool IsMe { get; set; }
        public bool IsFollowing { get; set; }
        public bool IsFollowedBy { get; set; }
        public bool FollowRequestPending { get; set; }
        public bool IsConnected { get; set; }
        public bool ConnectionIncoming { get; set; }
        public bool ConnectionOutgoing { get; set; }
    }
}
