namespace RoboByte.SocialMedia.Application.Dtos
{
    public class ReelDto
    {
        public Guid Id { get; set; }
        public Guid AuthorId { get; set; }
        public string? AuthorName { get; set; }
        public string? AuthorUsername { get; set; }
        public string? AuthorAvatarUrl { get; set; }
        public bool AuthorIsVerified { get; set; }

        public string VideoUrl { get; set; } = string.Empty;
        public string? ThumbnailUrl { get; set; }
        public string? Caption { get; set; }
        public double? DurationSeconds { get; set; }

        public int LikeCount { get; set; }
        public int ViewCount { get; set; }
        public int PlayCount { get; set; }
        public int SaveCount { get; set; }
        public bool IsLiked { get; set; }
        public bool IsSaved { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
