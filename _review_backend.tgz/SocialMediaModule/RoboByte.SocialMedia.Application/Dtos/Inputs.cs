using RoboByte.SocialMedia.Domain.Enums;

namespace RoboByte.SocialMedia.Application.Dtos
{
    public class PostMediaInput
    {
        public string Url { get; set; } = string.Empty;
        public MediaKindEnum Kind { get; set; }
        public string? ThumbnailUrl { get; set; }
        public int Position { get; set; }
        public int? Width { get; set; }
        public int? Height { get; set; }
        public double? DurationSeconds { get; set; }
    }

    public class PublishPostDto
    {
        public string? Content { get; set; }
        public PostVisibilityEnum Visibility { get; set; } = PostVisibilityEnum.Public;
        public List<PostMediaInput>? Media { get; set; }
    }

    public class SharePostDto
    {
        public Guid SharedPostId { get; set; }
        public string? Content { get; set; }
        public PostVisibilityEnum Visibility { get; set; } = PostVisibilityEnum.Public;
    }

    public class PublishReelDto
    {
        public string VideoUrl { get; set; } = string.Empty;
        public string? ThumbnailUrl { get; set; }
        public string? Caption { get; set; }
        public double? DurationSeconds { get; set; }
    }

    public class AddCommentDto
    {
        public string Content { get; set; } = string.Empty;
        public Guid? ParentCommentId { get; set; }
    }

    public class PublishStoryDto
    {
        public string MediaUrl { get; set; } = string.Empty;
        public MediaKindEnum Kind { get; set; }
        public string? Caption { get; set; }
    }

    public class StartConversationDto
    {
        public List<Guid> ParticipantIds { get; set; } = new();
        public string? Title { get; set; }
    }

    public class ApplyJobDto
    {
        public string? CoverLetter { get; set; }
        public string? ResumeUrl { get; set; }
    }
}
