using RoboByte.SocialMedia.Domain.Enums;

namespace RoboByte.SocialMedia.Application.Dtos
{
    public class NotificationDto
    {
        public Guid Id { get; set; }
        public NotificationTypeEnum Type { get; set; }
        public Guid? ActorId { get; set; }
        public string? ActorName { get; set; }
        public string? ActorAvatarUrl { get; set; }
        public Guid? PostId { get; set; }
        public Guid? CommentId { get; set; }
        public string? Text { get; set; }
        public bool IsRead { get; set; }
        public DateTime CreatedAt { get; set; }
    }

    public class HashtagDto
    {
        public string Tag { get; set; } = string.Empty;
        public int PostCount { get; set; }
    }

    public class FollowStateDto
    {
        public bool IsFollowing { get; set; }
        public bool Pending { get; set; }
        public int FollowerCount { get; set; }
    }

    /// <summary>Which slice of search results to page through.</summary>
    public enum SearchScopeEnum { Profiles = 0, Posts = 1, Reels = 2, Hashtags = 3, Jobs = 4 }

    /// <summary>The blended landing page — a few of each kind.</summary>
    public class SearchResultDto
    {
        public List<ProfileSimplifiedDto> Profiles { get; set; } = new();
        public List<HashtagDto> Hashtags { get; set; } = new();
        public List<PostSimplifiedDto> Posts { get; set; } = new();
        public List<ReelDto> Reels { get; set; } = new();
        public List<JobDto> Jobs { get; set; } = new();
    }

    /// <summary>One scope, paged. Only the list matching <see cref="Scope"/> is populated.</summary>
    public class SearchPageDto
    {
        public SearchScopeEnum Scope { get; set; }
        public int Page { get; set; }
        public int Size { get; set; }
        public int Total { get; set; }
        public bool HasMore { get; set; }

        public List<ProfileSimplifiedDto> Profiles { get; set; } = new();
        public List<HashtagDto> Hashtags { get; set; } = new();
        public List<PostSimplifiedDto> Posts { get; set; } = new();
        public List<ReelDto> Reels { get; set; } = new();
        public List<JobDto> Jobs { get; set; } = new();
    }
}
