using RoboByte.SocialMedia.Domain.Enums;

namespace RoboByte.SocialMedia.Application.Dtos
{
    public class PostMediaDto
    {
        public int Id { get; set; }
        public MediaKindEnum Kind { get; set; }
        public string Url { get; set; } = string.Empty;
        public string? ThumbnailUrl { get; set; }
        public int Position { get; set; }
        public int? Width { get; set; }
        public int? Height { get; set; }
        public double? DurationSeconds { get; set; }
    }

    public class PostSimplifiedDto
    {
        public Guid Id { get; set; }
        public Guid AuthorId { get; set; }
        public string? AuthorName { get; set; }
        public string? AuthorAvatarUrl { get; set; }
        public string? Content { get; set; }
        public string? FirstMediaUrl { get; set; }
        public int LikeCount { get; set; }
        public int CommentCount { get; set; }
        public bool IsLiked { get; set; }
        public DateTime CreatedAt { get; set; }
    }

    public class PostDto
    {
        public Guid Id { get; set; }
        public Guid AuthorId { get; set; }
        public string? AuthorName { get; set; }
        public string? AuthorUsername { get; set; }
        public string? AuthorAvatarUrl { get; set; }
        public bool AuthorIsVerified { get; set; }

        public string? Content { get; set; }
        public PostVisibilityEnum Visibility { get; set; }

        /// <summary>Set when this post is a repost/share; <see cref="SharedPost"/> is the original.</summary>
        public Guid? SharedPostId { get; set; }
        public PostSimplifiedDto? SharedPost { get; set; }

        public List<PostMediaDto> Media { get; set; } = new();
        public int LikeCount { get; set; }
        public int CommentCount { get; set; }
        public int ViewCount { get; set; }
        public int ShareCount { get; set; }
        public bool IsLiked { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
