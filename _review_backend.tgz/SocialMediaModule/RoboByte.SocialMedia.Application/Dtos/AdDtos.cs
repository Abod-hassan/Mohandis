using RoboByte.SocialMedia.Domain.Enums;

namespace RoboByte.SocialMedia.Application.Dtos
{
    /// <summary>Create a paid boost for content the caller owns.</summary>
    public class CreateBoostDto
    {
        public AdContextEnum Context { get; set; }

        /// <summary>PostId / ReelId / JobId / AdId, per <see cref="Context"/>.</summary>
        public Guid ContextId { get; set; }

        public decimal Budget { get; set; }
        public decimal CostPerImpression { get; set; }
        public decimal CostPerClick { get; set; }

        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        public int TargetReach { get; set; }
        public string? TargetGeoLocation { get; set; }
        public int? FrequencyCapPerProfile { get; set; }
    }

    /// <summary>A boost as its advertiser sees it — configuration plus live delivery numbers.</summary>
    public class BoostDto
    {
        public int Id { get; set; }
        public AdContextEnum Context { get; set; }
        public Guid ContextId { get; set; }
        public Guid AdvertiserProfileId { get; set; }
        public BoostStatusEnum Status { get; set; }

        public decimal Budget { get; set; }
        public decimal SpentAmount { get; set; }
        public decimal RemainingBudget { get; set; }
        public decimal CostPerImpression { get; set; }
        public decimal CostPerClick { get; set; }

        public int TargetReach { get; set; }
        public string? TargetGeoLocation { get; set; }
        public int? FrequencyCapPerProfile { get; set; }

        /// <summary>Total impressions delivered, including repeats to the same profile.</summary>
        public int Impressions { get; set; }

        /// <summary>Unique profiles reached.</summary>
        public int Reach { get; set; }

        public int Clicks { get; set; }

        /// <summary>Clicks ÷ impressions, 0 when nothing has been delivered yet.</summary>
        public double ClickThroughRate { get; set; }

        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public DateTimeOffset? InvoicedAt { get; set; }
        public DateTime CreatedAt { get; set; }
    }

    public class BoostFilter
    {
        /// <summary>Always the caller — a boost is only ever listed to the profile paying for it.</summary>
        public Guid? ViewerProfileId { get; set; }
        public int? Id { get; set; }
        public BoostStatusEnum? Status { get; set; }
    }
}
