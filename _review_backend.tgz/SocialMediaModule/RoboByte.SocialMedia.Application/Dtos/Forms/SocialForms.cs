using RoboByte.Kernel.ViewModels.Generics;
using RoboByte.SocialMedia.Domain.Enums;

namespace RoboByte.SocialMedia.Application.Dtos.Forms
{
    public class PostForm : GenericForm<Guid>
    {
        public Guid AuthorId { get; set; }
        public string? Content { get; set; }
        public PostVisibilityEnum Visibility { get; set; } = PostVisibilityEnum.Public;
        public Guid? SharedPostId { get; set; }
    }

    public class ReelForm : GenericForm<Guid>
    {
        public Guid AuthorId { get; set; }
        public string VideoUrl { get; set; } = string.Empty;
        public string? ThumbnailUrl { get; set; }
        public string? Caption { get; set; }
        public double? DurationSeconds { get; set; }
    }

    public class CommentForm : GenericForm<Guid>
    {
        public Guid PostId { get; set; }
        public Guid AuthorId { get; set; }
        public Guid? ParentCommentId { get; set; }
        public string Content { get; set; } = string.Empty;
    }

    public class StoryForm : GenericForm<Guid>
    {
        public Guid AuthorId { get; set; }
        public MediaKindEnum Kind { get; set; }
        public string MediaUrl { get; set; } = string.Empty;
        public string? Caption { get; set; }
        public DateTime ExpiresAt { get; set; }
    }

    public class JobForm : GenericForm<Guid>
    {
        public Guid PostedById { get; set; }
        public string Title { get; set; } = string.Empty;
        public string CompanyName { get; set; } = string.Empty;
        public string? Location { get; set; }
        public EmploymentTypeEnum? EmploymentType { get; set; }
        public WorkplaceTypeEnum? WorkplaceType { get; set; }
        public string Description { get; set; } = string.Empty;
        public string? Requirements { get; set; }
        public decimal? SalaryMin { get; set; }
        public decimal? SalaryMax { get; set; }
        public string? Currency { get; set; }
        public bool IsOpen { get; set; } = true;
        public DateTime? ClosesAt { get; set; }
    }

    public class JobApplicationForm : GenericForm<Guid>
    {
        public Guid JobId { get; set; }
        public Guid ApplicantId { get; set; }
        public string? CoverLetter { get; set; }
        public string? ResumeUrl { get; set; }
    }
}
