using RoboByte.SocialMedia.Domain.Enums;

namespace RoboByte.SocialMedia.Application.Dtos
{
    public class JobDto
    {
        public Guid Id { get; set; }
        public Guid PostedById { get; set; }
        public string? PostedByName { get; set; }
        public string? PostedByAvatarUrl { get; set; }

        public string Title { get; set; } = string.Empty;
        public string CompanyName { get; set; } = string.Empty;
        public string? Location { get; set; }
        public EmploymentTypeEnum? EmploymentType { get; set; }
        public WorkplaceTypeEnum? WorkplaceType { get; set; }
        public string Description { get; set; } = string.Empty;
        public string? Requirements { get; set; }
        public decimal? SalaryMin { get; set; }
        public decimal? SalaryMax { get; set; }
        public string? Currency { get; set; }
        public bool IsOpen { get; set; }
        public int ApplicationCount { get; set; }
        public DateTime? ClosesAt { get; set; }
        public DateTime CreatedAt { get; set; }
        public bool HasApplied { get; set; }
    }

    public class JobApplicationDto
    {
        public Guid Id { get; set; }
        public Guid JobId { get; set; }
        public Guid ApplicantId { get; set; }
        public string? ApplicantName { get; set; }
        public string? ApplicantAvatarUrl { get; set; }
        public string? CoverLetter { get; set; }
        public string? ResumeUrl { get; set; }
        public JobApplicationStatusEnum Status { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
