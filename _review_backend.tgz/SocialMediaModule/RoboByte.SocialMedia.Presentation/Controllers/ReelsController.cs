using Microsoft.AspNetCore.Mvc;
using RoboByte.SocialMedia.Application.Dtos;
using RoboByte.SocialMedia.Application.Dtos.Filters;
using RoboByte.SocialMedia.Application.Services;
using RoboByte.SocialMedia.Application.Services.Profiles;

namespace RoboByte.SocialMedia.Presentation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReelsController(IReelService reels, ICurrentProfileAccessor currentProfile) : ControllerBase
    {
        /// <summary>One reels endpoint — single, by author, followed-only, liked-only,
        /// saved-only, search.</summary>
        [HttpPost]
        public async Task<IActionResult> Get([FromBody] ReelFilter filter, [FromQuery] int page = 1, [FromQuery] int size = 20)
        {
            filter.ViewerProfileId = await currentProfile.GetProfileIdAsync();
            var result = await reels.GetAsync(filter, page, size);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpGet("{id:guid}")]
        public async Task<IActionResult> GetById(Guid id)
        {
            var result = await reels.GetAsync(new ReelFilter { Id = id, ViewerProfileId = await currentProfile.GetProfileIdAsync() });
            if (result.Error) return BadRequest(result);
            var reel = result.Data?.FirstOrDefault();
            return reel == null ? NotFound(result) : Ok(result);
        }

        /// <summary>The current user's saved reels.</summary>
        [HttpGet("saved")]
        public async Task<IActionResult> Saved([FromQuery] int page = 1, [FromQuery] int size = 20)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await reels.GetAsync(new ReelFilter { OnlySaved = true, ViewerProfileId = profileId }, page, size);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpPost("Publish")]
        public async Task<IActionResult> Publish([FromBody] PublishReelDto dto)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await reels.Publish(profileId.Value, dto);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpPost("Like")]
        public async Task<IActionResult> Like([FromQuery] Guid reelId)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await reels.LikeReel(reelId, profileId.Value);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpPost("Save")]
        public async Task<IActionResult> Save([FromQuery] Guid reelId)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await reels.SaveReel(reelId, profileId.Value);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpPost("Play")]
        public async Task<IActionResult> Play([FromQuery] Guid reelId)
        {
            var result = await reels.PlayReel(reelId);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpDelete("{id:guid}")]
        public async Task<IActionResult> Delete(Guid id)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await reels.DeleteReel(id, profileId.Value);
            return result.Error ? BadRequest(result) : Ok(result);
        }
    }
}
