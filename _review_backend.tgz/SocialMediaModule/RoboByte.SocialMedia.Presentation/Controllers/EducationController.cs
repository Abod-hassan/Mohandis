using Microsoft.AspNetCore.Mvc;
using RoboByte.SocialMedia.Application.Dtos.Filters;
using RoboByte.SocialMedia.Application.Services;

namespace RoboByte.SocialMedia.Presentation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EducationController(IProfessionalService professional) : ControllerBase
    {
        /// <summary>A profile's education. Create/edit/delete via GenericWrite.</summary>
        [HttpPost]
        public async Task<IActionResult> Get([FromBody] EducationFilter filter, [FromQuery] int page = 1, [FromQuery] int size = 50)
        {
            var result = await professional.GetEducationsAsync(filter, page, size);
            return result.Error ? BadRequest(result) : Ok(result);
        }
    }
}
