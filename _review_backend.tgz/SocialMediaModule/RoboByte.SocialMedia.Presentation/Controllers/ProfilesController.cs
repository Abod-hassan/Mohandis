using Microsoft.AspNetCore.Mvc;
using RoboByte.SocialMedia.Application.Dtos;
using RoboByte.SocialMedia.Application.Dtos.Filters;
using RoboByte.SocialMedia.Application.Services;
using RoboByte.SocialMedia.Application.Services.Profiles;

namespace RoboByte.SocialMedia.Presentation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProfilesController(IProfileService profiles, ICurrentProfileAccessor currentProfile) : ControllerBase
    {
        /// <summary>One profiles endpoint — by id, username, or search. detailed=true
        /// returns the full <see cref="ProfileDto"/> (with relationship flags).</summary>
        [HttpPost]
        public async Task<IActionResult> Get([FromBody] ProfileFilter filter, [FromQuery] bool detailed = false, [FromQuery] int page = 1, [FromQuery] int size = 20)
        {
            filter.ViewerProfileId = await currentProfile.GetProfileIdAsync();
            if (detailed)
            {
                var result = await profiles.GetAsync<ProfileDto>(filter, page, size);
                return result.Error ? BadRequest(result) : Ok(result);
            }
            else
            {
                var result = await profiles.GetAsync<ProfileSimplifiedDto>(filter, page, size);
                return result.Error ? BadRequest(result) : Ok(result);
            }
        }

        /// <summary>The caller's own profile, resolved from the token. The module keys
        /// everything by ProfileId while the JWT carries a ContactId, so a client has no
        /// way to name itself — this is the only endpoint that can answer "who am I".
        /// Provisions the profile on first call, like every other ProfileId resolution.</summary>
        [HttpGet("Me")]
        public async Task<IActionResult> Me()
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) 
                return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await profiles.GetAsync<ProfileDto>(new ProfileFilter { Id = profileId, ViewerProfileId = profileId });
            if (result.Error) 
                return BadRequest(result);
            var profile = result.Data?.FirstOrDefault();
            return profile == null ? NotFound(result) : Ok(result);
        }

        [HttpGet("{id:guid}")]
        public async Task<IActionResult> GetById(Guid id)
        {
            var result = await profiles.GetAsync<ProfileDto>(new ProfileFilter { Id = id, ViewerProfileId = await currentProfile.GetProfileIdAsync() });
            if (result.Error) 
                return BadRequest(result);
            var profile = result.Data?.FirstOrDefault();
            return profile == null ? NotFound(result) : Ok(result);
        }

        [HttpGet("followers/{id:guid}")]
        public async Task<IActionResult> Followers(Guid id, [FromQuery] int page = 1, [FromQuery] int size = 20)
        {
            var result = await profiles.GetFollowListAsync(new FollowListFilter { ProfileId = id, Followers = true, ViewerProfileId = await currentProfile.GetProfileIdAsync() }, page, size);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpGet("following/{id:guid}")]
        public async Task<IActionResult> Following(Guid id, [FromQuery] int page = 1, [FromQuery] int size = 20)
        {
            var result = await profiles.GetFollowListAsync(new FollowListFilter { ProfileId = id, Followers = false, ViewerProfileId = await currentProfile.GetProfileIdAsync() }, page, size);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpGet("requests")]
        public async Task<IActionResult> Requests([FromQuery] int page = 1, [FromQuery] int size = 20)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await profiles.GetFollowListAsync(new FollowListFilter { ProfileId = profileId.Value, Pending = true, ViewerProfileId = profileId }, page, size);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpPost("Follow")]
        public async Task<IActionResult> Follow([FromQuery] Guid targetId) => await Act(c => profiles.Follow(c, targetId));
        [HttpPost("Unfollow")]
        public async Task<IActionResult> Unfollow([FromQuery] Guid targetId) => await Act(c => profiles.Unfollow(c, targetId));
        [HttpPost("AcceptRequest")]
        public async Task<IActionResult> AcceptRequest([FromQuery] Guid followerId) => await Act(c => profiles.AcceptRequest(c, followerId));
        [HttpPost("RejectRequest")]
        public async Task<IActionResult> RejectRequest([FromQuery] Guid followerId) => await Act(c => profiles.RejectRequest(c, followerId));
        [HttpPost("Block")]
        public async Task<IActionResult> Block([FromQuery] Guid targetId) => await Act(c => profiles.Block(c, targetId));
        [HttpPost("Unblock")]
        public async Task<IActionResult> Unblock([FromQuery] Guid targetId) => await Act(c => profiles.Unblock(c, targetId));

        private async Task<IActionResult> Act<T>(Func<Guid, Task<T>> action) where T : class
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            dynamic result = await action(profileId.Value);
            return result.Error ? BadRequest(result) : Ok(result);
        }
    }
}
