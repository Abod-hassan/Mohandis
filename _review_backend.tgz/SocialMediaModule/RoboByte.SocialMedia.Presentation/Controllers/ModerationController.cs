using Microsoft.AspNetCore.Mvc;
using RoboByte.SocialMedia.Application.Dtos;
using RoboByte.SocialMedia.Application.Services.Moderation;
using RoboByte.SocialMedia.Application.Services.Profiles;
using RoboByte.SocialMedia.Domain.Enums;

namespace RoboByte.SocialMedia.Presentation.Controllers
{
    /// <summary>
    /// Reporting content. Open to any authenticated caller — reporting is safe by construction, and
    /// acting on reports lives on <see cref="ModerationController"/>, which is gated.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class ReportsController(IModerationService moderation, ICurrentProfileAccessor currentProfile) : ControllerBase
    {
        /// <summary>Report a post, reel, comment, message, story or profile.</summary>
        [HttpPost]
        public async Task<IActionResult> Report([FromBody] CreateReportDto dto)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });

            var result = await moderation.ReportAsync(profileId.Value, dto);
            return result.Error ? BadRequest(result) : Ok(result);
        }
    }

    /// <summary>
    /// The moderator surface: queue, takedown, restore, dismiss.
    /// <para>
    /// <b>This module cannot tell a moderator from anyone else.</b> It has no roles and no
    /// <c>[Authorize]</c> of its own — authentication and authorization are entirely the host's
    /// pipeline. Every endpoint here therefore refuses to do anything unless
    /// <c>SocialMedia:Moderation:Enabled</c> is set, and turning that on is a statement that the host
    /// has applied an authorization policy to this route. Enable it without doing so and any
    /// authenticated caller can remove anyone's content.
    /// </para>
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class ModerationController(IModerationService moderation, ICurrentProfileAccessor currentProfile) : ControllerBase
    {
        /// <summary>The report queue, oldest first. Filter by status, target, or reported author.</summary>
        [HttpPost("queue")]
        public async Task<IActionResult> Queue([FromBody] ReportFilter filter, [FromQuery] int page = 1, [FromQuery] int size = 20)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });

            var result = await moderation.GetQueueAsync(filter, page, size);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        /// <summary>Soft-delete the target and resolve every open report about it.</summary>
        [HttpPost("takedown")]
        public async Task<IActionResult> TakeDown([FromBody] ModerationActionDto dto)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });

            var result = await moderation.TakeDownAsync(profileId.Value, dto.TargetType, dto.TargetId, dto.Reason);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        /// <summary>Reverse a takedown.</summary>
        [HttpPost("restore")]
        public async Task<IActionResult> Restore([FromBody] ModerationActionDto dto)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });

            var result = await moderation.RestoreAsync(profileId.Value, dto.TargetType, dto.TargetId, dto.Reason);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        /// <summary>Close a report without actioning the content.</summary>
        [HttpPost("reports/{reportId:guid}/dismiss")]
        public async Task<IActionResult> Dismiss(Guid reportId, [FromQuery] string? note = null)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });

            var result = await moderation.DismissAsync(profileId.Value, reportId, note);
            return result.Error ? BadRequest(result) : Ok(result);
        }
    }
}
