using Microsoft.AspNetCore.Mvc;
using RoboByte.SocialMedia.Application.Dtos;
using RoboByte.SocialMedia.Application.Dtos.Filters;
using RoboByte.SocialMedia.Application.Services;
using RoboByte.SocialMedia.Application.Services.Profiles;

namespace RoboByte.SocialMedia.Presentation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PostsController(IPostService posts, ICurrentProfileAccessor currentProfile) : ControllerBase
    {
        [HttpPost]
        public async Task<IActionResult> Get([FromBody] PostFilter filter, [FromQuery] bool detailed = true, [FromQuery] int page = 1, [FromQuery] int size = 20)
        {
            filter.ViewerProfileId = await currentProfile.GetProfileIdAsync();
            if (detailed)
            {
                var result = await posts.GetAsync<PostDto>(filter, page, size);
                return result.Error ? BadRequest(result) : Ok(result);
            }
            else
            {
                var result = await posts.GetAsync<PostSimplifiedDto>(filter, page, size);
                return result.Error ? BadRequest(result) : Ok(result);
            }
        }

        [HttpGet("{id:guid}")]
        public async Task<IActionResult> GetById(Guid id)
        {
            var result = await posts.GetAsync<PostDto>(new PostFilter { Id = id, ViewerProfileId = await currentProfile.GetProfileIdAsync() });
            if (result.Error) return BadRequest(result);
            var post = result.Data?.FirstOrDefault();
            return post == null ? NotFound(result) : Ok(result);
        }

        [HttpPost("Publish")]
        public async Task<IActionResult> Publish([FromBody] PublishPostDto dto)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await posts.Publish(profileId.Value, dto);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpPost("Share")]
        public async Task<IActionResult> Share([FromBody] SharePostDto dto)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await posts.Share(profileId.Value, dto);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpPost("Like")]
        public async Task<IActionResult> Like([FromQuery] Guid postId)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await posts.LikePost(postId, profileId.Value);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpPost("View")]
        public async Task<IActionResult> View([FromQuery] Guid postId)
        {
            // Viewer is optional — an anonymous view still counts, it just can't mark the
            // viewer's fanned-out feed copy as seen.
            var result = await posts.ViewPost(postId, await currentProfile.GetProfileIdAsync());
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpDelete("{id:guid}")]
        public async Task<IActionResult> Delete(Guid id)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await posts.DeletePost(id, profileId.Value);
            return result.Error ? BadRequest(result) : Ok(result);
        }
    }
}
