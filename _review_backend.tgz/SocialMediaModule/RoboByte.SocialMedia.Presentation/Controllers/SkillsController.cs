using Microsoft.AspNetCore.Mvc;
using RoboByte.SocialMedia.Application.Dtos.Filters;
using RoboByte.SocialMedia.Application.Services;
using RoboByte.SocialMedia.Application.Services.Profiles;

namespace RoboByte.SocialMedia.Presentation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SkillsController(IProfessionalService professional, ICurrentProfileAccessor currentProfile) : ControllerBase
    {
        /// <summary>A profile's skills (with endorsement counts + IsEndorsedByMe).
        /// Create/delete a skill via GenericWrite.</summary>
        [HttpPost]
        public async Task<IActionResult> Get([FromBody] SkillFilter filter, [FromQuery] int page = 1, [FromQuery] int size = 100)
        {
            filter.ViewerProfileId = await currentProfile.GetProfileIdAsync();
            var result = await professional.GetSkillsAsync(filter, page, size);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpPost("Endorse")]
        public async Task<IActionResult> Endorse([FromQuery] int skillId)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await professional.EndorseSkill(skillId, profileId.Value);
            return result.Error ? BadRequest(result) : Ok(result);
        }
    }
}
