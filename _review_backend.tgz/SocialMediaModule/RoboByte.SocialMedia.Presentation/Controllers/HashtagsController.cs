using Microsoft.AspNetCore.Mvc;
using RoboByte.SocialMedia.Application.Services;

namespace RoboByte.SocialMedia.Presentation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HashtagsController(IHashtagService hashtags) : ControllerBase
    {
        [HttpGet("trending")]
        public async Task<IActionResult> Trending([FromQuery] int take = 20)
        {
            var result = await hashtags.Trending(take);
            return result.Error ? BadRequest(result) : Ok(result);
        }
    }
}
