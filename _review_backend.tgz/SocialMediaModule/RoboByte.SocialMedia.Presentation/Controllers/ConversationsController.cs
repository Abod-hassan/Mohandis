using Microsoft.AspNetCore.Mvc;
using RoboByte.SocialMedia.Application.Dtos;
using RoboByte.SocialMedia.Application.Dtos.Filters;
using RoboByte.SocialMedia.Application.Services;
using RoboByte.SocialMedia.Application.Services.Profiles;

namespace RoboByte.SocialMedia.Presentation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ConversationsController(IMessageService messages, ICurrentProfileAccessor currentProfile) : ControllerBase
    {
        [HttpGet]
        public async Task<IActionResult> List([FromQuery] int page = 1, [FromQuery] int size = 20)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await messages.GetConversationsAsync(profileId.Value, page, size);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpPost("Start")]
        public async Task<IActionResult> Start([FromBody] StartConversationDto dto)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await messages.Start(profileId.Value, dto);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpGet("{id:guid}/messages")]
        public async Task<IActionResult> Messages(Guid id, [FromQuery] int page = 1, [FromQuery] int size = 30)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await messages.GetMessagesAsync(new MessageFilter { ConversationId = id, ViewerProfileId = profileId }, page, size);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpPost("{id:guid}/messages")]
        public async Task<IActionResult> Send(Guid id, [FromBody] SendMessageDto dto)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await messages.Send(id, profileId.Value, dto);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpPost("{id:guid}/read")]
        public async Task<IActionResult> MarkRead(Guid id)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await messages.MarkRead(id, profileId.Value);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        #region Message actions

        /// <summary>Edit your own message. Marks it edited; prior versions aren't kept.</summary>
        [HttpPost("messages/{messageId:guid}/edit")]
        public async Task<IActionResult> EditMessage(Guid messageId, [FromBody] EditMessageDto dto)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await messages.Edit(messageId, profileId.Value, dto);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        /// <summary>Unsend your own message. Leaves a tombstone rather than deleting the row.</summary>
        [HttpPost("messages/{messageId:guid}/retract")]
        public async Task<IActionResult> RetractMessage(Guid messageId)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await messages.Retract(messageId, profileId.Value);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        /// <summary>Add, change, or (with an empty emoji) remove your reaction.</summary>
        [HttpPost("messages/{messageId:guid}/react")]
        public async Task<IActionResult> ReactToMessage(Guid messageId, [FromBody] ReactToMessageDto dto)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await messages.React(messageId, profileId.Value, dto);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        #endregion

        #region Conversation management

        /// <summary>Mute or unmute notifications for this thread. Unread counts keep accruing.</summary>
        [HttpPost("{id:guid}/mute")]
        public async Task<IActionResult> SetMuted(Guid id, [FromQuery] bool muted = true)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await messages.SetMuted(id, profileId.Value, muted);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        /// <summary>Leave a group. Direct threads can't be left.</summary>
        [HttpPost("{id:guid}/leave")]
        public async Task<IActionResult> Leave(Guid id)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await messages.Leave(id, profileId.Value);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        /// <summary>Rename a group — admin only.</summary>
        [HttpPost("{id:guid}/rename")]
        public async Task<IActionResult> Rename(Guid id, [FromBody] UpdateConversationDto dto)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await messages.Rename(id, profileId.Value, dto);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        /// <summary>Add people to a group — admin only.</summary>
        [HttpPost("{id:guid}/participants")]
        public async Task<IActionResult> AddParticipants(Guid id, [FromBody] ConversationParticipantsDto dto)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await messages.AddParticipants(id, profileId.Value, dto);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        /// <summary>Remove someone from a group — admin only. Use leave for yourself.</summary>
        [HttpDelete("{id:guid}/participants/{targetProfileId:guid}")]
        public async Task<IActionResult> RemoveParticipant(Guid id, Guid targetProfileId)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await messages.RemoveParticipant(id, profileId.Value, targetProfileId);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        #endregion
    }
}
