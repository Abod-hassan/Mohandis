using Microsoft.AspNetCore.Mvc;
using RoboByte.SocialMedia.Application.Dtos.Filters;
using RoboByte.SocialMedia.Application.Services;

namespace RoboByte.SocialMedia.Presentation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ExperienceController(IProfessionalService professional) : ControllerBase
    {
        /// <summary>A profile's work experience. Create/edit/delete via GenericWrite.</summary>
        [HttpPost]
        public async Task<IActionResult> Get([FromBody] ExperienceFilter filter, [FromQuery] int page = 1, [FromQuery] int size = 50)
        {
            var result = await professional.GetExperiencesAsync(filter, page, size);
            return result.Error ? BadRequest(result) : Ok(result);
        }
    }
}
