using Microsoft.AspNetCore.Mvc;
using RoboByte.SocialMedia.Application.Dtos.Filters;
using RoboByte.SocialMedia.Application.Services;
using RoboByte.SocialMedia.Application.Services.Profiles;

namespace RoboByte.SocialMedia.Presentation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ConnectionsController(IConnectionService connections, ICurrentProfileAccessor currentProfile) : ControllerBase
    {
        /// <summary>A profile's accepted connections (or pending incoming requests when Pending=true).</summary>
        [HttpPost]
        public async Task<IActionResult> Get([FromBody] ConnectionFilter filter, [FromQuery] int page = 1, [FromQuery] int size = 20)
        {
            var result = await connections.GetConnectionsAsync(filter, page, size);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpGet("requests")]
        public async Task<IActionResult> Requests([FromQuery] int page = 1, [FromQuery] int size = 20)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await connections.GetConnectionsAsync(new ConnectionFilter { ProfileId = profileId.Value, Pending = true }, page, size);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpPost("Connect")]
        public async Task<IActionResult> Connect([FromQuery] Guid targetId)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await connections.Connect(profileId.Value, targetId);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpPost("Accept")]
        public async Task<IActionResult> Accept([FromQuery] Guid requesterId)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await connections.Accept(profileId.Value, requesterId);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpPost("Ignore")]
        public async Task<IActionResult> Ignore([FromQuery] Guid requesterId)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await connections.Ignore(profileId.Value, requesterId);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpPost("Remove")]
        public async Task<IActionResult> Remove([FromQuery] Guid targetId)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await connections.Remove(profileId.Value, targetId);
            return result.Error ? BadRequest(result) : Ok(result);
        }
    }
}
