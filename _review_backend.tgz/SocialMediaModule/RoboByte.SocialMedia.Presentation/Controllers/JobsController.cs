using Microsoft.AspNetCore.Mvc;
using RoboByte.SocialMedia.Application.Dtos;
using RoboByte.SocialMedia.Application.Dtos.Filters;
using RoboByte.SocialMedia.Application.Dtos.Forms;
using RoboByte.SocialMedia.Application.Services;
using RoboByte.SocialMedia.Application.Services.Profiles;
using RoboByte.SocialMedia.Domain.Enums;

namespace RoboByte.SocialMedia.Presentation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class JobsController(IJobService jobs, ICurrentProfileAccessor currentProfile) : ControllerBase
    {
        /// <summary>One jobs endpoint — single, search, by location / employment /
        /// workplace type, by poster, open-only.</summary>
        [HttpPost]
        public async Task<IActionResult> Get([FromBody] JobFilter filter, [FromQuery] int page = 1, [FromQuery] int size = 20)
        {
            filter.ViewerProfileId = await currentProfile.GetProfileIdAsync();
            var result = await jobs.GetAsync(filter, page, size);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpGet("{id:guid}")]
        public async Task<IActionResult> GetById(Guid id)
        {
            var result = await jobs.GetAsync(new JobFilter { Id = id, ViewerProfileId = await currentProfile.GetProfileIdAsync(), OpenOnly = false });
            if (result.Error) return BadRequest(result);
            var job = result.Data?.FirstOrDefault();
            return job == null ? NotFound(result) : Ok(result);
        }

        /// <summary>Post a job (create via the generic write engine, poster = current user).</summary>
        [HttpPost("Publish")]
        public async Task<IActionResult> Publish([FromBody] JobForm form)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await jobs.PostJob(profileId.Value, form);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpPost("Apply")]
        public async Task<IActionResult> Apply([FromQuery] Guid jobId, [FromBody] ApplyJobDto dto)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await jobs.Apply(jobId, profileId.Value, dto);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        /// <summary>The current user's own job applications.</summary>
        [HttpGet("my-applications")]
        public async Task<IActionResult> MyApplications([FromQuery] int page = 1, [FromQuery] int size = 20)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await jobs.GetApplicationsAsync(new JobApplicationFilter { ApplicantId = profileId }, page, size);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        /// <summary>Applicants for a job — poster only.</summary>
        [HttpGet("{id:guid}/applications")]
        public async Task<IActionResult> Applications(Guid id, [FromQuery] int page = 1, [FromQuery] int size = 20)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });

            var job = (await jobs.GetAsync(new JobFilter { Id = id, OpenOnly = false }, 1, 1)).Data?.FirstOrDefault();
            if (job == null) return NotFound(new { Error = true, Message = "Job not found." });
            if (job.PostedById != profileId.Value) return StatusCode(403, new { Error = true, Message = "Only the job poster can view applicants." });

            var result = await jobs.GetApplicationsAsync(new JobApplicationFilter { JobId = id }, page, size);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpPost("applications/{applicationId:guid}/status")]
        public async Task<IActionResult> SetStatus(Guid applicationId, [FromQuery] JobApplicationStatusEnum status)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await jobs.SetApplicationStatus(applicationId, profileId.Value, status);
            return result.Error ? BadRequest(result) : Ok(result);
        }
    }
}
