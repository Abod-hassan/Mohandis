using Microsoft.AspNetCore.Mvc;
using RoboByte.SocialMedia.Application.Dtos;
using RoboByte.SocialMedia.Application.Dtos.Filters;
using RoboByte.SocialMedia.Application.Services;
using RoboByte.SocialMedia.Application.Services.Profiles;

namespace RoboByte.SocialMedia.Presentation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StoriesController(IStoryService stories, ICurrentProfileAccessor currentProfile) : ControllerBase
    {
        /// <summary>One stories endpoint — active feed (FollowedOnly), by user
        /// (AuthorIds), or single (Id).</summary>
        [HttpPost]
        public async Task<IActionResult> Get([FromBody] StoryFilter filter, [FromQuery] int page = 1, [FromQuery] int size = 50)
        {
            filter.ViewerProfileId = await currentProfile.GetProfileIdAsync();
            var result = await stories.GetAsync(filter, page, size);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpPost("Publish")]
        public async Task<IActionResult> Publish([FromBody] PublishStoryDto dto)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await stories.Publish(profileId.Value, dto);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpPost("View")]
        public async Task<IActionResult> View([FromQuery] Guid storyId)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await stories.View(storyId, profileId.Value);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpGet("{id:guid}/viewers")]
        public async Task<IActionResult> Viewers(Guid id, [FromQuery] int page = 1, [FromQuery] int size = 20)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await stories.GetViewersAsync(id, profileId.Value, page, size);
            return result.Error ? BadRequest(result) : Ok(result);
        }
    }
}
