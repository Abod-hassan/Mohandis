using Microsoft.AspNetCore.Mvc;
using RoboByte.SocialMedia.Application.Dtos;
using RoboByte.SocialMedia.Application.Dtos.Filters;
using RoboByte.SocialMedia.Application.Services;
using RoboByte.SocialMedia.Application.Services.Profiles;

namespace RoboByte.SocialMedia.Presentation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CommentsController(ICommentService comments, ICurrentProfileAccessor currentProfile) : ControllerBase
    {
        [HttpPost]
        public async Task<IActionResult> Get([FromBody] CommentFilter filter, [FromQuery] int page = 1, [FromQuery] int size = 20)
        {
            filter.ViewerProfileId = await currentProfile.GetProfileIdAsync();
            var result = await comments.GetAsync(filter, page, size);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpPost("Add")]
        public async Task<IActionResult> Add([FromQuery] Guid postId, [FromBody] AddCommentDto dto)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await comments.AddComment(postId, profileId.Value, dto);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpPost("Like")]
        public async Task<IActionResult> Like([FromQuery] Guid commentId)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await comments.LikeComment(commentId, profileId.Value);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpDelete("{id:guid}")]
        public async Task<IActionResult> Delete(Guid id)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await comments.DeleteComment(id, profileId.Value);
            return result.Error ? BadRequest(result) : Ok(result);
        }
    }
}
