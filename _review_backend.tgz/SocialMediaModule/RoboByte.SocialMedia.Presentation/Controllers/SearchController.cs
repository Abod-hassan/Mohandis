using Microsoft.AspNetCore.Mvc;
using RoboByte.SocialMedia.Application.Dtos;
using RoboByte.SocialMedia.Application.Services;
using RoboByte.SocialMedia.Application.Services.Profiles;

namespace RoboByte.SocialMedia.Presentation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SearchController(ISearchService search, ICurrentProfileAccessor currentProfile) : ControllerBase
    {
        /// <summary>Blended results — a few profiles, posts, reels, hashtags and jobs.</summary>
        [HttpGet]
        public async Task<IActionResult> Search([FromQuery] string q, [FromQuery] int take = 10)
        {
            var result = await search.Search(q, await currentProfile.GetProfileIdAsync(), take);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        /// <summary>One kind of result, paged — the "see all" tab behind each section.</summary>
        [HttpGet("{scope}")]
        public async Task<IActionResult> SearchScope(SearchScopeEnum scope, [FromQuery] string q,
            [FromQuery] int page = 1, [FromQuery] int size = 20)
        {
            var result = await search.SearchScopeAsync(scope, q, await currentProfile.GetProfileIdAsync(), page, size);
            return result.Error ? BadRequest(result) : Ok(result);
        }
    }
}
