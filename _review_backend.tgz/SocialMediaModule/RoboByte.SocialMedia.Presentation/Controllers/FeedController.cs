using Microsoft.AspNetCore.Mvc;
using RoboByte.SocialMedia.Application.Dtos;
using RoboByte.SocialMedia.Application.Services.Feed;
using RoboByte.SocialMedia.Domain.Enums;
using RoboByte.SocialMedia.Application.Services.Profiles;

namespace RoboByte.SocialMedia.Presentation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FeedController(IHomeFeedService feed, ICurrentProfileAccessor currentProfile) : ControllerBase
    {
        [HttpPost]
        public async Task<IActionResult> Get([FromBody] FeedPageRequest request)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            var result = await feed.GetHomeFeedAsync(profileId.Value, request);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        /// <summary>
        /// "Not interested" — hide one item, or everything from its author, in this viewer's feed.
        /// Also ranks that author down at the next affinity recompute.
        /// </summary>
        [HttpPost("Hide")]
        public async Task<IActionResult> Hide([FromQuery] Guid itemId, [FromQuery] FeedHideScopeEnum scope = FeedHideScopeEnum.Item)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await feed.HideAsync(profileId.Value, itemId, scope);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpPost("Unhide")]
        public async Task<IActionResult> Unhide([FromQuery] Guid itemId, [FromQuery] FeedHideScopeEnum scope = FeedHideScopeEnum.Item)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });
            var result = await feed.UnhideAsync(profileId.Value, itemId, scope);
            return result.Error ? BadRequest(result) : Ok(result);
        }
    }
}
