using Microsoft.AspNetCore.Mvc;
using RoboByte.SocialMedia.Application.Dtos;
using RoboByte.SocialMedia.Application.Services.Ads;
using RoboByte.SocialMedia.Application.Services.Profiles;

namespace RoboByte.SocialMedia.Presentation.Controllers
{
    /// <summary>
    /// Advertiser-facing ad surface: buy and manage boosts on your own content, read their
    /// performance, and report click-throughs. Creating the underlying <c>AdModel</c> creative, and
    /// any admin-side management, goes through <c>POST /api/GenericWrite/Save</c> and ReportBuilder
    /// per the platform convention — this controller only covers what an advertiser does.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class AdsController(
        IBoostService boosts,
        IAdDeliveryService delivery,
        ICurrentProfileAccessor currentProfile) : ControllerBase
    {
        /// <summary>The caller's own boosts, optionally filtered by status.</summary>
        [HttpPost("boosts")]
        public async Task<IActionResult> Get([FromBody] BoostFilter filter, [FromQuery] int page = 1, [FromQuery] int size = 20)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });

            // Never trust a caller-supplied advertiser id — a boost exposes spend.
            filter.ViewerProfileId = profileId;
            var result = await boosts.GetAsync(filter, page, size);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpGet("boosts/{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });

            var result = await boosts.GetAsync(new BoostFilter { Id = id, ViewerProfileId = profileId }, 1, 1);
            if (result.Error) return BadRequest(result);
            return result.Data?.FirstOrDefault() == null ? NotFound(result) : Ok(result);
        }

        [HttpPost("boosts/Create")]
        public async Task<IActionResult> Create([FromBody] CreateBoostDto dto)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });

            var result = await boosts.Create(profileId.Value, dto);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpPost("boosts/{id:int}/Pause")]
        public async Task<IActionResult> Pause(int id) => await SetPaused(id, true);

        [HttpPost("boosts/{id:int}/Resume")]
        public async Task<IActionResult> Resume(int id) => await SetPaused(id, false);

        /// <summary>
        /// Reports a click-through on a boosted item. Charged at the boost's cost-per-click, and
        /// only accepted from a viewer the boost was actually delivered to.
        /// </summary>
        [HttpPost("boosts/{id:int}/Click")]
        public async Task<IActionResult> Click(int id)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });

            var result = await delivery.RecordClickAsync(id, profileId.Value);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        private async Task<IActionResult> SetPaused(int id, bool paused)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });

            var result = await boosts.SetPaused(id, profileId.Value, paused);
            return result.Error ? BadRequest(result) : Ok(result);
        }
    }
}
