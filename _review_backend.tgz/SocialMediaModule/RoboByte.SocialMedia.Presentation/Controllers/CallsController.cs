using Microsoft.AspNetCore.Mvc;
using RoboByte.SocialMedia.Application.Dtos;
using RoboByte.SocialMedia.Application.Dtos.Filters;
using RoboByte.SocialMedia.Application.Services.Calling;
using RoboByte.SocialMedia.Application.Services.Profiles;

namespace RoboByte.SocialMedia.Presentation.Controllers
{
    /// <summary>
    /// Voice/video call signalling. Responses to Start, Answer and Token carry the credentials the
    /// client needs to join the Agora channel directly — no media passes through this API.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class CallsController(ICallService calls, ICurrentProfileAccessor currentProfile) : ControllerBase
    {
        /// <summary>The caller's own call history.</summary>
        [HttpPost]
        public async Task<IActionResult> Get([FromBody] CallFilter filter, [FromQuery] int page = 1, [FromQuery] int size = 20)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });

            filter.ViewerProfileId = profileId;
            var result = await calls.GetHistoryAsync(filter, page, size);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpPost("Start")]
        public async Task<IActionResult> Start([FromBody] StartCallDto dto)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });

            var result = await calls.Start(profileId.Value, dto);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpPost("{id:guid}/Answer")]
        public async Task<IActionResult> Answer(Guid id)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });

            var result = await calls.Answer(id, profileId.Value);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        [HttpPost("{id:guid}/Decline")]
        public async Task<IActionResult> Decline(Guid id)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });

            var result = await calls.Decline(id, profileId.Value);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        /// <summary>Hang up. From the initiator while still ringing this cancels the call outright.</summary>
        [HttpPost("{id:guid}/Leave")]
        public async Task<IActionResult> Leave(Guid id)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });

            var result = await calls.Leave(id, profileId.Value);
            return result.Error ? BadRequest(result) : Ok(result);
        }

        /// <summary>Re-issues channel credentials before the current token expires mid-call.</summary>
        [HttpPost("{id:guid}/Token")]
        public async Task<IActionResult> Token(Guid id)
        {
            var profileId = await currentProfile.GetProfileIdAsync();
            if (profileId == null) return BadRequest(new { Error = true, Message = "User ID not found in claims." });

            var result = await calls.RefreshToken(id, profileId.Value);
            return result.Error ? BadRequest(result) : Ok(result);
        }
    }
}
