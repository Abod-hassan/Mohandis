import 'package:intl/intl.dart';

/// Money formatter. Defaults to USD with no decimals — override
/// [currencyCode] / [decimals] per locale as needed.
///
/// Example: `formatCurrency(1250)` → `"USD 1,250"`.
/// Example: `formatCurrency(1250, currencyCode: 'د.ع', decimals: 0)` →
/// `"د.ع 1,250"`.
String formatCurrency(
  num amount, {
  String currencyCode = 'USD',
  int decimals = 0,
}) {
  final fmt = NumberFormat.currency(
    symbol: '$currencyCode ',
    decimalDigits: decimals,
  );
  return fmt.format(amount).trim();
}

/// Compact money like "8.9M" / "240K" — used in KPI tiles.
String formatCompactMoney(num amount) {
  if (amount.abs() >= 1000000) {
    return '${(amount / 1000000).toStringAsFixed(1)}M';
  }
  if (amount.abs() >= 1000) {
    return '${(amount / 1000).toStringAsFixed(0)}K';
  }
  return amount.toStringAsFixed(0);
}

String formatDate(DateTime date) =>
    DateFormat.yMMMd().format(date.toLocal());

String formatDateTime(DateTime date) =>
    DateFormat.yMMMd().add_jm().format(date.toLocal());

/// Hour-only time, e.g. "09:30".
String formatTime(DateTime date) => DateFormat.Hm().format(date.toLocal());

/// Clock time in Arabic with an ص/م marker — used for message timestamps.
String formatTimeArabic(DateTime date) =>
    DateFormat('h:mm a', 'ar').format(date.toLocal());

/// Relative age in Arabic, honouring the dual form Arabic needs
/// ("ساعتان", "يومان") that a plain "{n} hours" template gets wrong.
///
/// Returns the bare quantity — callers wrap it in "قبل {time}" via the
/// localized `jobPostedAgo` / `storyPostedAgo` strings.
String relativeTimeArabic(DateTime moment, {DateTime? now}) {
  final delta = (now ?? DateTime.now()).difference(moment);

  if (delta.inMinutes < 1) return 'الآن';
  if (delta.inMinutes < 60) return _quantity(delta.inMinutes, 'د', 'دقيقة', 'دقيقتان');
  if (delta.inHours < 24) return _quantity(delta.inHours, 'س', 'ساعة', 'ساعتان');
  if (delta.inDays < 7) return _quantity(delta.inDays, 'ي', 'يوم', 'يومان');
  if (delta.inDays < 30) {
    return _quantity(delta.inDays ~/ 7, 'أ', 'أسبوع', 'أسبوعان');
  }
  if (delta.inDays < 365) {
    return _quantity(delta.inDays ~/ 30, 'ش', 'شهر', 'شهران');
  }
  return _quantity(delta.inDays ~/ 365, 'سنة', 'سنة', 'سنتان');
}

/// Arabic counts inflect three ways: one, two (dual), and many. `abbrev` is
/// used from 3 upward where the design shows compact forms like "٥ س".
String _quantity(int value, String abbrev, String singular, String dual) {
  if (value == 1) return singular;
  if (value == 2) return dual;
  return '${_arabicDigits(value)} $abbrev';
}

String _arabicDigits(int value) => value
    .toString()
    .split('')
    .map((d) => String.fromCharCode(d.codeUnitAt(0) + 0x0660 - 0x30))
    .join();

/// Arabic date range for a CV row — "٢٠٢٢ — الآن · ٣ سنوات".
///
/// The backend stores experience and education as raw `startDate` / `endDate` /
/// `isCurrent`, so duration phrasing is the client's job. Years only: month
/// precision is noise at the width these rows render, except for a stint under
/// a year where "٥ أشهر" is the only useful thing to say.
String formatDateRangeArabic(DateTime? start, DateTime? end, bool isCurrent) {
  if (start == null) return isCurrent ? 'الآن' : '';

  final from = _arabicDigits(start.year);
  final to = isCurrent || end == null ? 'الآن' : _arabicDigits(end.year);
  final until = isCurrent || end == null ? DateTime.now() : end;

  var years = until.year - start.year;
  // Not a full year yet if the anniversary hasn't come round.
  if (until.month < start.month ||
      (until.month == start.month && until.day < start.day)) {
    years -= 1;
  }

  if (years >= 1) return '$from — $to · ${_arabicYears(years)}';

  final months = (until.year - start.year) * 12 + (until.month - start.month);
  if (months < 1) return '$from — $to';
  return '$from — $to · ${_arabicMonths(months)}';
}

/// Arabic counts inflect by band, not by singular/plural: one, two (dual),
/// 3–10 (plural of paucity), then 11+ back to the singular form.
String _arabicYears(int value) => switch (value) {
  1 => 'سنة',
  2 => 'سنتان',
  <= 10 => '${_arabicDigits(value)} سنوات',
  _ => '${_arabicDigits(value)} سنة',
};

String _arabicMonths(int value) => switch (value) {
  1 => 'شهر',
  2 => 'شهران',
  <= 10 => '${_arabicDigits(value)} أشهر',
  _ => '${_arabicDigits(value)} شهراً',
};
