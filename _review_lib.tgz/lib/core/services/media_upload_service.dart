import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';

import '../config/bunny_storage_config.dart';
import '../error/app_exception.dart';
import '../error/result.dart';
import '../providers.dart';

/// Uploads images to Bunny.net Storage and returns the value to store.
///
/// **What is stored is the host-less path** — `avatars/<uuid>.jpg`, never a
/// full URL. The CDN hostname is deployment configuration: baking it into
/// every row would mean rewriting the database to move zones or put a new pull
/// zone in front, and the same rows have to render behind whatever host each
/// environment uses.
///
/// Uses its own bare Dio on purpose. The app's `ApiClient` attaches a bearer
/// token, `X-KEY` and a request signature to everything it sends; forwarding
/// those to a third party would leak the session, and Bunny would reject the
/// `Content-Type` the client sets anyway.
class MediaUploadService {
  MediaUploadService({required BunnyStorageConfig config, Dio? dio, Uuid? uuid})
    : _config = config,
      _uuid = uuid ?? const Uuid(),
      _dio =
          dio ??
          Dio(
            BaseOptions(
              connectTimeout: const Duration(seconds: 20),
              // Generous: this is a photo over a phone connection, not a JSON
              // round-trip.
              sendTimeout: const Duration(seconds: 60),
              receiveTimeout: const Duration(seconds: 30),
            ),
          );

  final BunnyStorageConfig _config;
  final Dio _dio;
  final Uuid _uuid;

  /// Uploads the file at [localPath] and returns its stored path.
  ///
  /// The name is generated rather than taken from the picker: a device
  /// filename is not unique, can carry the person's own words, and would let
  /// one upload overwrite another's file in a shared zone.
  Future<Result<String, AppException>> uploadImage(String localPath) async {
    if (!_config.isConfigured) {
      return const Result.failure(
        UnknownException('Bunny storage is not configured for this flavour'),
      );
    }

    final file = File(localPath);
    if (!file.existsSync()) {
      return Result.failure(NotFoundException('الملف غير موجود: $localPath'));
    }

    final extension = _extensionOf(localPath);
    final storedPath = '${_config.folder}/${_uuid.v4()}$extension';
    final url = 'https://${_config.host}/${_config.zone}/$storedPath';

    try {
      final length = await file.length();
      await _dio.put<dynamic>(
        url,
        data: file.openRead(),
        options: Options(
          headers: {
            // Bunny's own header name — not `Authorization`.
            'AccessKey': _config.accessKey,
            Headers.contentTypeHeader: 'application/octet-stream',
            // Required with a stream body: without it Dio sends chunked, which
            // Bunny answers with a 411.
            Headers.contentLengthHeader: length,
          },
          // 201 is the success code here; anything else should raise.
          validateStatus: (status) => status != null && status < 300,
        ),
      );
      return Result.success(storedPath);
    } on DioException catch (e) {
      final status = e.response?.statusCode;
      if (status == 401) {
        return const Result.failure(
          UnauthorizedException('مفتاح التخزين غير صحيح'),
        );
      }
      return Result.failure(
        NetworkException(
          'تعذّر رفع الصورة${status != null ? ' ($status)' : ''}',
          cause: e,
        ),
      );
    } catch (e, s) {
      return Result.failure(
        UnknownException('تعذّر رفع الصورة', cause: e, stackTrace: s),
      );
    }
  }

  /// Keeps the source extension so the CDN serves a sensible content type.
  /// Anything unexpected falls back to `.jpg` rather than uploading a file
  /// with no extension at all.
  static String _extensionOf(String path) {
    final dot = path.lastIndexOf('.');
    if (dot == -1 || dot == path.length - 1) return '.jpg';
    final ext = path.substring(dot).toLowerCase();
    const allowed = {'.jpg', '.jpeg', '.png', '.heic', '.webp'};
    return allowed.contains(ext) ? ext : '.jpg';
  }
}

/// Null when the active flavour has no Bunny configuration — callers hide the
/// photo control rather than offering an upload that cannot work.
final mediaUploadServiceProvider = Provider<MediaUploadService?>((ref) {
  final config = ref.watch(appConfigProvider).bunnyStorage;
  if (config == null || !config.isConfigured) return null;
  return MediaUploadService(config: config);
});
