import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'rung_colors.dart';
import 'rung_tokens.dart';

/// Rung's Material theme, built entirely from the design-system tokens in
/// `rung_colors.dart` / `rung_tokens.dart`.
///
/// Widgets SHALL NOT re-declare `fontFamily` — it is set once here and
/// inherited (ARCHITECTURE.md §16.3).
class AppTheme {
  AppTheme._();

  static ThemeData light() => _build(RungColors.light, Brightness.light);

  static ThemeData dark() => _build(RungColors.dark, Brightness.dark);

  static ThemeData _build(RungColors c, Brightness brightness) {
    final scheme = ColorScheme(
      brightness: brightness,
      primary: c.accent,
      onPrimary: Colors.white,
      primaryContainer: c.accentSoft,
      onPrimaryContainer: c.accent,
      secondary: c.accent,
      onSecondary: Colors.white,
      error: c.red,
      onError: Colors.white,
      errorContainer: c.redSoft,
      onErrorContainer: c.red,
      surface: c.surface,
      onSurface: c.ink,
      surfaceContainerLowest: c.surface,
      surfaceContainerLow: c.surface2,
      surfaceContainer: c.surface2,
      surfaceContainerHigh: c.surface3,
      surfaceContainerHighest: c.surface3,
      onSurfaceVariant: c.ink2,
      outline: c.line2,
      outlineVariant: c.line,
    );

    final text = _textTheme(c);

    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: scheme,
      fontFamily: RungType.family,
      scaffoldBackgroundColor: c.bg,
      canvasColor: c.surface,
      dividerColor: c.line,
      splashFactory: InkSparkle.splashFactory,
      extensions: [c],
      textTheme: text,
      dividerTheme: DividerThemeData(color: c.line, thickness: 1, space: 1),
      appBarTheme: AppBarTheme(
        backgroundColor: c.surface,
        foregroundColor: c.ink,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        titleTextStyle: RungType.heading.copyWith(
          fontFamily: RungType.family,
          color: c.ink,
        ),
        shape: Border(bottom: BorderSide(color: c.line)),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: c.accent,
          foregroundColor: Colors.white,
          disabledBackgroundColor: c.surface3,
          disabledForegroundColor: c.ink3,
          minimumSize: const Size.fromHeight(48),
          textStyle: RungType.label.copyWith(
            fontFamily: RungType.family,
            fontSize: 15,
          ),
          shape: const RoundedRectangleBorder(borderRadius: RungRadius.pill),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: c.accent,
          minimumSize: const Size.fromHeight(48),
          side: BorderSide(color: c.accent, width: 1.5),
          textStyle: RungType.label.copyWith(
            fontFamily: RungType.family,
            fontSize: 15,
          ),
          shape: const RoundedRectangleBorder(borderRadius: RungRadius.pill),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: c.accent,
          textStyle: RungType.label.copyWith(fontFamily: RungType.family),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: c.surface,
        hintStyle: RungType.body.copyWith(
          fontFamily: RungType.family,
          color: c.ink3,
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: c.line2),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: c.line2),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: c.accent, width: 2),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: c.red, width: 1.5),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: c.red, width: 2),
        ),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: c.surface2,
        side: BorderSide(color: c.line),
        labelStyle: RungType.caption.copyWith(
          fontFamily: RungType.family,
          color: c.ink2,
        ),
        shape: const StadiumBorder(),
      ),
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: c.surface,
        surfaceTintColor: Colors.transparent,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: c.ink,
        contentTextStyle: RungType.label.copyWith(
          fontFamily: RungType.family,
          color: c.surface,
        ),
        behavior: SnackBarBehavior.floating,
        shape: const RoundedRectangleBorder(borderRadius: RungRadius.mdAll),
      ),
      progressIndicatorTheme: ProgressIndicatorThemeData(
        color: c.accent,
        linearTrackColor: c.surface3,
      ),
      switchTheme: SwitchThemeData(
        thumbColor: const WidgetStatePropertyAll(Colors.white),
        trackColor: WidgetStateProperty.resolveWith(
          (s) => s.contains(WidgetState.selected) ? c.accent : c.line2,
        ),
        trackOutlineColor: const WidgetStatePropertyAll(Colors.transparent),
      ),
      pageTransitionsTheme: const PageTransitionsTheme(
        builders: {
          TargetPlatform.android: CupertinoPageTransitionsBuilder(),
          TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
        },
      ),
    );
  }

  static TextTheme _textTheme(RungColors c) {
    TextStyle s(TextStyle base, Color color) =>
        base.copyWith(fontFamily: RungType.family, color: color);
    return TextTheme(
      displaySmall: s(RungType.display, c.ink),
      headlineSmall: s(RungType.title, c.ink),
      titleLarge: s(RungType.title, c.ink),
      titleMedium: s(RungType.heading, c.ink),
      titleSmall: s(RungType.label, c.ink),
      bodyLarge: s(RungType.body.copyWith(fontSize: 15), c.ink),
      bodyMedium: s(RungType.body, c.ink),
      bodySmall: s(RungType.caption, c.ink2),
      labelLarge: s(RungType.label, c.ink),
      labelMedium: s(RungType.caption, c.ink2),
      labelSmall: s(RungType.micro, c.ink3),
    );
  }
}
