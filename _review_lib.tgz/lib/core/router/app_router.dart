import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/activity/presentation/screens/notifications_screen.dart';
import '../../features/dashboard/presentation/screens/dashboard_screen.dart';
import '../../features/jobs/presentation/screens/apply_screen.dart';
import '../../features/jobs/presentation/screens/job_detail_screen.dart';
import '../../features/jobs/presentation/screens/jobs_screen.dart';
import '../../features/jobs/presentation/screens/my_applications_screen.dart';
import '../../features/messaging/presentation/screens/messages_screen.dart';
import '../../features/messaging/presentation/screens/thread_screen.dart';
import '../../features/network/presentation/screens/network_screen.dart';
import '../../features/posts/presentation/screens/composer_screen.dart';
import '../../features/posts/presentation/screens/feed_screen.dart';
import '../../features/posts/presentation/screens/post_detail_screen.dart';
import '../../features/profile/presentation/screens/edit_profile_screen.dart';
import '../../features/profile/presentation/screens/profile_screen.dart';
import '../../features/reels/presentation/screens/reels_screen.dart';
import '../../features/search/presentation/screens/search_screen.dart';
import '../../features/shared/auth/presentation/notifiers/auth_notifier.dart';
import '../../features/shared/auth/presentation/screens/auth_screen.dart';
import '../../features/profile/data/profile_setup_store.dart';
import '../../features/profile/presentation/screens/profile_setup_screen.dart';
import '../../features/shared/auth/presentation/screens/splash_screen.dart';
import '../../features/stories/presentation/screens/story_viewer_screen.dart';
import 'rung_shell.dart';

final _rootNavigatorKey = GlobalKey<NavigatorState>();

/// Routes are grouped by chrome:
///
/// * Inside [StatefulShellRoute] — the five primary tabs, each with its own
///   stack, under the bottom nav.
/// * On the root navigator (`parentNavigatorKey: _rootNavigatorKey`) — every
///   pushed screen. These cover the nav bar, matching the design's
///   full-screen detail, composer, story, thread, and apply surfaces.
///
/// Where a newly registered account is held until it has a profile.
const String _profileSetupPath = '/onboarding/profile';

/// See docs/ARCHITECTURE.md §4.6 for the auth redirect contract.
final appRouterProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    navigatorKey: _rootNavigatorKey,
    initialLocation: '/splash',
    refreshListenable: AuthRefreshNotifier(ref),
    redirect: (context, state) {
      final auth = ref.read(authNotifierProvider);
      final isAuthed = auth.maybeWhen(
        data: (session) => session != null,
        orElse: () => false,
      );

      final loc = state.matchedLocation;
      // Splash advances itself once auth resolves — never redirect off it.
      if (loc == '/splash') return null;

      final onAuth = loc == '/auth';
      if (!isAuthed) return onAuth ? null : '/auth';

      // A freshly registered account owes us the profile step. Held here
      // rather than merely offered it: the account exists but has nothing on
      // it, and a feed is a poor first impression of a network you have not
      // introduced yourself to yet. The screen itself offers a skip, which
      // clears the flag.
      final onProfileSetup = loc == _profileSetupPath;
      if (ref.read(profileSetupPendingProvider)) {
        return onProfileSetup ? null : _profileSetupPath;
      }

      if (onAuth || onProfileSetup) return '/feed';
      return null;
    },
    routes: [
      GoRoute(path: '/splash', builder: (_, __) => const SplashScreen()),
      GoRoute(path: '/auth', builder: (_, __) => const AuthScreen()),
      GoRoute(
        path: _profileSetupPath,
        parentNavigatorKey: _rootNavigatorKey,
        builder: (_, __) => const ProfileSetupScreen(),
      ),

      // ── Pushed over the shell (no bottom nav) ───────────────────────────
      GoRoute(
        path: '/search',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (_, __) => const SearchScreen(),
      ),
      GoRoute(
        path: '/notifications',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (_, __) => const NotificationsScreen(),
      ),
      GoRoute(
        path: '/messages',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (_, __) => const MessagesScreen(),
        routes: [
          GoRoute(
            path: ':threadId',
            parentNavigatorKey: _rootNavigatorKey,
            builder: (_, state) => ThreadScreen(
              threadId: state.pathParameters['threadId']!,
            ),
          ),
        ],
      ),
      GoRoute(
        path: '/profile/:personId',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (_, state) => ProfileScreen(
          personId: state.pathParameters['personId']!,
        ),
        routes: [
          GoRoute(
            path: 'edit',
            parentNavigatorKey: _rootNavigatorKey,
            builder: (_, __) => const EditProfileScreen(),
          ),
        ],
      ),

      // ── Primary tabs ────────────────────────────────────────────────────
      StatefulShellRoute.indexedStack(
        builder: (_, __, navigationShell) =>
            RungShell(navigationShell: navigationShell),
        branches: [
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/feed',
                builder: (_, __) => const FeedScreen(),
                routes: [
                  GoRoute(
                    path: 'composer',
                    parentNavigatorKey: _rootNavigatorKey,
                    builder: (_, __) => const ComposerScreen(),
                  ),
                  GoRoute(
                    path: 'posts/:postId',
                    parentNavigatorKey: _rootNavigatorKey,
                    builder: (_, state) => PostDetailScreen(
                      postId: state.pathParameters['postId']!,
                    ),
                  ),
                  GoRoute(
                    path: 'stories/:storyId',
                    parentNavigatorKey: _rootNavigatorKey,
                    builder: (_, state) => StoryViewerScreen(
                      storyId: state.pathParameters['storyId']!,
                    ),
                  ),
                ],
              ),
            ],
          ),
          StatefulShellBranch(
            routes: [
              GoRoute(path: '/reels', builder: (_, __) => const ReelsScreen()),
            ],
          ),
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/dashboard',
                builder: (_, __) => const DashboardScreen(),
              ),
            ],
          ),
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/jobs',
                builder: (_, __) => const JobsScreen(),
                routes: [
                  // `applications` is declared before `:jobId` so the literal
                  // segment wins the match.
                  GoRoute(
                    path: 'applications',
                    parentNavigatorKey: _rootNavigatorKey,
                    builder: (_, __) => const MyApplicationsScreen(),
                  ),
                  GoRoute(
                    path: ':jobId',
                    parentNavigatorKey: _rootNavigatorKey,
                    builder: (_, state) => JobDetailScreen(
                      jobId: state.pathParameters['jobId']!,
                    ),
                    routes: [
                      GoRoute(
                        path: 'apply',
                        parentNavigatorKey: _rootNavigatorKey,
                        builder: (_, state) => ApplyScreen(
                          jobId: state.pathParameters['jobId']!,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/network',
                builder: (_, __) => const NetworkScreen(),
              ),
            ],
          ),
        ],
      ),
    ],
  );
});

/// Bridges the providers the redirect reads into a `Listenable` so GoRouter
/// re-evaluates when either changes.
///
/// Both matter: auth state decides signed-in vs signed-out, and the
/// profile-setup flag decides whether a signed-in user is held on onboarding.
/// The flag is restored asynchronously at startup, so without listening to it
/// a returning user mid-onboarding would land on the feed.
class AuthRefreshNotifier extends ChangeNotifier {
  AuthRefreshNotifier(Ref ref) {
    _subs = [
      ref.listen(authNotifierProvider, (_, __) => notifyListeners()),
      ref.listen(profileSetupPendingProvider, (_, __) => notifyListeners()),
    ];
  }

  late final List<ProviderSubscription> _subs;

  @override
  void dispose() {
    for (final sub in _subs) {
      sub.close();
    }
    super.dispose();
  }
}
