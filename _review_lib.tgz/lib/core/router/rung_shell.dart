import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import 'package:flutter_mobile_template/features/network/presentation/notifiers/network_notifier.dart';
import 'package:flutter_mobile_template/l10n/l10n.dart';

import '../theme/rung_colors.dart';
import '../widgets/rung/rung.dart';

/// Shell around the five primary tabs. Each branch keeps its own navigation
/// stack and scroll position via `StatefulShellRoute.indexedStack`.
class RungShell extends ConsumerWidget {
  const RungShell({super.key, required this.navigationShell});

  final StatefulNavigationShell navigationShell;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final c = context.rung;
    final l10n = context.l10n;
    final pendingRequests = ref.watch(pendingRequestCountProvider);

    // Reels is a full-bleed dark surface; the bar floats over it instead of
    // pushing the video up.
    final isReels = navigationShell.currentIndex == 1;

    return Scaffold(
      backgroundColor: c.bg,
      extendBody: isReels,
      body: navigationShell,
      bottomNavigationBar: _BottomNav(
        currentIndex: navigationShell.currentIndex,
        translucent: isReels,
        onSelect: (index) => navigationShell.goBranch(
          index,
          // Tapping the active tab pops that branch back to its root.
          initialLocation: index == navigationShell.currentIndex,
        ),
        items: [
          _NavItem(icon: Icons.home_outlined, activeIcon: Icons.home, label: l10n.navHome),
          _NavItem(
            icon: Icons.video_library_outlined,
            activeIcon: Icons.video_library,
            label: l10n.navReels,
          ),
          _NavItem(
            icon: Icons.dashboard_outlined,
            activeIcon: Icons.dashboard,
            label: l10n.navDashboard,
          ),
          _NavItem(
            icon: Icons.work_outline_rounded,
            activeIcon: Icons.work_rounded,
            label: l10n.navJobs,
          ),
          _NavItem(
            icon: Icons.groups_outlined,
            activeIcon: Icons.groups,
            label: l10n.navNetwork,
            badgeCount: pendingRequests,
          ),
        ],
      ),
    );
  }
}

class _NavItem {
  const _NavItem({
    required this.icon,
    required this.activeIcon,
    required this.label,
    this.badgeCount = 0,
  });

  final IconData icon;
  final IconData activeIcon;
  final String label;
  final int badgeCount;
}

class _BottomNav extends StatelessWidget {
  const _BottomNav({
    required this.currentIndex,
    required this.items,
    required this.onSelect,
    required this.translucent,
  });

  final int currentIndex;
  final List<_NavItem> items;
  final ValueChanged<int> onSelect;
  final bool translucent;

  @override
  Widget build(BuildContext context) {
    final c = context.rung;
    final background = translucent ? const Color(0xE60A0D13) : c.surface;
    final inactive = translucent ? Colors.white60 : c.ink3;
    final active = translucent ? Colors.white : c.accent;

    return Container(
      decoration: BoxDecoration(
        color: background,
        border: Border(
          top: BorderSide(color: translucent ? Colors.white24 : c.line),
        ),
      ),
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 60,
          child: Row(
            children: [
              for (var i = 0; i < items.length; i++)
                Expanded(
                  child: _NavButton(
                    item: items[i],
                    selected: i == currentIndex,
                    activeColor: active,
                    inactiveColor: inactive,
                    onTap: () => onSelect(i),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _NavButton extends StatelessWidget {
  const _NavButton({
    required this.item,
    required this.selected,
    required this.activeColor,
    required this.inactiveColor,
    required this.onTap,
  });

  final _NavItem item;
  final bool selected;
  final Color activeColor;
  final Color inactiveColor;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = selected ? activeColor : inactiveColor;

    return Semantics(
      button: true,
      selected: selected,
      label: item.label,
      child: InkWell(
        onTap: onTap,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                Icon(
                  selected ? item.activeIcon : item.icon,
                  size: 24,
                  color: color,
                ),
                if (item.badgeCount > 0)
                  PositionedDirectional(
                    top: -4,
                    start: -6,
                    child: RungCountBadge(count: item.badgeCount),
                  ),
              ],
            ),
            const SizedBox(height: 3),
            Text(
              item.label,
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w600,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
