/// All backend endpoint paths. **Never inline a URL string in a repository
/// — add it here first.** See docs/ARCHITECTURE.md §7 for the doc-comment
/// convention every endpoint constant SHALL follow.
///
/// Group related constants (auth, users, orders, …) into logical clusters
/// with header comments. Namespace the constant names so grepping for
/// `authLogin` / `usersProfile` / `ordersCreate` finds them.
class EndPoints {
  EndPoints._();

  // ── Host ────────────────────────────────────────────────────────────────

  /// `GET /health` — liveness, and the default tenant an anonymous client
  /// needs before it can write anything.
  ///
  /// Not under `/api`: it is mapped directly on the host, outside every
  /// module. **Response:** `{ ok, tenantId, modules: string[] }`.
  ///
  /// Why the client needs it: the tenant normally rides the JWT's `TenantId`
  /// claim, but sign-up and login happen before there is a token, and Kernel
  /// `StrictTenantWrites` rejects a write with no tenant in scope. The id from
  /// here goes back as the `X-Tenant-Id` header on exactly those calls.
  static const String health = '/health';

  // ══ RoboByte.Auth module ════════════════════════════════════════════════
  //
  // Auth does NOT use the `api/social` prefix — it declares plain routes, so
  // everything here is `api/Auth/…`. There was once a second, mobile-specific
  // controller at `api/Mobile/Auth`; it was deleted (commit "remove mobile
  // controllers") and is absent from the shipped package, so those paths 404.
  //
  // Unlike the social module these actions do NOT return a `ResultViewModel`
  // envelope: login answers a bare `LoginResultDto`, register a bare string.
  // `ApiEnvelope` handles both — a non-envelope body becomes the data.

  /// `POST /api/Auth/Login` — sign in.
  ///
  /// **Request:** `{ userName, password }`. The username is Identity's
  /// `UserName`, not an email — the module never stores one.
  /// **Response:** `{ id, userName, roles, userType, accessToken,
  /// refreshToken, displayName, phoneNumber, tenantId }` — no envelope, and
  /// **no expiry fields**: the access token's lifetime is read out of the JWT's
  /// own `exp` claim (see `MobileAuthResultDto`).
  /// **Failure:** `401` `{ message: "Invalid username" }` for an unknown user
  /// and `{ message: "User Unauthorized" }` for a bad password or a locked-out
  /// account — the two are deliberately not distinguished further.
  static const String authLogin = '/api/Auth/Login';

  /// `PUT /api/Auth/Refresh-Token?refreshToken=<value>` — rotate the
  /// pair.
  ///
  /// Note the verb (**PUT**) and that the token rides in the QUERY STRING, not
  /// the body. The response repeats the same refresh token rather than issuing
  /// a new one; only the access token is re-minted.
  /// **Failure:** `404` when the token is unknown, `401` when it has expired.
  static const String authRefresh = '/api/Auth/Refresh-Token';

  /// `POST /api/Auth/Logout` — revoke a refresh token.
  ///
  /// **Request:** `refreshToken` as **form data** (`[FromForm]`), not JSON.
  static const String authLogout = '/api/Auth/Logout';

  /// `POST /api/Contact` — creates the contact record. **Step 1 of 2** in
  /// registration.
  ///
  /// A user account cannot exist without a contact: `RegisterForm` requires a
  /// `contactId`, and the contact is what carries the person's name and phone.
  ///
  /// **Request:** `{ name, phone, address, userType, gender?, dateOfBirth? }`.
  /// **Response:** `ResultViewModel<Guid>` — `data` is the new contact id,
  /// which step 2 needs.
  static const String contacts = '/api/Contact';

  /// `POST /api/Auth/Register` — creates the Identity user. **Step 2**.
  ///
  /// **Request:** `{ userName, password, contactId }`. The password must pass
  /// Identity's policy (6+ characters here) — a violation comes back as a
  /// `400` whose body is the raw message, e.g. "Passwords must have at least
  /// one digit ('0'-'9')."
  /// **Response:** `200` with the bare string `"user created successfully"` —
  /// no tokens, so the client signs in afterwards.
  static const String authRegister = '/api/Auth/Register';

  /// `POST /api/Auth/ForgotPassword` — `{ email }`, sends a reset link.
  ///
  /// Not wired into the app: the module has no email column, so there is
  /// nothing to send to. Listed so the next person doesn't go looking.
  static const String authForgotPassword = '/api/Auth/ForgotPassword';

  /// `POST /api/Auth/SignUp` — creates the contact AND its login in one
  /// transaction, and returns tokens: one call instead of
  /// contact → register → login.
  ///
  /// **Added in RoboByte.Auth after 1.11.1.** A host still on the older
  /// package answers 404, and `AuthRepositoryImpl` falls back to the
  /// three-call sequence — see the note there before deleting either path.
  ///
  /// **Request:** `{ name, userName, password, phone, gender?, imageUrl?,
  /// address?, dateOfBirth? }`. There is deliberately no `userType`: the
  /// endpoint is anonymous, and a caller-supplied role would make Admin
  /// self-service.
  /// **Response:** the same bare `LoginResultDto` login returns.
  static const String authSignUp = '/api/Auth/SignUp';

  // There is no `/api/auth/me`. Cold-start session validation uses
  // [profilesMe] instead — it needs a valid bearer token, which is exactly the
  // signal we want, and it returns the ProfileId the app needs anyway.
  //
  // There is no signing-bootstrap endpoint either. `RequestSigningInterceptor`
  // omits `X-Request-Key` when no secret is stored, which is the correct
  // behaviour against this backend — do not add a call for it.

  // ── Device / notifications ──────────────────────────────────────────────

  /// `POST /api/device/register-token` — persist the FCM device token
  /// on the user's profile so the backend can target this device.
  ///
  /// **Request:** `{ fcmToken, platform: "android" | "ios" }`.
  static const String deviceRegisterToken = '/api/device/register-token';

  /// `POST /api/device/unregister-token` — clear the FCM token on
  /// logout so the device stops receiving push for this account.
  static const String deviceUnregisterToken = '/api/device/unregister-token';

  // ══ RoboByte.SocialMedia module ═════════════════════════════════════════
  //
  // Every controller in the module is served under `api/social/…` — the module
  // declares `[Route("api/[controller]")]` and `AddRoboByteSocialMedia` applies
  // the Kernel's `AddModuleRoutePrefix("social", …)` convention on top. Without
  // the prefix `JobsController` would collide with the HR module's, and the
  // collision fails at request time, not startup. Never hand-write a module
  // path without it.
  //
  // Two conventions differ from a plain REST API and drive every signature below:
  //
  //   1. **Reads are POSTs.** A list read is `POST /api/social/<Entity>` with a
  //      *filter object* as the body and `?page=&size=` (plus `?detailed=` where
  //      the entity has a simplified projection) in the query. The filter's
  //      `viewerProfileId` is set server-side from the bearer token — never send
  //      it, it is overwritten.
  //   2. **Every response is an envelope.** `ResultViewModel<T>` — the payload is
  //      under `data`, with `error` / `message` / `totalCount` / `hasMore`
  //      alongside. Decode with `ApiEnvelope`; never read a body directly.

  // ── Feed ────────────────────────────────────────────────────────────────

  /// `POST /api/social/Feed` — the ranked home feed, blended from the
  /// Cassandra fan-out store, the Postgres recommendation pool, and ads.
  ///
  /// **Request:** `{ bucket?, beforeEventTime?, recommendationOffset, pageSize }`
  /// — send none of the three cursors for the first page, then echo back
  /// `bucket`, `nextBeforeEventTime` AND `nextRecommendationOffset` from the
  /// previous page. The two sources page independently; dropping either cursor
  /// re-serves rows you already showed.
  /// **Response:** `data` = `{ items: FeedItemDto[], bucket,
  /// nextBeforeEventTime, nextRecommendationOffset, hasMore }`.
  ///
  /// A page can come back shorter than `pageSize` — rows whose underlying post
  /// was deleted are dropped after paging. Treat `hasMore`, not the item count,
  /// as the end-of-feed signal.
  static const String feed = '/api/social/Feed';

  /// `POST /api/social/Feed/Hide?itemId=<guid>&scope=<0|1>` — "not interested".
  /// `scope` 0 hides the single item, 1 hides everything from its author.
  static const String feedHide = '/api/social/Feed/Hide';

  /// `POST /api/social/Feed/Unhide?itemId=<guid>&scope=<0|1>` — undoes [feedHide].
  static const String feedUnhide = '/api/social/Feed/Unhide';

  // ── Posts ───────────────────────────────────────────────────────────────

  /// `POST /api/social/Posts` — filtered post read. Backs profile activity and
  /// hashtag/search listings; the home feed uses [feed] instead.
  ///
  /// **Request:** `PostFilter` body — `{ id?, authorIds?: guid[], followedOnly?,
  /// onlyLiked?, hashtag?, search?, orderBy, descending }` — with
  /// `?detailed=true&page=1&size=20`. `detailed=false` returns the lighter
  /// `PostSimplifiedDto` projection.
  /// **Response:** `data` = `PostDto[]`, `totalCount` + `hasMore` on the envelope.
  static const String posts = '/api/social/Posts';

  /// `GET /api/social/Posts/{id}` — one post, full projection.
  ///
  /// **Failure:** `404` when the post is missing or invisible to the caller —
  /// visibility is applied inside the query, so "private" and "deleted" are
  /// deliberately indistinguishable from the client.
  static String postById(String id) => '/api/social/Posts/$id';

  /// `POST /api/social/Posts/Publish` — create a post.
  ///
  /// **Request:** `{ content, visibility: 0|1|2, media?: [{ url, kind: 0|1,
  /// thumbnailUrl?, position, width?, height?, durationSeconds? }] }`.
  /// Hashtags and @mentions are parsed out of `content` server-side — do not
  /// send a tags array, there is no field for one.
  /// **Response:** `data` = the created `PostDto`.
  static const String postsPublish = '/api/social/Posts/Publish';

  /// `POST /api/social/Posts/Share` — repost, optionally with a comment.
  ///
  /// **Request:** `{ sharedPostId, content?, visibility: 0|1|2 }`.
  /// **Response:** `data` = the new `PostDto` wrapping the original.
  static const String postsShare = '/api/social/Posts/Share';

  /// `POST /api/social/Posts/Like?postId=<guid>` — toggles the caller's like.
  ///
  /// **Response:** `data` = the whole post with authoritative `likeCount` /
  /// `isLiked`, so an optimistic toggle can be reconciled rather than trusted.
  static const String postsLike = '/api/social/Posts/Like';

  /// `POST /api/social/Posts/View?postId=<guid>` — records an explicit view and
  /// marks the viewer's fanned-out feed copy seen. Anonymous views are accepted.
  ///
  /// **Response:** `data` = `true`.
  static const String postsView = '/api/social/Posts/View';

  // ── Comments ────────────────────────────────────────────────────────────

  /// `POST /api/social/Comments` — filtered comment read.
  ///
  /// **Request:** `CommentFilter` body — `{ postId?, parentCommentId?,
  /// topLevelOnly?, orderBy, descending }` — with `?page=&size=`.
  /// **Response:** `data` = `CommentDto[]`. The list is FLAT: replies carry
  /// `parentCommentId` and are nested client-side.
  static const String comments = '/api/social/Comments';

  /// `POST /api/social/Comments/Add?postId=<guid>` — add a comment or reply.
  ///
  /// **Request:** `{ content, parentCommentId? }`.
  /// **Failure:** `400` `"Parent comment not found."` when the parent id is not
  /// a comment on that post.
  static const String commentsAdd = '/api/social/Comments/Add';

  /// `POST /api/social/Comments/Like?commentId=<guid>` — toggle a comment like.
  static const String commentsLike = '/api/social/Comments/Like';

  /// `DELETE /api/social/Comments/{id}` — author-only soft delete.
  static String commentById(String id) => '/api/social/Comments/$id';

  // ── Profiles ────────────────────────────────────────────────────────────

  /// `POST /api/social/Profiles` — filtered profile read; also the people
  /// directory and people search.
  ///
  /// **Request:** `ProfileFilter` body — `{ id?, username?, search?, orderBy,
  /// descending }` — with `?detailed=<bool>&page=&size=`. `detailed=false`
  /// (the default) returns `ProfileSimplifiedDto`: id, username, displayName,
  /// headline, avatarUrl, isVerified, isOnline, lastSeenAt.
  /// **Response:** `data` = `ProfileDto[]` or `ProfileSimplifiedDto[]`.
  static const String profiles = '/api/social/Profiles';

  /// `GET /api/social/Profiles/Me` — the caller's own profile, resolved from the
  /// bearer token, so it takes no id.
  ///
  /// The module keys everything by **ProfileId**, which is NOT the auth
  /// ContactId in the JWT — this endpoint is the only way for the client to
  /// learn its own ProfileId, so "me" surfaces resolve through here first.
  ///
  /// **Response:** `data` = full `ProfileDto` with `isMe: true`.
  static const String profilesMe = '/api/social/Profiles/Me';

  /// `GET /api/social/Profiles/{profileId}` — one profile, full projection
  /// including the viewer-relative flags (`isFollowing`, `followRequestPending`,
  /// `isConnected`, …).
  ///
  /// **Failure:** `404` when unknown.
  static String profileById(String profileId) =>
      '/api/social/Profiles/$profileId';

  /// `GET /api/social/Profiles/followers/{profileId}?page=&size=` —
  /// `data` = `ProfileSimplifiedDto[]`.
  static String profileFollowers(String profileId) =>
      '/api/social/Profiles/followers/$profileId';

  /// `GET /api/social/Profiles/following/{profileId}?page=&size=`.
  static String profileFollowing(String profileId) =>
      '/api/social/Profiles/following/$profileId';

  /// `GET /api/social/Profiles/requests?page=&size=` — inbound follow requests
  /// awaiting the caller's approval (private profiles only).
  static const String profileRequests = '/api/social/Profiles/requests';

  /// `POST /api/social/Profiles/Follow?targetId=<guid>` — follow, or send a
  /// follow request when the target is private.
  ///
  /// **Response:** `data` = `{ isFollowing, pending, followerCount }` — NOT a
  /// profile. `pending: true` means a request was raised, not that a follow
  /// edge now exists.
  static const String profileFollow = '/api/social/Profiles/Follow';

  /// `POST /api/social/Profiles/Unfollow?targetId=<guid>` — same response shape
  /// as [profileFollow]. Also withdraws a pending request.
  static const String profileUnfollow = '/api/social/Profiles/Unfollow';

  /// `POST /api/social/Profiles/AcceptRequest?followerId=<guid>`.
  static const String profileAcceptRequest =
      '/api/social/Profiles/AcceptRequest';

  /// `POST /api/social/Profiles/RejectRequest?followerId=<guid>`.
  static const String profileRejectRequest =
      '/api/social/Profiles/RejectRequest';

  /// `POST /api/social/Profiles/Block?targetId=<guid>` — blocks both ways and
  /// tears down any follow edges.
  static const String profileBlock = '/api/social/Profiles/Block';

  /// `POST /api/social/Profiles/Unblock?targetId=<guid>`.
  static const String profileUnblock = '/api/social/Profiles/Unblock';

  // ── Connections ─────────────────────────────────────────────────────────

  /// `POST /api/social/Connections/Connect?targetId=<guid>` — sends a
  /// connection request (the "add" button).
  ///
  /// **Response:** `data` = `{ connected, incoming, outgoing, connectionCount }`
  /// — `outgoing: true` is the state the button must then show, since the
  /// request exists but has not been accepted.
  static const String connectionsConnect = '/api/social/Connections/Connect';

  /// `POST /api/social/Connections/Accept?requesterId=<guid>` — accepts an
  /// inbound request. Note the parameter is the REQUESTER, not the target.
  static const String connectionsAccept = '/api/social/Connections/Accept';

  /// `POST /api/social/Connections/Ignore?requesterId=<guid>` — dismisses an
  /// inbound request.
  static const String connectionsIgnore = '/api/social/Connections/Ignore';

  /// `POST /api/social/Connections/Remove?targetId=<guid>` — removes an
  /// accepted connection, and also withdraws one still pending.
  static const String connectionsRemove = '/api/social/Connections/Remove';

  /// `POST /api/social/Connections` — a profile's accepted connections.
  ///
  /// **Request:** `{ profileId, pending?, search? }` with `?page=&size=`.
  static const String connections = '/api/social/Connections';

  /// `GET /api/social/Connections/requests?page=&size=` — inbound requests
  /// awaiting the caller.
  static const String connectionRequests = '/api/social/Connections/requests';

  // ── Professional (CV sections) ──────────────────────────────────────────

  /// `POST /api/social/Experience` — a profile's work history.
  ///
  /// **Request:** `{ profileId }` with `?page=&size=`.
  /// **Response:** `data` = `ExperienceDto[]` — raw `startDate`/`endDate`/
  /// `isCurrent`, so date-range phrasing is the client's job.
  static const String experience = '/api/social/Experience';

  /// `POST /api/social/Education` — `{ profileId }` → `EducationDto[]`.
  static const String education = '/api/social/Education';

  /// `POST /api/social/Skills` — `{ profileId }` → `SkillDto[]` with
  /// `endorsementCount` and `isEndorsedByMe`.
  static const String skills = '/api/social/Skills';

  /// `POST /api/social/Skills/Endorse?skillId=<int>` — toggle an endorsement.
  ///
  /// Note `skillId` is the row's **int** id, not the skill name — a name is not
  /// unique across profiles.
  static const String skillsEndorse = '/api/social/Skills/Endorse';

  // ── Stories ─────────────────────────────────────────────────────────────

  /// `POST /api/social/Stories` — the story rail.
  ///
  /// **Request:** `StoryFilter` — `{ authorIds?, activeOnly, followedOnly?,
  /// orderBy, descending }` — with `?page=&size=`. `activeOnly` defaults true
  /// server-side (stories expire after 24h).
  /// **Response:** `data` = `StoryDto[]` — `{ id, authorId, authorName,
  /// authorAvatarUrl, kind, mediaUrl, caption, createdAt, expiresAt,
  /// viewCount, viewedByMe }`.
  static const String stories = '/api/social/Stories';

  /// `POST /api/social/Stories/Publish` — `{ mediaUrl, kind, caption? }`.
  static const String storiesPublish = '/api/social/Stories/Publish';

  /// `POST /api/social/Stories/View?storyId=<guid>` — marks it seen.
  static const String storiesView = '/api/social/Stories/View';

  /// `GET /api/social/Stories/{id}/viewers?page=&size=` — who has seen it.
  static String storyViewers(String id) => '/api/social/Stories/$id/viewers';

  // ── Reels ───────────────────────────────────────────────────────────────

  /// `POST /api/social/Reels` — filtered reel read.
  ///
  /// **Request:** `ReelFilter` — `{ authorIds?, followedOnly?, onlyLiked?,
  /// onlySaved?, search?, orderBy, descending }` with `?page=&size=`.
  /// **Response:** `data` = `ReelDto[]`.
  static const String reels = '/api/social/Reels';

  /// `GET /api/social/Reels/{id}`.
  static String reelById(String id) => '/api/social/Reels/$id';

  /// `GET /api/social/Reels/saved?page=&size=` — the caller's saved reels.
  /// Reels DO have a saved list; posts do not.
  static const String reelsSaved = '/api/social/Reels/saved';

  /// `POST /api/social/Reels/Publish` —
  /// `{ videoUrl, thumbnailUrl?, caption?, durationSeconds? }`.
  static const String reelsPublish = '/api/social/Reels/Publish';

  /// `POST /api/social/Reels/Like?reelId=<guid>` — toggles; returns the reel.
  static const String reelsLike = '/api/social/Reels/Like';

  /// `POST /api/social/Reels/Save?reelId=<guid>` — toggles; returns the reel.
  static const String reelsSave = '/api/social/Reels/Save';

  /// `POST /api/social/Reels/Play?reelId=<guid>` — counts a play. Distinct
  /// from a view: fire it when playback starts, not when the row scrolls past.
  static const String reelsPlay = '/api/social/Reels/Play';

  // ── Notifications (the activity centre) ─────────────────────────────────

  /// `POST /api/social/Notifications` — the inbox.
  ///
  /// **Request:** `NotificationFilter` — `{ unreadOnly?, descending }` with
  /// `?page=&size=`.
  /// **Response:** `data` = `NotificationDto[]` — `{ id, type, actorId,
  /// actorName, actorAvatarUrl, postId?, commentId?, text, isRead, createdAt }`.
  /// `type` arrives BY NAME (`Follow`, `Like`, `Comment`, `Mention`, …).
  static const String notifications = '/api/social/Notifications';

  /// `GET /api/social/Notifications/unread-count` — `data` = int.
  static const String notificationsUnreadCount =
      '/api/social/Notifications/unread-count';

  /// `POST /api/social/Notifications/{id}/read`.
  static String notificationRead(String id) =>
      '/api/social/Notifications/$id/read';

  /// `POST /api/social/Notifications/read-all`.
  static const String notificationsReadAll =
      '/api/social/Notifications/read-all';

  // ── Search & hashtags ───────────────────────────────────────────────────

  /// `GET /api/social/Search?q=<text>&take=<int>` — blended landing page.
  ///
  /// **Response:** `data` = `{ profiles: ProfileSimplifiedDto[], hashtags,
  /// posts: PostSimplifiedDto[], reels, jobs }` — a few of each.
  static const String search = '/api/social/Search';

  /// `GET /api/social/Search/{scope}?q=&page=&size=` — one slice, paged.
  /// `scope` is the enum NAME: `Profiles` | `Posts` | `Reels` | `Hashtags` |
  /// `Jobs`.
  static String searchScope(String scope) => '/api/social/Search/$scope';

  /// `GET /api/social/Hashtags/trending?take=<int>` —
  /// `data` = `[{ tag, postCount }]`.
  static const String hashtagsTrending = '/api/social/Hashtags/trending';

  // ── Messaging ───────────────────────────────────────────────────────────

  /// `GET /api/social/Conversations?page=&size=` — the thread list.
  ///
  /// **Response:** `data` = `ConversationDto[]` — `{ id, type, title,
  /// participants: ProfileSimplifiedDto[], lastMessagePreview, lastMessageAt,
  /// unreadCount, isMuted, isAdmin }`. A direct thread has no title; name it
  /// from the other participant.
  static const String conversations = '/api/social/Conversations';

  /// `POST /api/social/Conversations/Start` — `{ participantIds: guid[],
  /// title? }`. Returns the existing direct thread rather than duplicating it.
  static const String conversationsStart = '/api/social/Conversations/Start';

  /// `GET|POST /api/social/Conversations/{id}/messages` — history (GET,
  /// `?page=&size=`) and send (POST).
  ///
  /// **Request (POST):** `{ content, attachments?, replyToMessageId? }`.
  static String conversationMessages(String id) =>
      '/api/social/Conversations/$id/messages';

  /// `POST /api/social/Conversations/{id}/read` — clears the unread count by
  /// moving the caller's read position, which is what read state is derived
  /// from; there are no per-message receipts.
  static String conversationRead(String id) =>
      '/api/social/Conversations/$id/read';

  /// `POST /api/social/Conversations/{id}/mute?muted=<bool>`.
  static String conversationMute(String id) =>
      '/api/social/Conversations/$id/mute';

  /// `POST /api/social/Conversations/{id}/leave`.
  static String conversationLeave(String id) =>
      '/api/social/Conversations/$id/leave';

  /// `POST /api/social/Conversations/{id}/rename` — `{ title }`, admin only.
  static String conversationRename(String id) =>
      '/api/social/Conversations/$id/rename';

  /// `POST /api/social/Conversations/{id}/participants` — `{ profileIds }`.
  static String conversationParticipants(String id) =>
      '/api/social/Conversations/$id/participants';

  /// `DELETE /api/social/Conversations/{id}/participants/{profileId}`.
  static String conversationParticipant(String id, String profileId) =>
      '/api/social/Conversations/$id/participants/$profileId';

  /// `POST /api/social/Conversations/messages/{id}/edit` — `{ content }`.
  static String messageEdit(String messageId) =>
      '/api/social/Conversations/messages/$messageId/edit';

  /// `POST /api/social/Conversations/messages/{id}/retract` — unsend. Leaves a
  /// tombstone (`isRetracted`), it does not delete the row.
  static String messageRetract(String messageId) =>
      '/api/social/Conversations/messages/$messageId/retract';

  /// `POST /api/social/Conversations/messages/{id}/react` — `{ emoji }`. One
  /// reaction per person per message; reacting again replaces it.
  static String messageReact(String messageId) =>
      '/api/social/Conversations/messages/$messageId/react';

  // ── Jobs ────────────────────────────────────────────────────────────────

  /// `POST /api/social/Jobs` — job search.
  ///
  /// **Request:** `JobFilter` — `{ search?, location?, employmentType?,
  /// workplaceType?, postedById?, openOnly, orderBy, descending }` with
  /// `?page=&size=`. The two enums go BY NAME; omit a filter entirely rather
  /// than sending "all".
  /// **Response:** `data` = `JobDto[]`, including `hasApplied`.
  static const String jobs = '/api/social/Jobs';

  /// `GET /api/social/Jobs/{id}`.
  static String jobById(String id) => '/api/social/Jobs/$id';

  /// `POST /api/social/Jobs/Publish` — `JobForm`.
  static const String jobsPublish = '/api/social/Jobs/Publish';

  /// `POST /api/social/Jobs/Apply?jobId=<guid>` — `{ coverLetter?, resumeUrl? }`.
  static const String jobsApply = '/api/social/Jobs/Apply';

  /// `GET /api/social/Jobs/my-applications?page=&size=` —
  /// `data` = `JobApplicationDto[]`.
  static const String jobsMyApplications = '/api/social/Jobs/my-applications';

  /// `GET /api/social/Jobs/{id}/applications` — the poster's view.
  static String jobApplications(String id) =>
      '/api/social/Jobs/$id/applications';

  /// `POST /api/social/Jobs/applications/{id}/status?status=<name>`.
  static String jobApplicationStatus(String applicationId) =>
      '/api/social/Jobs/applications/$applicationId/status';

  // ── Kernel generic write ────────────────────────────────────────────────

  /// `POST /api/GenericWrite/Save` — the Kernel's generic create/update/delete
  /// engine. **Not** under the `social` prefix: it is host-level, wired by
  /// `AddRoboByteKernelContext<SocialMediaDbContext>()`.
  ///
  /// The module exposes no profile-update endpoint, so editing the signed-in
  /// user's own profile goes through here.
  ///
  /// **Request:** `[{ model: "ProfileModel", id, writeType: "Update",
  /// fields: { <column>: <value>, … } }]` — a LIST of forms. `writeType` is
  /// serialised BY NAME: `Create` | `Update` | `SoftDelete` | `PermanentDelete`
  /// (and the enum is 1-based, so sending an ordinal is doubly easy to get
  /// wrong). `fields` keys are `ProfileModel`'s column names, not the DTO's.
  /// **Response:** `data` = the affected row ids.
  ///
  /// It writes any column you name, with no module-level validation — send only
  /// the fields the user edited.
  static const String genericWriteSave = '/api/GenericWrite/Save';

  // NOTE: the dashboard is the one surface with no backend — the module has
  // no engineer-panel endpoint — so it stays on its mock repository.

  // ── Engineer dashboard ──────────────────────────────────────────────────

  /// `GET /api/dashboard` — the engineer panel summary: continue-learning
  /// card, headline stats, and per-section unread counts.
  ///
  /// **Response:** bare `DashboardSummaryDto`.
  static const String dashboard = '/api/dashboard';
}
