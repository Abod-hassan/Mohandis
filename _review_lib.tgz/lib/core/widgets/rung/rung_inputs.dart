import 'package:flutter/material.dart';

import '../../theme/rung_colors.dart';
import '../../theme/rung_tokens.dart';

/// The neutral search field used on the top bar, jobs, messages, and search.
///
/// Pass [onTap] with no [controller] for the read-only "tap to open search"
/// affordance the feed top bar uses; pass a [controller] for a live field.
class RungSearchField extends StatelessWidget {
  const RungSearchField({
    super.key,
    required this.hint,
    this.controller,
    this.onChanged,
    this.onTap,
    this.autofocus = false,
    this.height = 40,
    this.radius = 11,
  });

  final String hint;
  final TextEditingController? controller;
  final ValueChanged<String>? onChanged;
  final VoidCallback? onTap;
  final bool autofocus;
  final double height;
  final double radius;

  @override
  Widget build(BuildContext context) {
    final c = context.rung;
    final readOnly = controller == null && onChanged == null;

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(radius),
      child: Container(
        height: height,
        padding: const EdgeInsets.symmetric(horizontal: 13),
        decoration: BoxDecoration(
          color: c.surface2,
          borderRadius: BorderRadius.circular(radius),
          border: Border.all(color: c.line),
        ),
        child: Row(
          children: [
            Icon(Icons.search_rounded, size: 17, color: c.ink3),
            const SizedBox(width: 9),
            Expanded(
              child: readOnly
                  ? Text(
                      hint,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        color: c.ink3,
                      ),
                    )
                  : TextField(
                      controller: controller,
                      onChanged: onChanged,
                      autofocus: autofocus,
                      textInputAction: TextInputAction.search,
                      style: TextStyle(fontSize: 14, color: c.ink),
                      decoration: InputDecoration(
                        isDense: true,
                        filled: false,
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                        contentPadding: EdgeInsets.zero,
                        hintText: hint,
                        hintStyle: TextStyle(fontSize: 14, color: c.ink3),
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Labelled form field used across edit-profile and the apply flow.
class RungField extends StatelessWidget {
  const RungField({
    super.key,
    required this.label,
    this.controller,
    this.initialValue,
    this.onChanged,
    this.hint,
    this.maxLines = 1,
    this.height,
    this.obscureText = false,
    this.keyboardType,
    this.textInputAction,
    this.validator,
    this.onSubmitted,
    this.autofillHints,
    this.enabled = true,
  });

  final String label;
  final TextEditingController? controller;
  final String? initialValue;
  final ValueChanged<String>? onChanged;
  final String? hint;
  final int maxLines;
  final double? height;
  final bool obscureText;
  final TextInputType? keyboardType;
  final TextInputAction? textInputAction;

  /// Standard `TextFormField` validator. Supplying one drops the fixed row
  /// height — an error message needs room under the box, and a 44px cage
  /// clips it.
  final String? Function(String?)? validator;

  final ValueChanged<String>? onSubmitted;

  /// Lets the OS offer saved credentials. Worth setting on every auth field:
  /// without it, iOS will not offer to save the password at all.
  final Iterable<String>? autofillHints;

  final bool enabled;

  @override
  Widget build(BuildContext context) {
    final c = context.rung;

    // A fixed-height multiline field fills its box via `expands`, which
    // Flutter requires be paired with null min/max lines.
    final fillsBox = height != null && maxLines > 1;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w700,
            color: c.ink3,
          ),
        ),
        const SizedBox(height: 6),
        SizedBox(
          height:
              height ??
              (maxLines > 1 || validator != null ? null : 44),
          child: TextFormField(
            controller: controller,
            initialValue: controller == null ? initialValue : null,
            onChanged: onChanged,
            onFieldSubmitted: onSubmitted,
            validator: validator,
            obscureText: obscureText,
            keyboardType: keyboardType,
            textInputAction: textInputAction,
            autofillHints: autofillHints,
            enabled: enabled,
            maxLines: obscureText ? 1 : (fillsBox ? null : maxLines),
            expands: fillsBox,
            textAlignVertical: TextAlignVertical.top,
            style: TextStyle(fontSize: 14, color: c.ink),
            decoration: InputDecoration(
              hintText: hint,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 14,
                vertical: 12,
              ),
            ),
          ),
        ),
      ],
    );
  }
}

/// Bordered row with a title, subtitle, and a switch — the edit-profile
/// "open to work" / "private profile" toggles.
class RungToggleTile extends StatelessWidget {
  const RungToggleTile({
    super.key,
    required this.title,
    required this.subtitle,
    required this.value,
    required this.onChanged,
    this.leading,
  });

  final String title;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;
  final Widget? leading;

  @override
  Widget build(BuildContext context) {
    final c = context.rung;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: RungRadius.mdAll,
        border: Border.all(color: c.line),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    if (leading != null) ...[leading!, const SizedBox(width: 6)],
                    Flexible(
                      child: Text(
                        title,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: TextStyle(fontSize: 12, color: c.ink3),
                ),
              ],
            ),
          ),
          Switch.adaptive(value: value, onChanged: onChanged),
        ],
      ),
    );
  }
}
