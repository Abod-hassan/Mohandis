import 'app_type.dart';
import 'bunny_storage_config.dart';
import 'environment.dart';

/// Immutable runtime configuration for the app.
///
/// Resolved once in each flavor entrypoint before `runApp`, then exposed
/// through `appConfigProvider`. Never read flavor info from env vars at
/// call sites — read from this object.
class AppConfig {
  const AppConfig({
    required this.environment,
    required this.apiBaseUrl,
    required this.appName,
    this.appType = AppType.primary,
    this.connectTimeout = const Duration(seconds: 15),
    this.receiveTimeout = const Duration(seconds: 20),
    this.useMockData = false,
    this.bunnyStorage,
    this.defaultTenantId = 1,
    bool? enableLogging,
  }) : _enableLogging = enableLogging;

  final Environment environment;
  final String apiBaseUrl;
  final String appName;
  final AppType appType;
  final Duration connectTimeout;
  final Duration receiveTimeout;

  /// When true, repository providers may be overridden in `bootstrap`
  /// with in-memory mocks. Demo / design-preview builds set this to
  /// `true`; prod always leaves it `false`.
  final bool useMockData;

  /// Where user-uploaded images go. Null disables uploading — the picker is
  /// then hidden rather than failing at submit time.
  final BunnyStorageConfig? bunnyStorage;

  /// Tenant used for anonymous writes when `GET /health` cannot supply one.
  ///
  /// The host is the authority — `TenantStore` asks it first. This only covers
  /// the host being unreachable or running a build whose `/health` predates
  /// the field; matching the deployment's real default keeps sign-up working
  /// in both cases.
  final int defaultTenantId;

  final bool? _enableLogging;

  /// True in dev/staging, false in prod — unless overridden at
  /// construction. Used to gate `LogInterceptor` and other verbose
  /// diagnostics.
  bool get enableLogging => _enableLogging ?? !environment.isProd;
}
