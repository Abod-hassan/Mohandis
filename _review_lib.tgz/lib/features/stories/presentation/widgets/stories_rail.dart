import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:flutter_mobile_template/core/theme/rung_colors.dart';
import 'package:flutter_mobile_template/core/theme/rung_tokens.dart';
import 'package:flutter_mobile_template/core/widgets/rung/rung.dart';
import 'package:flutter_mobile_template/features/shared/people/data/repositories/people_repository_impl.dart';
import 'package:flutter_mobile_template/features/shared/people/domain/entities/person.dart';
import 'package:flutter_mobile_template/l10n/l10n.dart';

import '../notifiers/stories_notifier.dart';

/// Horizontal story rail at the top of the feed. Renders nothing but its own
/// height while loading so the feed below doesn't jump when stories land.
class StoriesRail extends ConsumerWidget {
  const StoriesRail({
    super.key,
    required this.onOpenStory,
    required this.onAddStory,
  });

  final void Function(String storyId) onOpenStory;
  final VoidCallback onAddStory;

  /// Tall enough for a 60px avatar, the 6px gap, and the label at the
  /// theme's maximum 1.3x text scale without the column overflowing.
  static const double _height = 116;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final c = context.rung;
    final stories = ref.watch(storiesNotifierProvider);
    final directory = ref.watch(peopleDirectoryProvider).valueOrNull;
    final me = ref.watch(currentPersonProvider).valueOrNull;

    return Container(
      height: _height,
      decoration: BoxDecoration(
        color: c.surface,
        border: Border(bottom: BorderSide(color: c.line)),
      ),
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.fromLTRB(RungSpace.gutter, 14, RungSpace.gutter, 12),
        children: [
          _AddStoryTile(me: me, onTap: onAddStory),
          ...stories.maybeWhen(
            data: (list) => [
              for (final story in list)
                _StoryTile(
                  // The backend inlines the author on every story row; the
                  // directory is the richer record when it happens to hold
                  // this person, and it is paged, so it often does not.
                  person: directory?[story.authorId] ?? story.author,
                  seed: story.authorId,
                  seen: story.seen,
                  onTap: () => onOpenStory(story.id),
                ),
            ],
            orElse: () => const [],
          ),
        ],
      ),
    );
  }
}

class _AddStoryTile extends StatelessWidget {
  const _AddStoryTile({required this.me, required this.onTap});

  final Person? me;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final c = context.rung;
    return _RailSlot(
      label: context.l10n.feedYourStory,
      onTap: onTap,
      avatar: Container(
        width: 60,
        height: 60,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: c.surface2,
          shape: BoxShape.circle,
          border: Border.all(color: c.line2, width: 2),
        ),
        child: Stack(
          clipBehavior: Clip.none,
          alignment: Alignment.center,
          children: [
            RungAvatar(
              seed: me?.id ?? 'me',
              initials: me?.initials ?? '—',
              size: 44,
            ),
            PositionedDirectional(
              bottom: -6,
              start: -6,
              child: Container(
                width: 22,
                height: 22,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: c.accent,
                  shape: BoxShape.circle,
                  border: Border.all(color: c.surface, width: 2.5),
                ),
                child: const Icon(Icons.add, size: 13, color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StoryTile extends StatelessWidget {
  const _StoryTile({
    required this.person,
    required this.seed,
    required this.seen,
    required this.onTap,
  });

  final Person person;
  final String seed;
  final bool seen;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final name = person.firstName;
    return _RailSlot(
      // A story whose author the directory missed and whose payload predates
      // the inlined name has nothing to label the slot with.
      label: name.isEmpty ? '…' : name,
      onTap: onTap,
      avatar: RungAvatar(
        seed: seed,
        initials: person.initials,
        size: 55,
        ringState: seen ? StoryRingState.seen : StoryRingState.unseen,
      ),
    );
  }
}

class _RailSlot extends StatelessWidget {
  const _RailSlot({
    required this.avatar,
    required this.label,
    required this.onTap,
  });

  final Widget avatar;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final c = context.rung;
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 12),
      child: GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: SizedBox(
          width: 62,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(height: 60, child: Center(child: avatar)),
              const SizedBox(height: 6),
              Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  color: c.ink2,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
