import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:flutter_mobile_template/core/base/base_list_notifier.dart';
import 'package:flutter_mobile_template/core/base/base_repository.dart';

import '../../data/repositories/story_repository_impl.dart';
import '../../domain/entities/story.dart';

class StoriesNotifier extends BaseListNotifier<Story> {
  @override
  BaseRepository<Story> get repository => ref.read(storyRepositoryProvider);

  /// Flips the ring to "seen" immediately, then reconciles with the server.
  /// A failure is intentionally silent — a lost read-receipt must not throw
  /// an error banner over a story the user is already watching.
  Future<void> markSeen(String storyId) async {
    final previous = state.valueOrNull;
    if (previous == null) return;
    state = AsyncValue.data([
      for (final s in previous) s.id == storyId ? s.copyWith(seen: true) : s,
    ]);

    final result = await ref.read(storyRepositoryProvider).markSeen(storyId);
    result.when(
      success: (server) {
        final current = state.valueOrNull ?? previous;
        state = AsyncValue.data([
          for (final s in current) s.id == server.id ? server : s,
        ]);
      },
      failure: (_) {},
    );
  }
}

final storiesNotifierProvider =
    AsyncNotifierProvider<StoriesNotifier, List<Story>>(StoriesNotifier.new);
