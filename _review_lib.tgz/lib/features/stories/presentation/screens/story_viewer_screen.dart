import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import 'package:flutter_mobile_template/core/theme/rung_tokens.dart';
import 'package:flutter_mobile_template/core/utils/formatters.dart';
import 'package:flutter_mobile_template/core/widgets/error_view.dart';
import 'package:flutter_mobile_template/core/widgets/loading_view.dart';
import 'package:flutter_mobile_template/core/widgets/rung/rung.dart';
import 'package:flutter_mobile_template/features/shared/people/data/repositories/people_repository_impl.dart';
import 'package:flutter_mobile_template/l10n/l10n.dart';

import '../../domain/entities/story.dart';
import '../notifiers/stories_notifier.dart';

/// Full-bleed story viewer with an auto-advancing progress bar. Tapping the
/// card pauses; the bar completing closes the story the way the design's
/// 24-hour cards behave.
class StoryViewerScreen extends ConsumerStatefulWidget {
  const StoryViewerScreen({super.key, required this.storyId});

  final String storyId;

  @override
  ConsumerState<StoryViewerScreen> createState() => _StoryViewerScreenState();
}

class _StoryViewerScreenState extends ConsumerState<StoryViewerScreen>
    with SingleTickerProviderStateMixin {
  static const _duration = Duration(seconds: 6);

  late final AnimationController _progress;

  @override
  void initState() {
    super.initState();
    _progress = AnimationController(vsync: this, duration: _duration)
      ..addStatusListener(_onProgressStatus)
      ..forward();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      ref.read(storiesNotifierProvider.notifier).markSeen(widget.storyId);
    });
  }

  void _onProgressStatus(AnimationStatus status) {
    if (status == AnimationStatus.completed && mounted) _close();
  }

  @override
  void dispose() {
    _progress
      ..removeStatusListener(_onProgressStatus)
      ..dispose();
    super.dispose();
  }

  void _close() {
    if (context.canPop()) {
      context.pop();
    } else {
      context.go('/feed');
    }
  }

  @override
  Widget build(BuildContext context) {
    final stories = ref.watch(storiesNotifierProvider);

    return Scaffold(
      backgroundColor: Colors.black,
      body: stories.when(
        loading: () => const LoadingView(),
        error: (e, _) => ErrorView(
          error: e,
          onRetry: () => ref.read(storiesNotifierProvider.notifier).refresh(),
        ),
        data: (list) {
          final match = list.where((s) => s.id == widget.storyId);
          if (match.isEmpty) {
            // The story expired between the rail rendering and the tap.
            WidgetsBinding.instance.addPostFrameCallback((_) => _close());
            return const SizedBox.shrink();
          }
          return _StoryBody(
            story: match.first,
            progress: _progress,
            onClose: _close,
            onPauseChanged: (paused) =>
                paused ? _progress.stop() : _progress.forward(),
          );
        },
      ),
    );
  }
}

class _StoryBody extends ConsumerWidget {
  const _StoryBody({
    required this.story,
    required this.progress,
    required this.onClose,
    required this.onPauseChanged,
  });

  final Story story;
  final AnimationController progress;
  final VoidCallback onClose;
  final ValueChanged<bool> onPauseChanged;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // The backend inlines the author on every story row, so the story itself
    // is the fallback when the directory — which is paged, and need not hold
    // this person at all — misses.
    final author =
        ref.watch(peopleDirectoryProvider).valueOrNull?[story.authorId] ??
        story.author;
    final media = story.mediaUrl;

    return GestureDetector(
      onLongPressStart: (_) => onPauseChanged(true),
      onLongPressEnd: (_) => onPauseChanged(false),
      child: Container(
        decoration: BoxDecoration(gradient: RungGradients.forSeed(story.id)),
        child: Stack(
          fit: StackFit.expand,
          children: [
            // A video story has no player here yet, and its URL is not an
            // image — loading it would only flash the error builder — so the
            // gradient stands in for it.
            if (media != null && !story.isVideo)
              Image.network(
                media,
                fit: BoxFit.cover,
                // The gradient underneath is the fallback; a broken-image
                // glyph across a full-bleed story would read as a crash.
                errorBuilder: (_, __, ___) => const SizedBox.shrink(),
              ),
            SafeArea(
              child: Stack(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 36),
                    child: Center(
                      child: Text(
                        story.caption,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                          fontWeight: FontWeight.w700,
                          height: 1.35,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    top: 14,
                    left: 12,
                    right: 12,
                    child: Column(
                      children: [
                        AnimatedBuilder(
                          animation: progress,
                          builder: (context, _) => ClipRRect(
                            borderRadius: BorderRadius.circular(2),
                            child: LinearProgressIndicator(
                              value: progress.value,
                              minHeight: 3,
                              backgroundColor: Colors.white24,
                              valueColor: const AlwaysStoppedAnimation(
                                Colors.white,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            RungAvatar(
                              seed: story.authorId,
                              initials: author.initials,
                              size: 36,
                              borderColor: Colors.white,
                              borderWidth: 2,
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    author.name,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 14,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  Text(
                                    context.l10n.storyPostedAgo(
                                      relativeTimeArabic(story.createdAt),
                                    ),
                                    style: const TextStyle(
                                      color: Colors.white70,
                                      fontSize: 11,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            IconButton(
                              onPressed: onClose,
                              icon: const Icon(Icons.close, color: Colors.white),
                              tooltip: MaterialLocalizations.of(
                                context,
                              ).closeButtonTooltip,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    bottom: 24,
                    left: 16,
                    right: 16,
                    child: Row(
                      children: [
                        Expanded(
                          child: Container(
                            height: 44,
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            alignment: AlignmentDirectional.centerStart,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(24),
                              border: Border.all(
                                color: Colors.white54,
                                width: 1.5,
                              ),
                            ),
                            child: Text(
                              context.l10n.storyReplyTo(author.firstName),
                              style: const TextStyle(
                                color: Colors.white70,
                                fontSize: 13,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        IconButton(
                          onPressed: () =>
                              showRungToast(context, context.l10n.toastReposted),
                          icon: const Icon(
                            Icons.favorite_border,
                            color: Colors.white,
                            size: 26,
                          ),
                          tooltip: context.l10n.postActionLike,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
