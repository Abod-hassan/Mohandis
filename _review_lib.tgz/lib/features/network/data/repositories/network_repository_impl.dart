import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:flutter_mobile_template/core/api/api_client.dart';
import 'package:flutter_mobile_template/core/api/api_envelope.dart';
import 'package:flutter_mobile_template/core/api/endpoints.dart';
import 'package:flutter_mobile_template/core/error/app_exception.dart';
import 'package:flutter_mobile_template/core/error/result.dart';
import 'package:flutter_mobile_template/core/providers.dart';
import 'package:flutter_mobile_template/features/shared/people/data/dtos/person_dto.dart';
import 'package:flutter_mobile_template/features/shared/people/domain/entities/person.dart';

import '../../domain/entities/connection_request.dart';
import '../../domain/repositories/network_repository.dart';
import '../dtos/connection_request_dto.dart';

/// The network tab, served by the module's `ConnectionsController`.
///
/// Connections are the LinkedIn-style bidirectional edge (request → accept),
/// which is a different relation from following — `ProfilesController` owns
/// that one. The two must not be crossed: accepting a connection does not
/// follow anybody.
class NetworkRepositoryImpl implements NetworkRepository {
  NetworkRepositoryImpl({required ApiClient apiClient}) : _api = apiClient;

  final ApiClient _api;

  /// How many profiles to draw on for the suggestions grid. Larger than the
  /// grid needs, because the pool is filtered down client-side.
  static const int _suggestionPoolSize = 40;

  /// How many tiles the grid shows once filtering is done.
  static const int _suggestionLimit = 8;

  @override
  Future<Result<NetworkOverview, AppException>> overview() async {
    // The requests list is the tab. If it fails the screen fails — there is
    // nothing honest to render in its place.
    final requests = await apiCall(
      EndPoints.connectionRequests,
      () => _api.dio.get<dynamic>(
        EndPoints.connectionRequests,
        queryParameters: {'page': 1, 'size': 50},
      ),
      (envelope) => envelope.list
          .map((j) => ConnectionRequestDto.fromJson(j).toDomain())
          .toList(growable: false),
    );
    if (requests.isFailure) {
      return Result.failure(requests.errorOrNull!);
    }

    final rows = requests.valueOrNull!;
    final suggestions = await _suggestions(
      exclude: {for (final r in rows) r.personId},
    );

    return Result.success(
      NetworkOverview(requests: rows, suggestions: suggestions),
    );
  }

  /// "People you may know", assembled client-side.
  ///
  /// The module has **no recommender** — `ConnectionsController` exposes the
  /// edges and the inbound requests and nothing that proposes people — so this
  /// is the profile directory with everyone already spoken for removed: me, my
  /// accepted connections, and anyone whose request is already sitting in the
  /// list above. It is honest about being a directory slice rather than a
  /// ranked suggestion, and it is the only thing the backend can support.
  ///
  /// Best-effort by design: a failure here yields an empty grid, never an error
  /// screen. Losing the suggestions is a much smaller loss than losing the
  /// requests they sit under.
  Future<List<Person>> _suggestions({required Set<String> exclude}) async {
    final me = await apiCall(
      EndPoints.profilesMe,
      () => _api.dio.get<dynamic>(EndPoints.profilesMe),
      (envelope) {
        final rows = envelope.list;
        return rows.isEmpty ? '' : '${rows.first['id'] ?? ''}';
      },
    );
    final myId = me.valueOrNull ?? '';
    if (myId.isEmpty) return const [];

    // Existing connections — already-connected people are the one thing a
    // "people you may know" grid must never show.
    final connectedCall = apiCall(
      EndPoints.connections,
      () => _api.dio.post<dynamic>(
        EndPoints.connections,
        data: {'profileId': myId, 'pending': false},
        queryParameters: {'page': 1, 'size': 200},
      ),
      (envelope) => envelope.list.map((j) => '${j['id'] ?? ''}').toSet(),
    );

    final poolCall = apiCall(
      EndPoints.profiles,
      () => _api.dio.post<dynamic>(
        EndPoints.profiles,
        data: const <String, dynamic>{},
        queryParameters: {
          'detailed': false,
          'page': 1,
          'size': _suggestionPoolSize,
        },
      ),
      (envelope) => envelope.list
          .map((j) => PersonDto.fromJson(j).toDomain())
          .toList(growable: false),
    );

    final connected = (await connectedCall).valueOrNull ?? const <String>{};
    final pool = (await poolCall).valueOrNull ?? const <Person>[];

    return pool
        .where(
          (p) =>
              p.id.isNotEmpty &&
              p.id != myId &&
              !connected.contains(p.id) &&
              !exclude.contains(p.id),
        )
        .take(_suggestionLimit)
        .toList(growable: false);
  }

  // Accept and Ignore take the REQUESTER's id — answering someone else's
  // request — while Connect takes the TARGET's. Same id in this feature, but
  // the parameter names are not interchangeable server-side.
  @override
  Future<Result<void, AppException>> accept(String personId) =>
      _action(EndPoints.connectionsAccept, 'requesterId', personId);

  @override
  Future<Result<void, AppException>> ignore(String personId) =>
      _action(EndPoints.connectionsIgnore, 'requesterId', personId);

  @override
  Future<Result<void, AppException>> connect(String personId) =>
      _action(EndPoints.connectionsConnect, 'targetId', personId);

  /// Runs one connection action. The responses differ — `Connect` answers a
  /// `ConnectionStateDto`, the rest answer a bare `true` — and none of them is
  /// worth reading here: the tab reloads the rows it changed.
  Future<Result<void, AppException>> _action(
    String path,
    String parameter,
    String personId,
  ) {
    return apiCall<void>(
      path,
      () => _api.dio.post<dynamic>(
        path,
        queryParameters: {parameter: personId},
      ),
      (_) {},
    );
  }
}

final networkRepositoryProvider = Provider<NetworkRepository>((ref) {
  return NetworkRepositoryImpl(apiClient: ref.watch(apiClientProvider));
});
