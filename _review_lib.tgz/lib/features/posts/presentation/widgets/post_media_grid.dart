import 'package:flutter/material.dart';

import 'package:flutter_mobile_template/core/theme/rung_tokens.dart';

import '../../domain/entities/post.dart';

/// Media strip under a post. A single attachment keeps its own aspect ratio;
/// two or more render as a square two-column grid with a "+N" veil on the
/// last visible tile.
///
/// Attachments have no `url` while the backend is mocked, so each tile falls
/// back to a deterministic gradient keyed on the media id.
class PostMediaGrid extends StatelessWidget {
  const PostMediaGrid({super.key, required this.media, this.onTap});

  final List<PostMedia> media;
  final VoidCallback? onTap;

  static const int _maxVisible = 2;

  @override
  Widget build(BuildContext context) {
    if (media.isEmpty) return const SizedBox.shrink();

    if (media.length == 1) {
      return GestureDetector(
        onTap: onTap,
        child: AspectRatio(
          aspectRatio: media.first.aspectRatio,
          child: _Tile(media: media.first),
        ),
      );
    }

    final visible = media.take(_maxVisible).toList(growable: false);
    final overflow = media.length - visible.length;

    return GestureDetector(
      onTap: onTap,
      child: Row(
        children: [
          for (var i = 0; i < visible.length; i++) ...[
            if (i > 0) const SizedBox(width: 2),
            Expanded(
              child: AspectRatio(
                aspectRatio: 1,
                child: _Tile(
                  media: visible[i],
                  overflowCount:
                      i == visible.length - 1 && overflow > 0 ? overflow : null,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _Tile extends StatelessWidget {
  const _Tile({required this.media, this.overflowCount});

  final PostMedia media;
  final int? overflowCount;

  @override
  Widget build(BuildContext context) {
    final url = media.url;
    return Stack(
      fit: StackFit.expand,
      children: [
        if (url != null)
          Image.network(
            url,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => _Placeholder(seed: media.id),
          )
        else
          _Placeholder(seed: media.id),
        if (overflowCount != null)
          Container(
            color: const Color(0x800A0E16),
            alignment: Alignment.center,
            child: Text(
              '+$overflowCount',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 22,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
      ],
    );
  }
}

class _Placeholder extends StatelessWidget {
  const _Placeholder({required this.seed});

  final String seed;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(gradient: RungGradients.forSeed(seed)),
      child: const Center(
        child: Icon(
          Icons.image_outlined,
          color: Colors.white54,
          size: 34,
        ),
      ),
    );
  }
}
