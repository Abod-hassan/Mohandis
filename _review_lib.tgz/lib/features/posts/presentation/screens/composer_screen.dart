import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import 'package:flutter_mobile_template/core/theme/rung_colors.dart';
import 'package:flutter_mobile_template/core/theme/rung_tokens.dart';
import 'package:flutter_mobile_template/core/utils/error_messages.dart';
import 'package:flutter_mobile_template/core/widgets/rung/rung.dart';
import 'package:flutter_mobile_template/features/shared/people/data/repositories/people_repository_impl.dart';
import 'package:flutter_mobile_template/l10n/l10n.dart';

import '../../domain/entities/post.dart';
import '../notifiers/feed_notifier.dart';
import '../widgets/post_visibility_label.dart';

/// Full-screen post composer. Visibility cycles public → followers → private
/// through the pill under the author name, matching the design.
class ComposerScreen extends ConsumerStatefulWidget {
  const ComposerScreen({super.key});

  @override
  ConsumerState<ComposerScreen> createState() => _ComposerScreenState();
}

class _ComposerScreenState extends ConsumerState<ComposerScreen> {
  final _controller = TextEditingController();
  PostVisibility _visibility = PostVisibility.public;
  bool _publishing = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  bool get _canPublish => _controller.text.trim().isNotEmpty && !_publishing;

  Future<void> _publish() async {
    if (!_canPublish) return;
    setState(() => _publishing = true);

    // Hashtags are parsed out of the text server-side and stored in their own
    // table — the publish endpoint takes no tags array.
    final result = await ref
        .read(feedNotifierProvider.notifier)
        .publish(text: _controller.text, visibility: _visibility);

    if (!mounted) return;
    setState(() => _publishing = false);

    result.when(
      success: (_) {
        showRungToast(context, context.l10n.toastPosted);
        if (context.canPop()) context.pop();
      },
      failure: (e) =>
          showRungToast(context, arabicMessageForException(e), success: false),
    );
  }

  @override
  Widget build(BuildContext context) {
    final c = context.rung;
    final l10n = context.l10n;
    final me = ref.watch(currentPersonProvider).valueOrNull;

    return Scaffold(
      backgroundColor: c.surface,
      appBar: RungAppBar(
        showBack: false,
        leading: TextButton(
          onPressed: () => context.canPop() ? context.pop() : context.go('/feed'),
          style: TextButton.styleFrom(foregroundColor: c.ink2),
          child: Text(l10n.actionCancel),
        ),
        title: l10n.composerTitle,
        titleStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: FilledButton(
              onPressed: _canPublish ? _publish : null,
              style: FilledButton.styleFrom(
                minimumSize: const Size(0, 34),
                padding: const EdgeInsets.symmetric(horizontal: 18),
                textStyle: const TextStyle(
                  fontSize: 13.5,
                  fontWeight: FontWeight.w700,
                ),
              ),
              child: _publishing
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : Text(l10n.composerPublish),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(
                RungSpace.gutter,
                14,
                RungSpace.gutter,
                14,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      RungAvatar(
                        seed: me?.id ?? 'me',
                        initials: me?.initials ?? '—',
                        size: 44,
                      ),
                      const SizedBox(width: 11),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            me?.name ?? '',
                            style: const TextStyle(
                              fontSize: 14.5,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(height: 3),
                          _VisibilityPill(
                            visibility: _visibility,
                            onTap: () => setState(
                              () => _visibility = _visibility.next,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: RungSpace.sm),
                  TextField(
                    controller: _controller,
                    autofocus: true,
                    maxLines: null,
                    minLines: 8,
                    onChanged: (_) => setState(() {}),
                    style: TextStyle(fontSize: 16, height: 1.55, color: c.ink),
                    decoration: InputDecoration(
                      filled: false,
                      border: InputBorder.none,
                      enabledBorder: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      contentPadding: EdgeInsets.zero,
                      hintText: l10n.composerHint,
                      hintStyle: TextStyle(fontSize: 16, color: c.ink3),
                    ),
                  ),
                ],
              ),
            ),
          ),
          _AttachmentBar(),
        ],
      ),
    );
  }
}

class _VisibilityPill extends StatelessWidget {
  const _VisibilityPill({required this.visibility, required this.onTap});

  final PostVisibility visibility;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final c = context.rung;
    return InkWell(
      onTap: onTap,
      borderRadius: RungRadius.pill,
      child: Container(
        height: 26,
        padding: const EdgeInsets.symmetric(horizontal: 10),
        decoration: BoxDecoration(
          borderRadius: RungRadius.pill,
          border: Border.all(color: c.line2, width: 1.5),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.public, size: 13, color: c.ink2),
            const SizedBox(width: 5),
            Text(
              visibility.audienceLabel(context),
              style: TextStyle(
                fontSize: 11.5,
                fontWeight: FontWeight.w700,
                color: c.ink2,
              ),
            ),
            const SizedBox(width: 2),
            Icon(Icons.keyboard_arrow_down, size: 14, color: c.ink2),
          ],
        ),
      ),
    );
  }
}

/// Media / document / hashtag / poll affordances. These are presentation-only
/// until the attachments backend lands — each confirms with a toast rather
/// than silently doing nothing.
class _AttachmentBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final c = context.rung;
    final l10n = context.l10n;

    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.symmetric(
          horizontal: RungSpace.gutter,
          vertical: RungSpace.sm,
        ),
        decoration: BoxDecoration(
          border: Border(top: BorderSide(color: c.line)),
        ),
        child: Row(
          children: [
            for (final entry in [
              (Icons.image_outlined, c.green),
              (Icons.description_outlined, c.accent),
              (Icons.tag, c.amber),
              (Icons.poll_outlined, c.ink2),
            ])
              IconButton(
                onPressed: () => showRungToast(context, l10n.comingSoon),
                icon: Icon(entry.$1),
                color: entry.$2,
                tooltip: l10n.comingSoon,
              ),
            const Spacer(),
            IconButton(
              onPressed: () => showRungToast(context, l10n.comingSoon),
              icon: const Icon(Icons.alternate_email),
              color: c.ink3,
              tooltip: l10n.comingSoon,
            ),
          ],
        ),
      ),
    );
  }
}
