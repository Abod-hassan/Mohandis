import 'package:flutter_mobile_template/core/base/base_entity.dart';
import 'package:flutter_mobile_template/features/shared/people/domain/entities/person.dart';

import 'comment.dart';

/// Who can see a post. Mirrors the composer's three-way visibility cycle, and
/// the wire values are the backend's `PostVisibilityEnum` ordinals — the
/// declaration order below IS the contract, do not reorder.
enum PostVisibility { public, followers, private }

/// A single media attachment. The backend's `MediaKindEnum` is `0` image /
/// `1` video; [isVideo] carries that so the grid can badge a video without a
/// second enum.
class PostMedia {
  const PostMedia({
    required this.id,
    this.url,
    this.thumbnailUrl,
    this.aspectRatio = 1,
    this.isVideo = false,
    this.durationSeconds,
  });

  final String id;
  final String? url;
  final String? thumbnailUrl;

  /// Derived from the server's `width`/`height` when both are present, else 1.
  final double aspectRatio;
  final bool isVideo;
  final double? durationSeconds;
}

/// A post quoted inside another post (the "share with comment" embed).
///
/// Built from the backend's `sharedPost` — a `PostSimplifiedDto`, so it
/// carries the original author's name inline and needs no directory lookup.
class QuotedPost {
  const QuotedPost({
    required this.authorId,
    required this.text,
    required this.createdAt,
    this.id = '',
    this.authorName = '',
    this.authorAvatarUrl,
  });

  final String id;
  final String authorId;
  final String text;
  final DateTime createdAt;
  final String authorName;
  final String? authorAvatarUrl;
}

class Post extends BaseEntity {
  const Post({
    required this.id,
    required this.authorId,
    required this.createdAt,
    required this.visibility,
    required this.text,
    this.authorName = '',
    this.authorAvatarUrl,
    this.authorVerified = false,
    this.tags = const [],
    this.media = const [],
    this.likeCount = 0,
    this.liked = false,
    this.commentCount = 0,
    this.comments = const [],
    this.repostCount = 0,
    this.reposted = false,
    this.saved = false,
    this.viewCount = 0,
    this.repostedById,
    this.quoted,
    this.jobId,
  });

  @override
  final String id;

  final String authorId;

  /// Denormalized by the backend onto every post and feed row, so a feed page
  /// renders without a second round-trip per author. May be empty on payloads
  /// that predate the denormalization — fall back to the people directory.
  final String authorName;
  final String? authorAvatarUrl;
  final bool authorVerified;

  final DateTime createdAt;
  final PostVisibility visibility;
  final String text;

  /// Hashtags found in [text]. The backend parses these out of the content
  /// itself and does not accept a tags array on publish — this is a read-side
  /// convenience only.
  final List<String> tags;

  final List<PostMedia> media;

  final int likeCount;
  final bool liked;

  /// Server-side total. [comments] may hold only the first page, so the card
  /// renders this rather than `comments.length`.
  final int commentCount;
  final List<Comment> comments;

  /// The backend calls this the share count — a repost IS a share there.
  final int repostCount;
  final bool reposted;

  /// Always false against the live backend: the module has a saved-reels list
  /// but no saved-posts table. Kept so the card's bookmark control still
  /// renders; `PostRepository.toggleSave` reports it as unsupported.
  final bool saved;

  final int viewCount;

  /// Set when this post appears in the feed because someone reposted it.
  final String? repostedById;

  final QuotedPost? quoted;

  /// A job posting shared into the feed, rendered as a tappable embed.
  final String? jobId;

  bool get hasMedia => media.isNotEmpty;
  bool get hasTags => tags.isNotEmpty;
  bool get isRepost => repostedById != null;

  /// The author as a [Person], assembled from the fields the backend inlines.
  ///
  /// Thinner than a directory entry — there is no headline or location on a
  /// post payload — so prefer a directory hit when one exists and use this as
  /// the fallback that keeps the card from rendering blank.
  Person get author => Person(
    id: authorId,
    name: authorName,
    firstName: authorName.split(RegExp(r'\s+')).first,
    headline: '',
    location: '',
    verified: authorVerified,
  );

  Post copyWith({
    String? text,
    PostVisibility? visibility,
    List<String>? tags,
    List<PostMedia>? media,
    int? likeCount,
    bool? liked,
    int? commentCount,
    List<Comment>? comments,
    int? repostCount,
    bool? reposted,
    bool? saved,
    int? viewCount,
  }) {
    return Post(
      id: id,
      authorId: authorId,
      authorName: authorName,
      authorAvatarUrl: authorAvatarUrl,
      authorVerified: authorVerified,
      createdAt: createdAt,
      visibility: visibility ?? this.visibility,
      text: text ?? this.text,
      tags: tags ?? this.tags,
      media: media ?? this.media,
      likeCount: likeCount ?? this.likeCount,
      liked: liked ?? this.liked,
      commentCount: commentCount ?? this.commentCount,
      comments: comments ?? this.comments,
      repostCount: repostCount ?? this.repostCount,
      reposted: reposted ?? this.reposted,
      saved: saved ?? this.saved,
      viewCount: viewCount ?? this.viewCount,
      repostedById: repostedById,
      quoted: quoted,
      jobId: jobId,
    );
  }

  /// Applies a like toggle locally so the notifier can update optimistically
  /// before the server round-trip lands.
  Post toggleLike() =>
      copyWith(liked: !liked, likeCount: likeCount + (liked ? -1 : 1));

  Post toggleRepost() => copyWith(
    reposted: !reposted,
    repostCount: repostCount + (reposted ? -1 : 1),
  );

  Post toggleSave() => copyWith(saved: !saved);
}
