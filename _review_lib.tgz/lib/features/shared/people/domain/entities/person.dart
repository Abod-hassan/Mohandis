import 'package:flutter_mobile_template/core/base/base_entity.dart';

/// A person on Rung. Deliberately thin — it carries only what the feed,
/// messaging, search, and network surfaces render. The full CV-style record
/// lives in the profile feature's `Profile` entity.
class Person extends BaseEntity {
  const Person({
    required this.id,
    required this.name,
    required this.firstName,
    required this.headline,
    required this.location,
    this.verified = false,
  });

  @override
  final String id;

  final String name;

  /// Short form used in toasts and story labels ("أمل").
  final String firstName;

  final String headline;
  final String location;
  final bool verified;

  /// Two-letter monogram for the avatar, derived from the display name.
  String get initials {
    final parts = name.trim().split(RegExp(r'\s+')).where((p) => p.isNotEmpty);
    if (parts.isEmpty) return '؟';
    if (parts.length == 1) return parts.first.characters2;
    return '${parts.first.characters2[0]}${parts.last.characters2[0]}';
  }

  Person copyWith({
    String? name,
    String? firstName,
    String? headline,
    String? location,
    bool? verified,
  }) {
    return Person(
      id: id,
      name: name ?? this.name,
      firstName: firstName ?? this.firstName,
      headline: headline ?? this.headline,
      location: location ?? this.location,
      verified: verified ?? this.verified,
    );
  }
}

extension on String {
  /// First two characters, or the whole string when shorter.
  String get characters2 => length <= 2 ? this : substring(0, 2);
}
