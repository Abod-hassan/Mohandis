import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import 'package:flutter_mobile_template/core/theme/rung_tokens.dart';
import 'package:flutter_mobile_template/l10n/l10n.dart';

import '../notifiers/auth_notifier.dart';

/// Cold-start splash. Blocks navigation on:
///   1. `authNotifierProvider` resolving (either a live session or a
///      definitive signed-out).
///   2. A minimum display window so the splash isn't a flash.
///
/// Signing-bootstrap fires in parallel with the splash animation, best-
/// effort — a failure is swallowed since `RequestSigningInterceptor`
/// gracefully skips signing when no secret is stored.
class SplashScreen extends ConsumerStatefulWidget {
  const SplashScreen({super.key});

  @override
  ConsumerState<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends ConsumerState<SplashScreen> {
  static const _minDisplay = Duration(milliseconds: 1200);

  Timer? _minTimer;
  bool _minElapsed = false;

  @override
  void initState() {
    super.initState();
    _minTimer = Timer(_minDisplay, () {
      if (!mounted) return;
      setState(() => _minElapsed = true);
      _tryAdvance();
    });
    _bootstrapSigning();
  }

  Future<void> _bootstrapSigning() async {
    try {
      await ref.read(authRepositoryProvider).ensureSigningSecret();
    } catch (_) {
      // Best-effort — swallow.
    }
  }

  @override
  void dispose() {
    _minTimer?.cancel();
    super.dispose();
  }

  void _tryAdvance() {
    if (!_minElapsed) return;
    final auth = ref.read(authNotifierProvider);
    if (auth.isLoading) return;
    final hasSession = auth.maybeWhen(
      data: (s) => s != null,
      orElse: () => false,
    );
    if (!mounted) return;
    context.go(hasSession ? '/feed' : '/auth');
  }

  @override
  Widget build(BuildContext context) {
    ref.listen(authNotifierProvider, (_, __) => _tryAdvance());
    return Scaffold(
      body: DecoratedBox(
        decoration: const BoxDecoration(gradient: RungGradients.brand),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 78,
                height: 78,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: const Color(0x29FFFFFF),
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: const Color(0x40FFFFFF)),
                ),
                child: const Text(
                  'ر',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 40,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              const SizedBox(height: 18),
              Text(
                context.l10n.appTitle,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 26,
                  fontWeight: FontWeight.w800,
                  letterSpacing: -0.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
