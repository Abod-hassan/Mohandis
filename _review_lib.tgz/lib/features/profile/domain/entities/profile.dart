import 'package:flutter_mobile_template/core/base/base_entity.dart';
import 'package:flutter_mobile_template/features/shared/people/domain/entities/person.dart';

class Experience {
  const Experience({
    required this.role,
    required this.company,
    required this.monogram,
    required this.dates,
    required this.location,
    this.description = '',
  });

  final String role;
  final String company;
  final String monogram;

  /// Preformatted by the backend ("٢٠٢٢ — الآن · ٣ سنوات") — duration
  /// phrasing is locale work the client shouldn't duplicate.
  final String dates;

  final String location;
  final String description;

  bool get hasDescription => description.trim().isNotEmpty;
}

class Education {
  const Education({
    required this.school,
    required this.monogram,
    required this.degree,
    required this.dates,
  });

  final String school;
  final String monogram;
  final String degree;
  final String dates;
}

/// What kind of account a profile is.
///
/// Distinct from Identity's `UserTypeEnum` (SystemAdmin / Admin / User), which
/// is a permission role — this is what the account IS. Chosen at sign-up and
/// stored on the social profile, since Auth's contact record has no field for
/// it. The declaration order is the wire contract: it maps to the backend's
/// `AccountTypeEnum` ordinals.
enum AccountType { individual, company }

class Skill {
  const Skill({
    required this.name,
    required this.endorsements,
    this.id = 0,
    this.endorsedByMe = false,
  });

  /// The row's int id. Endorsing goes by id, not name — a skill name is not
  /// unique across profiles, so the name alone cannot address a row.
  final int id;

  final String name;
  final int endorsements;
  final bool endorsedByMe;

  Skill copyWith({int? endorsements, bool? endorsedByMe}) => Skill(
    id: id,
    name: name,
    endorsements: endorsements ?? this.endorsements,
    endorsedByMe: endorsedByMe ?? this.endorsedByMe,
  );
}

/// The CV-shaped record behind a profile screen. Keyed by the person's id —
/// [id] and [personId] are the same value, exposed twice so `BaseEntity`
/// equality works while call sites read naturally.
class Profile extends BaseEntity {
  const Profile({
    required this.personId,
    required this.about,
    this.username = '',
    this.displayName = '',
    this.headline = '',
    this.location = '',
    this.avatarUrl,
    this.coverUrl,
    this.website,
    this.verified = false,
    this.accountType = AccountType.individual,
    this.isMe = false,
    this.followRequestPending = false,
    this.industry = '',
    this.openToWork = false,
    this.hiring = false,
    this.isPrivate = false,
    this.following = false,
    this.connected = false,
    this.connectionIncoming = false,
    this.connectionOutgoing = false,
    this.connectionCount = 0,
    this.followerCount = 0,
    this.followingCount = 0,
    this.postCount = 0,
    this.experience = const [],
    this.education = const [],
    this.skills = const [],
  });

  @override
  String get id => personId;

  final String personId;

  // Identity. The backend returns these on the profile itself, so a profile
  // screen no longer depends on the people directory having this person.
  final String username;
  final String displayName;
  final String headline;
  final String location;
  final String? avatarUrl;
  final String? coverUrl;
  final String? website;
  final bool verified;

  /// Individual or company. Defaults to individual for any profile created
  /// before the column existed, which is the safe reading of a null.
  final AccountType accountType;

  /// True when this profile belongs to the caller — resolved server-side from
  /// the bearer token, never by comparing ids client-side.
  final bool isMe;

  /// A follow request was sent to a private profile and is awaiting approval.
  /// [following] stays false until it is accepted.
  final bool followRequestPending;

  /// An accepted connection — the two profiles are connected.
  final bool connected;

  /// They asked to connect with you and are waiting on an answer. The button
  /// becomes "accept" rather than "add".
  final bool connectionIncoming;

  /// You asked them, and it hasn't been accepted yet. This is what the button
  /// must show after an add request, instead of inviting the same tap again.
  final bool connectionOutgoing;

  final String about;
  final String industry;
  final bool openToWork;
  final bool hiring;
  final bool isPrivate;

  /// Whether the signed-in user follows this person.
  final bool following;

  final int connectionCount;
  final int followerCount;
  final int followingCount;
  final int postCount;
  final List<Experience> experience;
  final List<Education> education;
  final List<Skill> skills;

  /// This profile as a directory [Person] — enough for a header or an avatar
  /// without a second lookup.
  Person get person => Person(
    id: personId,
    name: displayName,
    firstName: displayName.split(RegExp(r'\s+')).first,
    headline: headline,
    location: location,
    verified: verified,
  );

  Profile copyWith({
    String? about,
    String? industry,
    String? displayName,
    String? headline,
    String? location,
    bool? openToWork,
    bool? isPrivate,
    bool? following,
    bool? followRequestPending,
    bool? connected,
    bool? connectionIncoming,
    bool? connectionOutgoing,
    int? followerCount,
    List<Skill>? skills,
  }) {
    return Profile(
      personId: personId,
      username: username,
      displayName: displayName ?? this.displayName,
      headline: headline ?? this.headline,
      location: location ?? this.location,
      avatarUrl: avatarUrl,
      coverUrl: coverUrl,
      website: website,
      verified: verified,
      accountType: accountType,
      isMe: isMe,
      about: about ?? this.about,
      industry: industry ?? this.industry,
      openToWork: openToWork ?? this.openToWork,
      hiring: hiring,
      isPrivate: isPrivate ?? this.isPrivate,
      following: following ?? this.following,
      followRequestPending: followRequestPending ?? this.followRequestPending,
      connected: connected ?? this.connected,
      connectionIncoming: connectionIncoming ?? this.connectionIncoming,
      connectionOutgoing: connectionOutgoing ?? this.connectionOutgoing,
      connectionCount: connectionCount,
      followerCount: followerCount ?? this.followerCount,
      followingCount: followingCount,
      postCount: postCount,
      experience: experience,
      education: education,
      skills: skills ?? this.skills,
    );
  }
}
