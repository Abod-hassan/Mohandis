import 'package:flutter_mobile_template/core/error/app_exception.dart';
import 'package:flutter_mobile_template/core/error/result.dart';

import '../entities/profile.dart';

/// Profiles are read by person id and only ever written for the signed-in
/// user, so this deliberately does not extend `BaseRepository` — the generic
/// CRUD surface would advertise operations the backend refuses.
abstract class ProfileRepository {
  /// The full profile: identity, counts, viewer-relative flags, and the three
  /// CV sections (experience, education, skills) fetched alongside.
  ///
  /// Pass [meSentinel] as [personId] for the signed-in user. The module keys
  /// everything by ProfileId, which the client cannot derive from its auth
  /// token, so "me" has to be resolved by the server.
  Future<Result<Profile, AppException>> byPerson(String personId);

  /// The id that means "whoever is holding the bearer token".
  static const String meSentinel = 'me';

  /// Saves the signed-in user's profile edits.
  ///
  /// [body] keys: `name`, `headline`, `industry`, `location`, `about`,
  /// `openToWork`, `isPrivate` — the same keys the edit screen already sends —
  /// plus `accountType`, which takes an [AccountType] value rather than a
  /// string and is set once at sign-up.
  Future<Result<Profile, AppException>> updateMe(Map<String, dynamic> body);

  /// Follows or unfollows [personId].
  ///
  /// [isFollowing] is the state being toggled AWAY from — the backend has
  /// separate Follow and Unfollow actions rather than one toggle, so the
  /// caller has to say which way it is going. Pass null to have the repository
  /// read the current state first (one extra round-trip).
  Future<Result<Profile, AppException>> toggleFollow(
    String personId, {
    bool? isFollowing,
  });

  /// Sends a connection request — the "add" button.
  ///
  /// Returns the profile as the server sees it afterwards, so the button can
  /// render the state that actually exists (`connectionOutgoing` for a request
  /// awaiting their answer) rather than assuming success meant "connected".
  Future<Result<Profile, AppException>> connect(String personId);

  /// Accepts an inbound request from [personId].
  Future<Result<Profile, AppException>> acceptConnection(String personId);

  /// Dismisses an inbound request from [personId].
  Future<Result<Profile, AppException>> ignoreConnection(String personId);

  /// Removes an accepted connection — and withdraws one still pending, which
  /// is what "cancel request" maps to.
  Future<Result<Profile, AppException>> removeConnection(String personId);

  /// Toggles the caller's endorsement of one skill row.
  ///
  /// Addressed by the skill's int id, not its name: names are not unique
  /// across profiles.
  Future<Result<Profile, AppException>> endorseSkill({
    required String personId,
    required int skillId,
  });
}
