import 'package:flutter_mobile_template/core/base/base_dto.dart';
import 'package:flutter_mobile_template/core/utils/formatters.dart';

import '../../domain/entities/profile.dart';

/// Wire model for the backend's `ProfileDto`
/// (`GET /api/social/Profiles/{id}`, `GET /api/social/Profiles/Me`,
/// `POST /api/social/Profiles` with `?detailed=true`).
///
/// The CV sections are NOT part of this payload — experience, education and
/// skills are three separate endpoints, fetched alongside and passed to
/// [toDomain]. That is why `toDomain()` takes arguments: a profile with no
/// sections is a valid partial read, not an error.
class ProfileDto implements BaseDto<Profile> {
  const ProfileDto({
    required this.id,
    required this.username,
    required this.displayName,
    this.bio,
    this.avatarUrl,
    this.coverUrl,
    this.website,
    this.location,
    this.headline,
    this.industry,
    this.about,
    this.isOpenToWork = false,
    this.isHiring = false,
    this.isPrivate = false,
    this.isVerified = false,
    this.accountType = AccountType.individual,
    this.followerCount = 0,
    this.followingCount = 0,
    this.connectionCount = 0,
    this.postCount = 0,
    this.isMe = false,
    this.isFollowing = false,
    this.followRequestPending = false,
    this.isConnected = false,
    this.connectionIncoming = false,
    this.connectionOutgoing = false,
  });

  factory ProfileDto.fromJson(Map<String, dynamic> json) => ProfileDto(
    id: '${json['id'] ?? ''}',
    username: '${json['username'] ?? ''}',
    displayName: '${json['displayName'] ?? ''}',
    bio: json['bio'] as String?,
    avatarUrl: json['avatarUrl'] as String?,
    coverUrl: json['coverUrl'] as String?,
    website: json['website'] as String?,
    location: json['location'] as String?,
    headline: json['headline'] as String?,
    industry: json['industry'] as String?,
    about: json['about'] as String?,
    isOpenToWork: json['isOpenToWork'] == true,
    isHiring: json['isHiring'] == true,
    isPrivate: json['isPrivate'] == true,
    isVerified: json['isVerified'] == true,
    accountType: accountTypeFromWire(json['accountType']),
    followerCount: _int(json['followerCount']),
    followingCount: _int(json['followingCount']),
    connectionCount: _int(json['connectionCount']),
    postCount: _int(json['postCount']),
    isMe: json['isMe'] == true,
    isFollowing: json['isFollowing'] == true,
    followRequestPending: json['followRequestPending'] == true,
    isConnected: json['isConnected'] == true,
    connectionIncoming: json['connectionIncoming'] == true,
    connectionOutgoing: json['connectionOutgoing'] == true,
  );

  final String id;
  final String username;
  final String displayName;
  final String? bio;
  final String? avatarUrl;
  final String? coverUrl;
  final String? website;
  final String? location;
  final String? headline;
  final String? industry;
  final String? about;
  final bool isOpenToWork;
  final bool isHiring;
  final bool isPrivate;
  final bool isVerified;
  final AccountType accountType;
  final int followerCount;
  final int followingCount;
  final int connectionCount;
  final int postCount;
  final bool isMe;
  final bool isFollowing;
  final bool followRequestPending;
  final bool isConnected;
  final bool connectionIncoming;
  final bool connectionOutgoing;

  @override
  Profile toDomain({
    List<Experience> experience = const [],
    List<Education> education = const [],
    List<Skill> skills = const [],
  }) => Profile(
    personId: id,
    username: username,
    displayName: displayName,
    headline: headline ?? '',
    location: location ?? '',
    avatarUrl: avatarUrl,
    coverUrl: coverUrl,
    website: website,
    verified: isVerified,
    accountType: accountType,
    isMe: isMe,
    // `about` is the professional summary and `bio` the short social one. The
    // profile screen shows a single "about" block, so fall back rather than
    // leave it blank for a profile that only filled in the social side.
    about: about ?? bio ?? '',
    industry: industry ?? '',
    openToWork: isOpenToWork,
    hiring: isHiring,
    isPrivate: isPrivate,
    following: isFollowing,
    followRequestPending: followRequestPending,
    connected: isConnected,
    connectionIncoming: connectionIncoming,
    connectionOutgoing: connectionOutgoing,
    connectionCount: connectionCount,
    followerCount: followerCount,
    followingCount: followingCount,
    postCount: postCount,
    experience: experience,
    education: education,
    skills: skills,
  );

  @override
  Map<String, dynamic> toJson() => {
    'id': id,
    'username': username,
    'displayName': displayName,
    'headline': headline,
    'industry': industry,
    'about': about,
    'location': location,
    'isOpenToWork': isOpenToWork,
    'isPrivate': isPrivate,
  };

  static int _int(Object? raw) => (raw as num?)?.toInt() ?? 0;

  /// `AccountTypeEnum` — by name, since the host registers Newtonsoft's
  /// `StringEnumConverter`; ordinals are accepted too. Anything unrecognised,
  /// including the null a pre-migration row returns, reads as individual.
  static AccountType accountTypeFromWire(Object? raw) {
    if (raw is num) {
      final i = raw.toInt();
      return i >= 0 && i < AccountType.values.length
          ? AccountType.values[i]
          : AccountType.individual;
    }
    return '$raw'.toLowerCase() == 'company'
        ? AccountType.company
        : AccountType.individual;
  }

  /// Writes go through the Kernel generic engine, which takes the enum by
  /// name — the same spelling the C# member has.
  static String accountTypeToWire(AccountType type) =>
      type == AccountType.company ? 'Company' : 'Individual';
}

/// `ExperienceDto` — `POST /api/social/Experience`.
class ExperienceDto {
  const ExperienceDto({
    required this.title,
    required this.companyName,
    this.location,
    this.startDate,
    this.endDate,
    this.isCurrent = false,
    this.description,
  });

  factory ExperienceDto.fromJson(Map<String, dynamic> json) => ExperienceDto(
    title: '${json['title'] ?? ''}',
    companyName: '${json['companyName'] ?? ''}',
    location: json['location'] as String?,
    startDate: DateTime.tryParse('${json['startDate']}'),
    endDate: DateTime.tryParse('${json['endDate']}'),
    isCurrent: json['isCurrent'] == true,
    description: json['description'] as String?,
  );

  final String title;
  final String companyName;
  final String? location;
  final DateTime? startDate;
  final DateTime? endDate;
  final bool isCurrent;
  final String? description;

  Experience toDomain() => Experience(
    role: title,
    company: companyName,
    monogram: monogramOf(companyName),
    dates: formatDateRangeArabic(startDate, endDate, isCurrent),
    location: location ?? '',
    description: description ?? '',
  );
}

/// `EducationDto` — `POST /api/social/Education`.
class EducationDto {
  const EducationDto({
    required this.school,
    this.degree,
    this.fieldOfStudy,
    this.startDate,
    this.endDate,
  });

  factory EducationDto.fromJson(Map<String, dynamic> json) => EducationDto(
    school: '${json['school'] ?? ''}',
    degree: json['degree'] as String?,
    fieldOfStudy: json['fieldOfStudy'] as String?,
    startDate: DateTime.tryParse('${json['startDate']}'),
    endDate: DateTime.tryParse('${json['endDate']}'),
  );

  final String school;
  final String? degree;
  final String? fieldOfStudy;
  final DateTime? startDate;
  final DateTime? endDate;

  Education toDomain() => Education(
    school: school,
    monogram: monogramOf(school),
    // The row shows one line, so the field of study rides along with the
    // degree rather than claiming a line of its own.
    degree: [
      if (degree != null && degree!.isNotEmpty) degree!,
      if (fieldOfStudy != null && fieldOfStudy!.isNotEmpty) fieldOfStudy!,
    ].join(' · '),
    dates: formatDateRangeArabic(startDate, endDate, false),
  );
}

/// `SkillDto` — `POST /api/social/Skills`.
class SkillDto {
  const SkillDto({
    required this.id,
    required this.name,
    this.endorsementCount = 0,
    this.isEndorsedByMe = false,
  });

  factory SkillDto.fromJson(Map<String, dynamic> json) => SkillDto(
    id: (json['id'] as num?)?.toInt() ?? 0,
    name: '${json['name'] ?? ''}',
    endorsementCount: (json['endorsementCount'] as num?)?.toInt() ?? 0,
    isEndorsedByMe: json['isEndorsedByMe'] == true,
  );

  final int id;
  final String name;
  final int endorsementCount;
  final bool isEndorsedByMe;

  Skill toDomain() => Skill(
    id: id,
    name: name,
    endorsements: endorsementCount,
    endorsedByMe: isEndorsedByMe,
  );
}

/// Two-letter monogram for the logo tile beside a company or school.
///
/// The backend stores no logo, so the tile is generated from the name — the
/// same trick the avatar uses for people.
String monogramOf(String name) {
  final parts = name
      .trim()
      .split(RegExp(r'\s+'))
      .where((p) => p.isNotEmpty)
      .toList();
  if (parts.isEmpty) return '؟';
  if (parts.length == 1) {
    return parts.first.length <= 2 ? parts.first : parts.first.substring(0, 2);
  }
  return '${parts.first.substring(0, 1)}${parts[1].substring(0, 1)}';
}
