import 'package:flutter_mobile_template/core/error/app_exception.dart';
import 'package:flutter_mobile_template/core/error/result.dart';
import 'package:flutter_mobile_template/features/shared/people/data/repositories/people_mock_repository.dart';

import '../../domain/entities/profile.dart';
import '../../domain/repositories/profile_repository.dart';

class ProfileMockRepository implements ProfileRepository {
  ProfileMockRepository({this.latency = const Duration(milliseconds: 240)})
      : _profiles = {for (final p in _seed()) p.personId: p};

  final Duration latency;
  final Map<String, Profile> _profiles;

  Future<void> _wait() => Future<void>.delayed(latency);

  static List<Profile> _seed() => const [
        Profile(
          personId: 'me',
          // The profile screen asks the profile whether it is the caller's —
          // against the real API that flag is resolved server-side from the
          // token, so the mock has to state it too or "me" renders as a
          // stranger with a Follow button.
          isMe: true,
          displayName: 'أنت',
          about:
              'مصمم منتجات أول يركّز على تجارب مالية جديرة بالثقة. أهتم بالواجهات الهادئة والأنظمة '
              'الواضحة والعمل الذي يحترم وقت الناس وانتباههم. متاح حالياً لأدوار تصميم أولى أو قيادية.',
          industry: 'التصميم',
          openToWork: true,
          connectionCount: 842,
          followerCount: 3400,
          followingCount: 512,
          postCount: 96,
          experience: [
            Experience(
              role: 'مصمم منتجات أول',
              company: 'كوبالت المالية',
              monogram: 'ك',
              dates: '٢٠٢٢ — الآن · ٣ سنوات',
              location: 'الرياض، السعودية',
              description:
                  'المصمم الرئيسي لمنتجات التمويل والمدفوعات. بنيت نظام التصميم المستخدم اليوم في '
                  'أكثر من ٤٠ واجهة.',
            ),
            Experience(
              role: 'مصمم منتجات',
              company: 'نورثويند',
              monogram: 'ن',
              dates: '٢٠١٩ — ٢٠٢٢ · ٣ سنوات',
              location: 'جدة، السعودية',
            ),
            Experience(
              role: 'مصمم تجربة مستخدم',
              company: 'برايت لاين',
              monogram: 'ب',
              dates: '٢٠١٧ — ٢٠١٩ · سنتان',
              location: 'عن بُعد',
            ),
          ],
          education: [
            Education(
              school: 'جامعة الملك سعود',
              monogram: 'ج',
              degree: 'بكالوريوس فنون، التصميم الجرافيكي',
              dates: '٢٠١٣ — ٢٠١٧',
            ),
          ],
          skills: [
            Skill(id: 1, name: 'أنظمة التصميم', endorsements: 38),
            Skill(id: 2, name: 'النماذج التفاعلية', endorsements: 27),
            Skill(id: 3, name: 'فيغما', endorsements: 52),
            Skill(id: 4, name: 'بحوث تجربة المستخدم', endorsements: 19),
            Skill(id: 5, name: 'التقنية المالية', endorsements: 14),
            Skill(id: 6, name: 'إمكانية الوصول', endorsements: 11),
          ],
        ),
        Profile(
          personId: 'amal',
          about:
              'مديرة هندسة تبني فرقاً هادئة تعمل بالتزامن المرن. أكتب كثيراً، أُطلق بثبات، وأوظّف '
              'بحثاً عن الفضول لا الشهادات.',
          industry: 'الهندسة',
          hiring: true,
          connectionCount: 1900,
          followerCount: 6200,
          followingCount: 340,
          postCount: 210,
          experience: [
            Experience(
              role: 'مديرة هندسة',
              company: 'نورثويند',
              monogram: 'ن',
              dates: '٢٠٢١ — الآن · ٤ سنوات',
              location: 'جدة، السعودية',
              description:
                  'أقود فريق منصة من ١٢ شخصاً. أعدت تصميم دورة التوظيف فقلّ زمن انتظار المرشحين ٤٠٪.',
            ),
            Experience(
              role: 'مهندسة رئيسية',
              company: 'لوب ورك',
              monogram: 'ل',
              dates: '٢٠١٨ — ٢٠٢١ · ٣ سنوات',
              location: 'عن بُعد',
            ),
          ],
          education: [
            Education(
              school: 'جامعة الملك فهد للبترول والمعادن',
              monogram: 'ف',
              degree: 'ماجستير علوم حاسب',
              dates: '٢٠١٤ — ٢٠١٦',
            ),
          ],
          skills: [
            Skill(id: 7, name: 'قيادة الفرق', endorsements: 61),
            Skill(id: 8, name: 'الأنظمة الموزّعة', endorsements: 44),
            Skill(id: 9, name: 'التوظيف', endorsements: 33),
            Skill(id: 10, name: 'لغة Go', endorsements: 28),
          ],
        ),
      ];

  /// People without a hand-written profile still need a full screen, so a
  /// plausible record is derived from their directory entry.
  Profile _fallback(String personId) {
    final matches = PeopleMockRepository.seed.where((p) => p.id == personId);
    final headline = matches.isEmpty ? '' : matches.first.headline;
    final location = matches.isEmpty ? '' : matches.first.location;
    return Profile(
      personId: personId,
      about: '$headline. شغوف بالعمل الجيد مع أشخاص مميزين.',
      connectionCount: 428,
      followerCount: 1100,
      followingCount: 263,
      postCount: 37,
      experience: [
        Experience(
          role: headline.split(' · ').first,
          company: '—',
          monogram: '؟',
          dates: '٢٠٢٠ — الآن',
          location: location,
        ),
      ],
      education: const [
        Education(
          school: 'الجامعة الوطنية',
          monogram: 'ج',
          degree: 'بكالوريوس',
          dates: '٢٠١٢ — ٢٠١٦',
        ),
      ],
      skills: const [
        Skill(id: 11, name: 'التواصل', endorsements: 12),
        Skill(id: 12, name: 'القيادة', endorsements: 8),
      ],
    );
  }

  @override
  Future<Result<Profile, AppException>> byPerson(String personId) async {
    await _wait();
    final known = PeopleMockRepository.seed.any((p) => p.id == personId);
    if (!known) {
      return Result.failure(NotFoundException('لا يوجد ملف بالمعرف $personId'));
    }
    return Result.success(
      _profiles.putIfAbsent(personId, () => _fallback(personId)),
    );
  }

  @override
  Future<Result<Profile, AppException>> updateMe(
    Map<String, dynamic> body,
  ) async {
    await _wait();
    final current = _profiles['me']!;
    final next = current.copyWith(
      about: body['about'] as String?,
      industry: body['industry'] as String?,
      openToWork: body['openToWork'] as bool?,
      isPrivate: body['isPrivate'] as bool?,
    );
    _profiles['me'] = next;
    return Result.success(next);
  }

  @override
  Future<Result<Profile, AppException>> toggleFollow(
    String personId, {
    bool? isFollowing,
  }) async {
    await _wait();
    final current = _profiles[personId] ?? _fallback(personId);
    final next = current.copyWith(following: !current.following);
    _profiles[personId] = next;
    return Result.success(next);
  }

  @override
  Future<Result<Profile, AppException>> connect(String personId) =>
      _connectionState(personId, outgoing: true);

  @override
  Future<Result<Profile, AppException>> acceptConnection(String personId) =>
      _connectionState(personId, connected: true);

  @override
  Future<Result<Profile, AppException>> ignoreConnection(String personId) =>
      _connectionState(personId);

  @override
  Future<Result<Profile, AppException>> removeConnection(String personId) =>
      _connectionState(personId);

  Future<Result<Profile, AppException>> _connectionState(
    String personId, {
    bool connected = false,
    bool outgoing = false,
  }) async {
    await _wait();
    final current = _profiles[personId] ?? _fallback(personId);
    final next = current.copyWith(
      connected: connected,
      connectionOutgoing: outgoing,
      connectionIncoming: false,
    );
    _profiles[personId] = next;
    return Result.success(next);
  }

  @override
  Future<Result<Profile, AppException>> endorseSkill({
    required String personId,
    required int skillId,
  }) async {
    await _wait();
    final current = _profiles[personId] ?? _fallback(personId);
    final next = current.copyWith(
      skills: [
        for (final s in current.skills)
          if (s.id == skillId)
            s.copyWith(endorsements: s.endorsements + 1)
          else
            s,
      ],
    );
    _profiles[personId] = next;
    return Result.success(next);
  }
}
