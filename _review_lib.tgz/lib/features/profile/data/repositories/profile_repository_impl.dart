import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:flutter_mobile_template/core/api/api_client.dart';
import 'package:flutter_mobile_template/core/api/api_envelope.dart';
import 'package:flutter_mobile_template/core/api/endpoints.dart';
import 'package:flutter_mobile_template/core/error/app_exception.dart';
import 'package:flutter_mobile_template/core/error/result.dart';
import 'package:flutter_mobile_template/core/providers.dart';

import '../../domain/entities/profile.dart';
import '../../domain/repositories/profile_repository.dart';
import '../dtos/profile_dto.dart';

/// Profiles against the RoboByte.SocialMedia module.
///
/// A profile screen is four endpoints, not one: the profile itself plus
/// experience, education and skills. They are issued together and the CV
/// sections degrade to empty on failure — a skills outage should not blank a
/// profile.
class ProfileRepositoryImpl implements ProfileRepository {
  ProfileRepositoryImpl({required ApiClient apiClient}) : _api = apiClient;

  final ApiClient _api;

  @override
  Future<Result<Profile, AppException>> byPerson(String personId) async {
    final isMe = personId == ProfileRepository.meSentinel;
    final path = isMe ? EndPoints.profilesMe : EndPoints.profileById(personId);

    final result = await apiCall(
      path,
      () => _api.dio.get<dynamic>(path),
      // Both endpoints answer through the same paged read, so the profile
      // arrives as a one-element list rather than a bare object.
      (envelope) {
        final rows = envelope.list;
        if (rows.isEmpty) {
          throw const NotFoundException('لم يُعثر على هذا الملف الشخصي');
        }
        return ProfileDto.fromJson(rows.first);
      },
    );

    return result.flatMapAsync((dto) async {
      final sections = await _sections(dto.id);
      return Result.success(
        dto.toDomain(
          experience: sections.experience,
          education: sections.education,
          skills: sections.skills,
        ),
      );
    });
  }

  /// The three CV lists, in flight together.
  Future<_CvSections> _sections(String profileId) async {
    final experience = _section(
      EndPoints.experience,
      profileId,
      (j) => ExperienceDto.fromJson(j).toDomain(),
    );
    final education = _section(
      EndPoints.education,
      profileId,
      (j) => EducationDto.fromJson(j).toDomain(),
    );
    final skills = _section(
      EndPoints.skills,
      profileId,
      (j) => SkillDto.fromJson(j).toDomain(),
    );

    return _CvSections(
      experience: await experience,
      education: await education,
      skills: await skills,
    );
  }

  /// One CV section. Failures come back as an empty list on purpose: the
  /// profile is still worth showing without its skills.
  Future<List<T>> _section<T>(
    String path,
    String profileId,
    T Function(Map<String, dynamic> json) map,
  ) async {
    final result = await apiCall(
      path,
      () => _api.dio.post<dynamic>(
        path,
        data: {'profileId': profileId},
        queryParameters: {'page': 1, 'size': 100},
      ),
      (envelope) => envelope.list.map(map).toList(growable: false),
    );
    return result.valueOrNull ?? <T>[];
  }

  @override
  Future<Result<Profile, AppException>> toggleFollow(
    String personId, {
    bool? isFollowing,
  }) async {
    var following = isFollowing;
    if (following == null) {
      final current = await byPerson(personId);
      if (current.isFailure) return current;
      following = current.valueOrNull!.following;
    }

    final path = following
        ? EndPoints.profileUnfollow
        : EndPoints.profileFollow;

    // The response is a `FollowStateDto` — `{ isFollowing, pending,
    // followerCount }` — not a profile, so the profile is re-read afterwards
    // rather than patched from a partial payload.
    final acted = await apiCall(
      path,
      () => _api.dio.post<dynamic>(
        path,
        queryParameters: {'targetId': personId},
      ),
      (envelope) => envelope.object,
    );

    return acted.flatMapAsync((_) => byPerson(personId));
  }

  @override
  Future<Result<Profile, AppException>> connect(String personId) =>
      _connectionAction(EndPoints.connectionsConnect, 'targetId', personId);

  @override
  Future<Result<Profile, AppException>> acceptConnection(String personId) =>
      // The parameter is the REQUESTER here, not the target — accepting is
      // answering someone else's request.
      _connectionAction(EndPoints.connectionsAccept, 'requesterId', personId);

  @override
  Future<Result<Profile, AppException>> ignoreConnection(String personId) =>
      _connectionAction(EndPoints.connectionsIgnore, 'requesterId', personId);

  @override
  Future<Result<Profile, AppException>> removeConnection(String personId) =>
      _connectionAction(EndPoints.connectionsRemove, 'targetId', personId);

  /// Runs one connection action and re-reads the profile.
  ///
  /// The endpoints answer a `ConnectionStateDto` — `{ connected, incoming,
  /// outgoing, connectionCount }` — not a profile, so rather than patching a
  /// partial payload into the screen's model the profile is read back. It also
  /// keeps the counts honest, since connecting moves `connectionCount` too.
  Future<Result<Profile, AppException>> _connectionAction(
    String path,
    String parameter,
    String personId,
  ) async {
    final acted = await apiCall(
      path,
      () => _api.dio.post<dynamic>(
        path,
        queryParameters: {parameter: personId},
      ),
      (envelope) => envelope.object,
    );
    return acted.flatMapAsync((_) => byPerson(personId));
  }

  @override
  Future<Result<Profile, AppException>> endorseSkill({
    required String personId,
    required int skillId,
  }) async {
    final acted = await apiCall(
      EndPoints.skillsEndorse,
      () => _api.dio.post<dynamic>(
        EndPoints.skillsEndorse,
        queryParameters: {'skillId': skillId},
      ),
      (envelope) => envelope.data,
    );
    return acted.flatMapAsync((_) => byPerson(personId));
  }

  /// The module exposes no profile-update endpoint — profile rows are written
  /// through the Kernel's generic write engine.
  ///
  /// Two consequences worth knowing: the row id has to be resolved first
  /// (hence the `Me` read), and `GenericWrite` writes exactly the columns it is
  /// given with no module-level validation, so only edited fields are sent and
  /// the column names must match `ProfileModel` — not the DTO.
  @override
  Future<Result<Profile, AppException>> updateMe(
    Map<String, dynamic> body,
  ) async {
    final me = await byPerson(ProfileRepository.meSentinel);
    if (me.isFailure) return me;
    final profileId = me.valueOrNull!.personId;

    final fields = <String, dynamic>{
      if (body.containsKey('name')) 'DisplayName': body['name'],
      if (body.containsKey('headline')) 'Headline': body['headline'],
      if (body.containsKey('industry')) 'Industry': body['industry'],
      if (body.containsKey('location')) 'Location': body['location'],
      if (body.containsKey('about')) 'About': body['about'],
      if (body.containsKey('bio')) 'Bio': body['bio'],
      if (body.containsKey('website')) 'Website': body['website'],
      if (body.containsKey('avatarUrl')) 'AvatarUrl': body['avatarUrl'],
      if (body.containsKey('openToWork')) 'IsOpenToWork': body['openToWork'],
      if (body.containsKey('isPrivate')) 'IsPrivate': body['isPrivate'],
      if (body['accountType'] is AccountType)
        'AccountType': ProfileDto.accountTypeToWire(
          body['accountType'] as AccountType,
        ),
    };

    if (fields.isEmpty) return me;

    final saved = await apiCall(
      EndPoints.genericWriteSave,
      () => _api.dio.post<dynamic>(
        EndPoints.genericWriteSave,
        data: [
          {
            // The Kernel README's example uses a fully-qualified type name,
            // but the module's own writes pass the simple one
            // (`nameof(PostModel)`) to the same service, so it resolves. If a
            // Kernel upgrade ever tightens that, this becomes
            // 'RoboByte.SocialMedia.Domain.Entities.Profile.ProfileModel'.
            'model': 'ProfileModel',
            'id': profileId,
            // Sent BY NAME, and WriteTypeEnum is 1-based (Create = 1), so the
            // ordinal for "update" would be 2 — send the name and neither trap
            // applies. Getting this wrong inserts a profile instead of editing
            // one.
            'writeType': 'Update',
            'fields': {'Id': profileId, ...fields},
          },
        ],
      ),
      (envelope) => envelope.data,
    );

    return saved.flatMapAsync(
      (_) => byPerson(ProfileRepository.meSentinel),
    );
  }
}

class _CvSections {
  const _CvSections({
    required this.experience,
    required this.education,
    required this.skills,
  });

  final List<Experience> experience;
  final List<Education> education;
  final List<Skill> skills;
}

final profileRepositoryProvider = Provider<ProfileRepository>((ref) {
  return ProfileRepositoryImpl(apiClient: ref.watch(apiClientProvider));
});
