import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import 'package:flutter_mobile_template/core/error/app_exception.dart';
import 'package:flutter_mobile_template/core/error/result.dart';
import 'package:flutter_mobile_template/core/theme/rung_colors.dart';
import 'package:flutter_mobile_template/core/theme/rung_tokens.dart';
import 'package:flutter_mobile_template/core/utils/arabic_numbers.dart';
import 'package:flutter_mobile_template/core/utils/error_messages.dart';
import 'package:flutter_mobile_template/core/widgets/error_view.dart';
import 'package:flutter_mobile_template/core/widgets/loading_view.dart';
import 'package:flutter_mobile_template/core/widgets/rung/rung.dart';
import 'package:flutter_mobile_template/features/shared/people/data/repositories/people_repository_impl.dart';
import 'package:flutter_mobile_template/features/shared/people/domain/entities/person.dart';
import 'package:flutter_mobile_template/l10n/l10n.dart';

import '../../domain/entities/profile.dart';
import '../notifiers/profile_notifier.dart';

/// Height of the gradient cover *below* the status bar. The status-bar inset
/// is added on top of it (see [_coverHeight]) so the header controls sit in
/// their own band instead of colliding with the notch or with the avatar,
/// which straddles the bottom of the cover.
const double _kCoverVisibleHeight = 132;

/// Distance the avatar hangs below the cover seam.
const double _kAvatarOverhang = 44;

double _coverHeight(BuildContext context) =>
    _kCoverVisibleHeight + MediaQuery.paddingOf(context).top;

class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key, required this.personId});

  final String personId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final c = context.rung;
    final profile = ref.watch(profileNotifierProvider(personId));
    // The directory is one page of profiles, so a miss here is normal — the
    // profile payload itself carries the name, headline and location.
    final directoryPerson = ref
        .watch(peopleDirectoryProvider)
        .valueOrNull?[personId];

    return Scaffold(
      backgroundColor: c.bg,
      body: profile.when(
        loading: () => const LoadingView(),
        error: (e, _) => ErrorView(
          error: e,
          onRetry: () =>
              ref.read(profileNotifierProvider(personId).notifier).refresh(),
        ),
        data: (data) =>
            _Body(profile: data, person: directoryPerson ?? data.person),
      ),
    );
  }
}

class _Body extends ConsumerWidget {
  const _Body({required this.profile, required this.person});

  final Profile profile;
  final Person person;

  /// Resolved server-side from the bearer token — the client cannot tell by
  /// comparing ids, because its own ProfileId is not in the auth token.
  bool get _isMe => profile.isMe;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final c = context.rung;
    final l10n = context.l10n;
    final coverHeight = _coverHeight(context);

    return ListView(
      padding: const EdgeInsets.only(bottom: 28),
      children: [
        // The avatar straddles the cover/surface seam, so the header is a
        // Stack: the column reserves top padding for the overlap and the
        // avatar is positioned across the boundary.
        Stack(
          clipBehavior: Clip.none,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _Cover(personId: person.id),
                Container(
                  width: double.infinity,
                  color: c.surface,
                  margin: const EdgeInsets.only(bottom: RungSpace.sectionGap),
                  padding: const EdgeInsets.fromLTRB(
                    RungSpace.gutter,
                    52,
                    RungSpace.gutter,
                    RungSpace.gutter,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Flexible(
                            child: Text(
                              person.name,
                              style: const TextStyle(
                                fontSize: 21,
                                fontWeight: FontWeight.w800,
                                letterSpacing: -0.3,
                              ),
                            ),
                          ),
                          if (person.verified) ...[
                            const SizedBox(width: 6),
                            const VerifiedBadge(size: 18),
                          ],
                        ],
                      ),
                      const SizedBox(height: 3),
                      Text(
                        person.headline,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                          color: c.ink2,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Icon(Icons.place_outlined, size: 13, color: c.ink3),
                          const SizedBox(width: 5),
                          Flexible(
                            child: Text(
                              person.location,
                              style: TextStyle(fontSize: 12.5, color: c.ink3),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: RungSpace.sm),
                      Row(
                        children: [
                          _CountStat(
                            value: profile.connectionCount,
                            label: l10n.profileConnections,
                            onTap: () => context.push('/network'),
                          ),
                          const SizedBox(width: 18),
                          _CountStat(
                            value: profile.followerCount,
                            label: l10n.profileFollowers,
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      _Actions(profile: profile, person: person, isMe: _isMe),
                    ],
                  ),
                ),
              ],
            ),
            PositionedDirectional(
              start: RungSpace.gutter,
              top: coverHeight - _kAvatarOverhang,
              child: RungAvatar(
                seed: person.id,
                initials: person.initials,
                size: 88,
                borderColor: c.surface,
                borderWidth: 4,
              ),
            ),
            if (profile.openToWork)
              PositionedDirectional(
                end: RungSpace.gutter,
                top: coverHeight + 8,
                child: RungStatusPill.success(
                  context,
                  label: l10n.profileOpenToWork,
                  leading: RungDot(color: c.green),
                ),
              )
            else if (profile.hiring)
              PositionedDirectional(
                end: RungSpace.gutter,
                top: coverHeight + 8,
                child: RungStatusPill.accent(
                  context,
                  label: '✦ ${l10n.profileHiring}',
                ),
              ),
          ],
        ),
        RungSection(
          title: l10n.profileAbout,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                profile.about,
                style: TextStyle(fontSize: 13.5, height: 1.55, color: c.ink2),
              ),
              if (_isMe) ...[
                const SizedBox(height: RungSpace.sm),
                TextButton.icon(
                  onPressed: () => showRungToast(context, l10n.comingSoon),
                  icon: const Icon(Icons.download_outlined, size: 15),
                  label: Text(l10n.profileDownloadCv),
                  style: TextButton.styleFrom(
                    padding: EdgeInsets.zero,
                    minimumSize: const Size(0, 32),
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  ),
                ),
              ],
            ],
          ),
        ),
        if (profile.experience.isNotEmpty)
          RungSection(
            title: l10n.profileExperience,
            child: Column(
              children: [
                for (final item in profile.experience)
                  _ExperienceRow(item: item),
              ],
            ),
          ),
        if (profile.education.isNotEmpty)
          RungSection(
            title: l10n.profileEducation,
            child: Column(
              children: [
                for (final item in profile.education) _EducationRow(item: item),
              ],
            ),
          ),
        if (profile.skills.isNotEmpty)
          RungSection(
            title: l10n.profileSkills,
            gapBelow: 0,
            child: Column(
              children: [
                for (final skill in profile.skills)
                  _SkillRow(skill: skill, personId: person.id),
              ],
            ),
          ),
      ],
    );
  }
}

class _Cover extends StatelessWidget {
  const _Cover({required this.personId});

  final String personId;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: _coverHeight(context),
      child: Stack(
        fit: StackFit.expand,
        children: [
          DecoratedBox(
            decoration: BoxDecoration(
              gradient: personId == 'me'
                  ? RungGradients.brand
                  : RungGradients.forSeed('cover-$personId'),
            ),
          ),
          PositionedDirectional(
            top: MediaQuery.paddingOf(context).top,
            start: 0,
            end: 0,
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: RungSpace.gutter,
                vertical: 8,
              ),
              child: Row(
                children: [
                  _OverlayButton(
                    icon: Icons.chevron_left,
                    onTap: () =>
                        context.canPop() ? context.pop() : context.go('/feed'),
                    tooltip: MaterialLocalizations.of(context).backButtonTooltip,
                  ),
                  const Spacer(),
                  _OverlayButton(
                    icon: Icons.more_horiz,
                    onTap: () => showRungToast(context, context.l10n.comingSoon),
                    tooltip:
                        MaterialLocalizations.of(context).moreButtonTooltip,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _OverlayButton extends StatelessWidget {
  const _OverlayButton({
    required this.icon,
    required this.onTap,
    required this.tooltip,
  });

  final IconData icon;
  final VoidCallback onTap;
  final String tooltip;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: tooltip,
      child: InkWell(
        onTap: onTap,
        customBorder: const CircleBorder(),
        child: Container(
          width: 36,
          height: 36,
          alignment: Alignment.center,
          decoration: const BoxDecoration(
            color: Color(0x660F172A),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, size: 20, color: Colors.white),
        ),
      ),
    );
  }
}

class _CountStat extends StatelessWidget {
  const _CountStat({required this.value, required this.label, this.onTap});

  final int value;
  final String label;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final c = context.rung;
    return GestureDetector(
      onTap: onTap,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            ArabicNumbers.compact(value),
            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
          ),
          const SizedBox(width: 4),
          Text(label, style: TextStyle(fontSize: 12, color: c.ink3)),
        ],
      ),
    );
  }
}

class _Actions extends ConsumerWidget {
  const _Actions({
    required this.profile,
    required this.person,
    required this.isMe,
  });

  final Profile profile;
  final Person person;
  final bool isMe;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final c = context.rung;
    final l10n = context.l10n;

    if (isMe) {
      return Row(
        children: [
          Expanded(
            child: FilledButton(
              onPressed: () => context.push('/profile/me/edit'),
              style: FilledButton.styleFrom(minimumSize: const Size(0, 42)),
              child: Text(l10n.profileEdit),
            ),
          ),
          const SizedBox(width: 8),
          SizedBox(
            width: 42,
            height: 42,
            child: OutlinedButton(
              onPressed: () => context.push('/feed/composer'),
              style: OutlinedButton.styleFrom(
                padding: EdgeInsets.zero,
                minimumSize: Size.zero,
                side: BorderSide(color: c.line2, width: 1.5),
                foregroundColor: c.ink2,
              ),
              child: const Icon(Icons.add, size: 19),
            ),
          ),
        ],
      );
    }

    return Row(
      children: [
        Expanded(
          child: FilledButton(
            onPressed: () async {
              final wasFollowing = profile.following;
              final result = await ref
                  .read(profileNotifierProvider(person.id).notifier)
                  .toggleFollow();
              if (!context.mounted) return;
              result.when(
                success: (_) => showRungToast(
                  context,
                  wasFollowing
                      ? l10n.toastUnfollowed
                      : l10n.toastFollowing(person.firstName),
                ),
                failure: (e) => showRungToast(
                  context,
                  arabicMessageForException(e),
                  success: false,
                ),
              );
            },
            style: FilledButton.styleFrom(minimumSize: const Size(0, 42)),
            // A private profile answers a follow with a REQUEST, not a follow:
            // `following` stays false while `followRequestPending` is true, and
            // a button still reading "follow" invites the same tap forever.
            child: Text(
              profile.following
                  ? l10n.profileUnfollow
                  : profile.followRequestPending
                  ? l10n.profileFollowRequested
                  : l10n.profileFollow,
            ),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: _ConnectButton(profile: profile, person: person),
        ),
        const SizedBox(width: 8),
        SizedBox(
          width: 42,
          height: 42,
          child: OutlinedButton(
            onPressed: () => context.push('/messages'),
            style: OutlinedButton.styleFrom(
              padding: EdgeInsets.zero,
              minimumSize: Size.zero,
              side: BorderSide(color: c.line2, width: 1.5),
              foregroundColor: c.ink2,
            ),
            child: const Icon(Icons.chat_bubble_outline_rounded, size: 19),
          ),
        ),
      ],
    );
  }
}

class _ExperienceRow extends StatelessWidget {
  const _ExperienceRow({required this.item});

  final Experience item;

  @override
  Widget build(BuildContext context) {
    final c = context.rung;
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          RungLogoTile(
            seed: item.company,
            monogram: item.monogram,
            size: 46,
            radius: 11,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.role,
                  style: const TextStyle(
                    fontSize: 14.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                Text(
                  item.company,
                  style: TextStyle(fontSize: 13, color: c.ink2),
                ),
                Text(item.dates, style: TextStyle(fontSize: 12, color: c.ink3)),
                Text(
                  item.location,
                  style: TextStyle(fontSize: 12, color: c.ink3),
                ),
                if (item.hasDescription)
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text(
                      item.description,
                      style: TextStyle(
                        fontSize: 13,
                        height: 1.5,
                        color: c.ink2,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _EducationRow extends StatelessWidget {
  const _EducationRow({required this.item});

  final Education item;

  @override
  Widget build(BuildContext context) {
    final c = context.rung;
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          RungLogoTile(
            seed: item.school,
            monogram: item.monogram,
            size: 46,
            radius: 11,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.school,
                  style: const TextStyle(
                    fontSize: 14.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                Text(
                  item.degree,
                  style: TextStyle(fontSize: 13, color: c.ink2),
                ),
                Text(item.dates, style: TextStyle(fontSize: 12, color: c.ink3)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SkillRow extends ConsumerWidget {
  const _SkillRow({required this.skill, required this.personId});

  final Skill skill;
  final String personId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final c = context.rung;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  skill.name,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                Text(
                  context.l10n.profileEndorsements(
                    ArabicNumbers.count(skill.endorsements),
                  ),
                  style: TextStyle(fontSize: 12, color: c.ink3),
                ),
              ],
            ),
          ),
          OutlinedButton(
            onPressed: () => ref
                .read(profileNotifierProvider(personId).notifier)
                .endorse(skill.id),
            style: OutlinedButton.styleFrom(
              minimumSize: const Size(0, 34),
              padding: const EdgeInsets.symmetric(horizontal: 15),
              textStyle: const TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w700,
              ),
            ),
            child: Text(context.l10n.profileEndorse),
          ),
        ],
      ),
    );
  }
}

/// The "add" button, in whichever of its four states applies.
///
/// It used to be a toast and nothing else — tapping it told you a request was
/// sent, no request was sent, and the button still said "connect" afterwards.
/// Each state now maps to the action that makes sense from there, and the
/// label is driven by the server's own view of the edge
/// (`isConnected` / `connectionIncoming` / `connectionOutgoing` on ProfileDto),
/// so it survives a reopen of the screen rather than living in widget state.
class _ConnectButton extends ConsumerWidget {
  const _ConnectButton({required this.profile, required this.person});

  final Profile profile;
  final Person person;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = context.l10n;
    final notifier = ref.read(profileNotifierProvider(person.id).notifier);

    Future<void> run(
      Future<Result<Profile, AppException>> Function() action,
      String successMessage,
    ) async {
      final result = await action();
      if (!context.mounted) return;
      result.when(
        success: (_) => showRungToast(context, successMessage),
        failure: (e) =>
            showRungToast(context, arabicMessageForException(e), success: false),
      );
    }

    // Order matters: connected wins over any stale pending flag, and an
    // inbound request outranks the option to send one of your own.
    final (label, onPressed) = switch (profile) {
      Profile(connected: true) => (
        l10n.profileConnected,
        () => run(notifier.removeConnection, l10n.toastConnectionRemoved),
      ),
      Profile(connectionIncoming: true) => (
        l10n.profileConnectAccept,
        () => run(notifier.acceptConnection, l10n.toastConnectAccepted),
      ),
      Profile(connectionOutgoing: true) => (
        l10n.profileConnectSent,
        // Tapping again withdraws it — the same endpoint that removes an
        // accepted connection deletes a pending one.
        () => run(
          notifier.removeConnection,
          l10n.toastConnectRequestCancelled,
        ),
      ),
      _ => (
        l10n.profileConnect,
        () => run(
          notifier.connect,
          l10n.toastConnectRequestSent(person.firstName),
        ),
      ),
    };

    return OutlinedButton(
      onPressed: onPressed,
      style: OutlinedButton.styleFrom(minimumSize: const Size(0, 42)),
      child: Text(label),
    );
  }
}
