import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import 'package:flutter_mobile_template/core/theme/rung_colors.dart';
import 'package:flutter_mobile_template/core/theme/rung_tokens.dart';
import 'package:flutter_mobile_template/core/utils/error_messages.dart';
import 'package:flutter_mobile_template/core/widgets/error_view.dart';
import 'package:flutter_mobile_template/core/widgets/loading_view.dart';
import 'package:flutter_mobile_template/core/widgets/rung/rung.dart';
import 'package:flutter_mobile_template/features/shared/people/data/repositories/people_repository_impl.dart';
import 'package:flutter_mobile_template/l10n/l10n.dart';

import '../../domain/entities/profile.dart';
import '../notifiers/profile_notifier.dart';

class EditProfileScreen extends ConsumerStatefulWidget {
  const EditProfileScreen({super.key});

  @override
  ConsumerState<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends ConsumerState<EditProfileScreen> {
  final _name = TextEditingController();
  final _headline = TextEditingController();
  final _industry = TextEditingController();
  final _location = TextEditingController();
  final _about = TextEditingController();

  bool _openToWork = false;
  bool _isPrivate = false;
  bool _hydrated = false;
  bool _saving = false;

  @override
  void dispose() {
    for (final controller in [_name, _headline, _industry, _location, _about]) {
      controller.dispose();
    }
    super.dispose();
  }

  /// Seeds the form once, the first time both the person and profile land.
  /// Re-seeding on every rebuild would stomp on what the user is typing.
  void _hydrate(Profile profile) {
    if (_hydrated) return;
    final me = ref.read(currentPersonProvider).valueOrNull;
    if (me == null) return;

    _name.text = me.name;
    _headline.text = me.headline;
    _location.text = me.location;
    _industry.text = profile.industry;
    _about.text = profile.about;
    _openToWork = profile.openToWork;
    _isPrivate = profile.isPrivate;
    _hydrated = true;
  }

  Future<void> _save() async {
    if (_saving) return;
    setState(() => _saving = true);

    final result =
        await ref.read(profileNotifierProvider('me').notifier).save({
      'name': _name.text.trim(),
      'headline': _headline.text.trim(),
      'industry': _industry.text.trim(),
      'location': _location.text.trim(),
      'about': _about.text.trim(),
      'openToWork': _openToWork,
      'isPrivate': _isPrivate,
    });

    if (!mounted) return;
    setState(() => _saving = false);

    result.when(
      success: (_) {
        showRungToast(context, context.l10n.toastProfileUpdated);
        if (context.canPop()) context.pop();
      },
      failure: (e) =>
          showRungToast(context, arabicMessageForException(e), success: false),
    );
  }

  @override
  Widget build(BuildContext context) {
    final c = context.rung;
    final l10n = context.l10n;
    final profile = ref.watch(profileNotifierProvider('me'));
    final me = ref.watch(currentPersonProvider).valueOrNull;

    return Scaffold(
      backgroundColor: c.surface,
      appBar: RungAppBar(
        showBack: false,
        leading: TextButton(
          onPressed: () =>
              context.canPop() ? context.pop() : context.go('/profile/me'),
          style: TextButton.styleFrom(foregroundColor: c.ink2),
          child: Text(l10n.actionCancel),
        ),
        title: l10n.editProfileTitle,
        actions: [
          TextButton(
            onPressed: _saving ? null : _save,
            child: _saving
                ? SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: c.accent,
                    ),
                  )
                : Text(l10n.actionSave),
          ),
        ],
      ),
      body: profile.when(
        loading: () => const LoadingView(),
        error: (e, _) => ErrorView(
          error: e,
          onRetry: () =>
              ref.read(profileNotifierProvider('me').notifier).refresh(),
        ),
        data: (data) {
          _hydrate(data);
          return ListView(
            padding: EdgeInsets.zero,
            children: [
              SizedBox(
                height: 110,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    const DecoratedBox(
                      decoration: BoxDecoration(gradient: RungGradients.brand),
                    ),
                    Center(
                      child: _CircleAction(
                        icon: Icons.photo_camera_outlined,
                        onTap: () => showRungToast(context, l10n.comingSoon),
                        tooltip: l10n.comingSoon,
                      ),
                    ),
                  ],
                ),
              ),
              Transform.translate(
                offset: const Offset(0, -34),
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: RungSpace.gutter,
                  ),
                  child: Align(
                    alignment: AlignmentDirectional.centerStart,
                    child: Stack(
                      clipBehavior: Clip.none,
                      children: [
                        RungAvatar(
                          seed: me?.id ?? 'me',
                          initials: me?.initials ?? '—',
                          size: 76,
                          borderColor: c.surface,
                          borderWidth: 4,
                        ),
                        PositionedDirectional(
                          bottom: 0,
                          end: 0,
                          child: Container(
                            width: 26,
                            height: 26,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: c.accent,
                              shape: BoxShape.circle,
                              border: Border.all(color: c.surface, width: 2),
                            ),
                            child: const Icon(
                              Icons.edit,
                              size: 13,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(
                  RungSpace.gutter,
                  0,
                  RungSpace.gutter,
                  RungSpace.lg,
                ),
                child: Column(
                  children: [
                    RungField(
                      label: l10n.editProfileFullName,
                      controller: _name,
                    ),
                    const SizedBox(height: RungSpace.md),
                    RungField(
                      label: l10n.editProfileHeadline,
                      controller: _headline,
                    ),
                    const SizedBox(height: RungSpace.md),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: RungField(
                            label: l10n.editProfileIndustry,
                            controller: _industry,
                          ),
                        ),
                        const SizedBox(width: RungSpace.sm),
                        Expanded(
                          child: RungField(
                            label: l10n.editProfileLocation,
                            controller: _location,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: RungSpace.md),
                    RungField(
                      label: l10n.editProfileAbout,
                      controller: _about,
                      maxLines: 5,
                      height: 110,
                    ),
                    const SizedBox(height: RungSpace.md),
                    RungToggleTile(
                      title: l10n.editProfileOpenToWorkTitle,
                      subtitle: l10n.editProfileOpenToWorkSubtitle,
                      leading: RungDot(color: c.green),
                      value: _openToWork,
                      onChanged: (v) => setState(() => _openToWork = v),
                    ),
                    const SizedBox(height: RungSpace.md),
                    RungToggleTile(
                      title: l10n.editProfilePrivateTitle,
                      subtitle: l10n.editProfilePrivateSubtitle,
                      value: _isPrivate,
                      onChanged: (v) => setState(() => _isPrivate = v),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _CircleAction extends StatelessWidget {
  const _CircleAction({
    required this.icon,
    required this.onTap,
    required this.tooltip,
  });

  final IconData icon;
  final VoidCallback onTap;
  final String tooltip;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: tooltip,
      child: InkWell(
        onTap: onTap,
        customBorder: const CircleBorder(),
        child: Container(
          width: 40,
          height: 40,
          alignment: Alignment.center,
          decoration: const BoxDecoration(
            color: Color(0x40FFFFFF),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, size: 20, color: Colors.white),
        ),
      ),
    );
  }
}
