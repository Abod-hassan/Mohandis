import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:flutter_mobile_template/core/error/app_exception.dart';
import 'package:flutter_mobile_template/core/error/result.dart';

import '../../data/repositories/profile_repository_impl.dart';
import '../../domain/entities/profile.dart';
import '../../domain/repositories/profile_repository.dart';

/// One profile screen's state, keyed by person id.
class ProfileNotifier extends FamilyAsyncNotifier<Profile, String> {
  @override
  Future<Profile> build(String personId) async {
    final result =
        await ref.read(profileRepositoryProvider).byPerson(personId);
    return result.when(success: (p) => p, failure: (e) => throw e);
  }

  Future<void> refresh() async {
    state = const AsyncValue.loading();
    state = await AsyncValue.guard(() async {
      final result = await ref.read(profileRepositoryProvider).byPerson(arg);
      return result.when(success: (p) => p, failure: (e) => throw e);
    });
  }

  Future<Result<Profile, AppException>> toggleFollow() async {
    final current = state.valueOrNull;
    if (current != null) {
      state = AsyncValue.data(current.copyWith(following: !current.following));
    }
    // The backend has separate Follow and Unfollow actions rather than one
    // toggle, so the direction is passed explicitly — and from the state
    // BEFORE the optimistic flip above, not after it.
    final result = await ref
        .read(profileRepositoryProvider)
        .toggleFollow(arg, isFollowing: current?.following);
    result.when(
      success: (p) => state = AsyncValue.data(p),
      failure: (_) {
        if (current != null) state = AsyncValue.data(current);
      },
    );
    return result;
  }

  /// Sends a connection request.
  ///
  /// Optimistic on the way out — the button flips to "request sent" on tap —
  /// and reconciled with whatever the server reports, which for a private or
  /// already-connected profile may not be `outgoing` at all.
  Future<Result<Profile, AppException>> connect() => _connectionAction(
    (repository) => repository.connect(arg),
    optimistic: (p) => p.copyWith(connectionOutgoing: true),
  );

  Future<Result<Profile, AppException>> acceptConnection() =>
      _connectionAction(
        (repository) => repository.acceptConnection(arg),
        optimistic: (p) =>
            p.copyWith(connected: true, connectionIncoming: false),
      );

  Future<Result<Profile, AppException>> ignoreConnection() =>
      _connectionAction(
        (repository) => repository.ignoreConnection(arg),
        optimistic: (p) => p.copyWith(connectionIncoming: false),
      );

  /// Removes a connection, or withdraws a request that hasn't been answered.
  Future<Result<Profile, AppException>> removeConnection() =>
      _connectionAction(
        (repository) => repository.removeConnection(arg),
        optimistic: (p) =>
            p.copyWith(connected: false, connectionOutgoing: false),
      );

  Future<Result<Profile, AppException>> _connectionAction(
    Future<Result<Profile, AppException>> Function(ProfileRepository) call, {
    required Profile Function(Profile) optimistic,
  }) async {
    final current = state.valueOrNull;
    if (current != null) state = AsyncValue.data(optimistic(current));

    final result = await call(ref.read(profileRepositoryProvider));
    result.when(
      success: (p) => state = AsyncValue.data(p),
      failure: (_) {
        if (current != null) state = AsyncValue.data(current);
      },
    );
    return result;
  }

  /// Endorses one skill row. Addressed by the row's int id — a skill name is
  /// not unique across profiles.
  Future<Result<Profile, AppException>> endorse(int skillId) async {
    final result = await ref
        .read(profileRepositoryProvider)
        .endorseSkill(personId: arg, skillId: skillId);
    result.when(
      success: (p) => state = AsyncValue.data(p),
      failure: (_) {},
    );
    return result;
  }

  /// Saves the signed-in user's edits. Only valid on the `me` profile.
  Future<Result<Profile, AppException>> save(Map<String, dynamic> body) async {
    final result = await ref.read(profileRepositoryProvider).updateMe(body);
    result.when(
      success: (p) => state = AsyncValue.data(p),
      failure: (_) {},
    );
    return result;
  }
}

final profileNotifierProvider =
    AsyncNotifierProvider.family<ProfileNotifier, Profile, String>(
  ProfileNotifier.new,
);
