import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:flutter_mobile_template/core/base/base_list_notifier.dart';
import 'package:flutter_mobile_template/core/base/base_repository.dart';
import 'package:flutter_mobile_template/core/error/app_exception.dart';
import 'package:flutter_mobile_template/core/error/result.dart';

import '../../data/repositories/reel_repository_impl.dart';
import '../../domain/entities/reel.dart';

class ReelsNotifier extends BaseListNotifier<Reel> {
  @override
  BaseRepository<Reel> get repository => ref.read(reelRepositoryProvider);

  Future<Result<Reel, AppException>> toggleLike(String reelId) => _optimistic(
        reelId,
        (r) => r.toggleLike(),
        ref.read(reelRepositoryProvider).toggleLike,
      );

  Future<Result<Reel, AppException>> toggleSave(String reelId) => _optimistic(
        reelId,
        (r) => r.toggleSave(),
        ref.read(reelRepositoryProvider).toggleSave,
      );

  /// Counts a playback. Nothing in the list changes — the server owns the play
  /// count and only reports it on the next read — and a failure is
  /// deliberately silent: a lost counter must not throw an error banner over a
  /// reel the user is already watching.
  Future<void> markPlayed(String reelId) async {
    await ref.read(reelRepositoryProvider).markPlayed(reelId);
  }

  Future<Result<Reel, AppException>> _optimistic(
    String reelId,
    Reel Function(Reel) transform,
    Future<Result<Reel, AppException>> Function(String) call,
  ) async {
    final previous = state.valueOrNull;
    if (previous == null) return call(reelId);

    state = AsyncValue.data([
      for (final r in previous) r.id == reelId ? transform(r) : r,
    ]);

    final result = await call(reelId);
    return result.when(
      success: (server) {
        final current = state.valueOrNull ?? previous;
        state = AsyncValue.data([
          for (final r in current) r.id == server.id ? server : r,
        ]);
        return Result<Reel, AppException>.success(server);
      },
      failure: (e) {
        state = AsyncValue.data(previous);
        return Result<Reel, AppException>.failure(e);
      },
    );
  }
}

final reelsNotifierProvider =
    AsyncNotifierProvider<ReelsNotifier, List<Reel>>(ReelsNotifier.new);
