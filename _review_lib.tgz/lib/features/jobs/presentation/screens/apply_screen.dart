import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import 'package:flutter_mobile_template/core/theme/rung_colors.dart';
import 'package:flutter_mobile_template/core/theme/rung_tokens.dart';
import 'package:flutter_mobile_template/core/utils/error_messages.dart';
import 'package:flutter_mobile_template/core/widgets/error_view.dart';
import 'package:flutter_mobile_template/core/widgets/loading_view.dart';
import 'package:flutter_mobile_template/core/widgets/rung/rung.dart';
import 'package:flutter_mobile_template/features/shared/people/data/repositories/people_repository_impl.dart';
import 'package:flutter_mobile_template/l10n/l10n.dart';

import '../../domain/entities/job.dart';
import '../notifiers/jobs_notifier.dart';

/// Two-step application flow — résumé + cover letter, then review — followed
/// by a success state that replaces the form entirely.
class ApplyScreen extends ConsumerStatefulWidget {
  const ApplyScreen({super.key, required this.jobId});

  final String jobId;

  @override
  ConsumerState<ApplyScreen> createState() => _ApplyScreenState();
}

class _ApplyScreenState extends ConsumerState<ApplyScreen> {
  /// The résumé on file — a placeholder, and it stays one.
  ///
  /// The backend stores a `ResumeUrl` that the poster's applicant list opens
  /// as a link, and there is no endpoint anywhere in the module that accepts a
  /// document; `MediaUploadService` uploads images to the avatar zone only.
  /// So there is nothing to turn this name into a URL with, and it is NOT sent
  /// as one — a bare file name in that column resolves to nothing and would
  /// look, to the poster, like a CV that fails to open. The application goes
  /// up with its cover letter and no résumé until a document upload exists.
  static const _resumeFileName = 'يوسف_الحربي_السيرة_الذاتية.pdf';
  static const _resumeSize = '٢٨٤ ك.ب';

  final _cover = TextEditingController();
  int _step = 0;
  bool _submitting = false;
  bool _done = false;

  @override
  void dispose() {
    _cover.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_submitting) return;
    setState(() => _submitting = true);

    final result =
        await ref.read(applicationsNotifierProvider.notifier).apply(
              jobId: widget.jobId,
              coverLetter: _cover.text,
            );

    if (!mounted) return;
    setState(() => _submitting = false);

    result.when(
      success: (_) => setState(() => _done = true),
      failure: (e) =>
          showRungToast(context, arabicMessageForException(e), success: false),
    );
  }

  @override
  Widget build(BuildContext context) {
    final c = context.rung;
    final l10n = context.l10n;
    final job = ref.watch(jobDetailProvider(widget.jobId));

    return Scaffold(
      backgroundColor: c.surface,
      appBar: RungAppBar(
        showBack: false,
        leading: IconButton(
          onPressed: () => context.canPop() ? context.pop() : context.go('/jobs'),
          icon: const Icon(Icons.close, size: 22),
          color: c.ink,
          tooltip: l10n.actionCancel,
        ),
        title: l10n.applyTitle,
      ),
      body: job.when(
        loading: () => const LoadingView(),
        error: (e, _) => ErrorView(
          error: e,
          onRetry: () => ref.invalidate(jobDetailProvider(widget.jobId)),
        ),
        data: (data) => _done ? _successView(data) : _formView(data),
      ),
    );
  }

  Widget _successView(Job job) {
    final c = context.rung;
    final l10n = context.l10n;

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 88,
              height: 88,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: c.greenSoft,
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.check_rounded, size: 46, color: c.green),
            ),
            const SizedBox(height: 22),
            Text(
              l10n.applyDoneTitle,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 10),
            Text(
              l10n.applyDoneBody(job.title, job.company),
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14, height: 1.55, color: c.ink2),
            ),
            const SizedBox(height: 26),
            FilledButton(
              onPressed: () {
                showRungToast(context, l10n.toastApplicationSent);
                if (context.canPop()) context.pop();
              },
              style: FilledButton.styleFrom(
                minimumSize: const Size(0, 46),
                padding: const EdgeInsets.symmetric(horizontal: 34),
              ),
              child: Text(l10n.actionDone),
            ),
          ],
        ),
      ),
    );
  }

  Widget _formView(Job job) {
    final c = context.rung;
    final l10n = context.l10n;

    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(
              RungSpace.gutter,
              18,
              RungSpace.gutter,
              18,
            ),
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: c.surface2,
                  borderRadius: RungRadius.mdAll,
                  border: Border.all(color: c.line),
                ),
                child: Row(
                  children: [
                    RungLogoTile(
                      seed: job.company,
                      monogram: job.monogram,
                      size: 44,
                      radius: 11,
                    ),
                    const SizedBox(width: 11),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            job.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          Text(
                            '${job.company} · ${job.location}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(fontSize: 12, color: c.ink2),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(child: _progressBar(filled: true)),
                  const SizedBox(width: 8),
                  Expanded(child: _progressBar(filled: _step >= 1)),
                ],
              ),
              const SizedBox(height: 20),
              if (_step == 0) ..._resumeStep() else ..._reviewStep(job),
            ],
          ),
        ),
        SafeArea(
          top: false,
          child: Container(
            padding: const EdgeInsets.symmetric(
              horizontal: RungSpace.gutter,
              vertical: RungSpace.sm,
            ),
            decoration: BoxDecoration(
              border: Border(top: BorderSide(color: c.line)),
            ),
            child: FilledButton(
              onPressed: _submitting
                  ? null
                  : _step == 0
                      ? () => setState(() => _step = 1)
                      : _submit,
              child: _submitting
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : Text(_step == 0 ? l10n.actionContinue : l10n.applySubmit),
            ),
          ),
        ),
      ],
    );
  }

  Widget _progressBar({required bool filled}) {
    final c = context.rung;
    return Container(
      height: 4,
      decoration: BoxDecoration(
        color: filled ? c.accent : c.line2,
        borderRadius: BorderRadius.circular(2),
      ),
    );
  }

  List<Widget> _resumeStep() {
    final c = context.rung;
    final l10n = context.l10n;

    return [
      Text(l10n.applyResumeSection, style: _sectionStyle),
      const SizedBox(height: 6),
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: c.accentSoft,
          borderRadius: RungRadius.mdAll,
          border: Border.all(color: c.accent, width: 1.5),
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: c.red,
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Text(
                'PDF',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 10,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _resumeFileName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 13.5,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Text(
                    l10n.applyResumeUploaded(_resumeSize),
                    style: TextStyle(fontSize: 11.5, color: c.ink3),
                  ),
                ],
              ),
            ),
            TextButton(
              onPressed: () => showRungToast(context, l10n.comingSoon),
              child: Text(l10n.actionChange),
            ),
          ],
        ),
      ),
      const SizedBox(height: 20),
      Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(l10n.applyCoverLetterSection, style: _sectionStyle),
          const SizedBox(width: 6),
          Text(
            l10n.optionalSuffix,
            style: TextStyle(fontSize: 12, color: c.ink3),
          ),
        ],
      ),
      const SizedBox(height: 6),
      SizedBox(
        height: 150,
        child: TextField(
          controller: _cover,
          maxLines: null,
          expands: true,
          textAlignVertical: TextAlignVertical.top,
          style: TextStyle(fontSize: 14, height: 1.5, color: c.ink),
          decoration: InputDecoration(
            hintText: l10n.applyCoverHint,
            contentPadding: const EdgeInsets.all(13),
          ),
        ),
      ),
    ];
  }

  List<Widget> _reviewStep(Job job) {
    final c = context.rung;
    final l10n = context.l10n;
    final me = ref.watch(currentPersonProvider).valueOrNull;
    final cover = _cover.text.trim();

    Widget row(String label, Widget value, {bool last = false}) => Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
          decoration: BoxDecoration(
            border: last
                ? null
                : Border(bottom: BorderSide(color: c.line)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: TextStyle(
                  fontSize: 11.5,
                  fontWeight: FontWeight.w600,
                  color: c.ink3,
                ),
              ),
              const SizedBox(height: 3),
              value,
            ],
          ),
        );

    return [
      Text(l10n.applyReviewSection, style: _sectionStyle),
      const SizedBox(height: 12),
      Container(
        decoration: BoxDecoration(
          borderRadius: RungRadius.mdAll,
          border: Border.all(color: c.line),
        ),
        clipBehavior: Clip.antiAlias,
        child: Column(
          children: [
            row(
              l10n.applyApplicantLabel,
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    me?.name ?? '',
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Text(
                    '${me?.headline ?? ''} · ${me?.location ?? ''}',
                    style: TextStyle(fontSize: 12.5, color: c.ink2),
                  ),
                ],
              ),
            ),
            row(
              l10n.applyResumeLabel,
              Text(
                _resumeFileName,
                style: const TextStyle(
                  fontSize: 13.5,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            row(
              l10n.applyCoverLetterSection,
              Text(
                cover.isEmpty ? l10n.applyNoCoverLetter : cover,
                style: TextStyle(fontSize: 13, height: 1.5, color: c.ink2),
              ),
              last: true,
            ),
          ],
        ),
      ),
    ];
  }

  static const _sectionStyle = TextStyle(
    fontSize: 15,
    fontWeight: FontWeight.w800,
  );
}
