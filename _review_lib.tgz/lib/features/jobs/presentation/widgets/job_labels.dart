import 'package:flutter/widgets.dart';

import 'package:flutter_mobile_template/l10n/l10n.dart';

import '../../domain/entities/job.dart';
import '../../domain/entities/job_application.dart';

extension WorkModeLabel on WorkMode {
  String label(BuildContext context) => switch (this) {
        WorkMode.remote => context.l10n.jobsFilterRemote,
        WorkMode.hybrid => context.l10n.jobsFilterHybrid,
        WorkMode.onsite => context.l10n.jobsFilterOnsite,
      };
}

extension EmploymentTypeLabel on EmploymentType {
  /// `freelance`, `selfEmployed` and `temporary` are the three
  /// `EmploymentTypeEnum` members the design never drew a chip for, so they
  /// borrow the nearest existing string ("عقد") rather than going unlabelled.
  /// Only the label is approximate — [Job] keeps the real value, so filtering
  /// and re-posting still round-trip. Give them their own keys when there is
  /// copy for them.
  String label(BuildContext context) => switch (this) {
        EmploymentType.fullTime => context.l10n.jobTypeFullTime,
        EmploymentType.partTime => context.l10n.jobTypePartTime,
        EmploymentType.internship => context.l10n.jobTypeInternship,
        EmploymentType.contract ||
        EmploymentType.freelance ||
        EmploymentType.selfEmployed ||
        EmploymentType.temporary =>
          context.l10n.jobTypeContract,
      };
}

extension ApplicationStatusLabel on ApplicationStatus {
  String label(BuildContext context) => switch (this) {
        ApplicationStatus.submitted => context.l10n.applicationStatusSubmitted,
        ApplicationStatus.inReview => context.l10n.applicationStatusInReview,
        ApplicationStatus.shortlisted =>
          context.l10n.applicationStatusShortlisted,
        ApplicationStatus.interview => context.l10n.applicationStatusInterview,
        ApplicationStatus.accepted => context.l10n.applicationStatusAccepted,
        ApplicationStatus.rejected => context.l10n.applicationStatusRejected,
      };
}

/// The five stepper labels, in order.
List<String> applicationStepLabels(BuildContext context) => [
      context.l10n.applicationStepSubmitted,
      context.l10n.applicationStepReview,
      context.l10n.applicationStepShortlist,
      context.l10n.applicationStepInterview,
      context.l10n.applicationStepDecision,
    ];
