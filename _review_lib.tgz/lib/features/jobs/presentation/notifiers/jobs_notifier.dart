import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:flutter_mobile_template/core/error/app_exception.dart';
import 'package:flutter_mobile_template/core/error/result.dart';

import '../../data/repositories/job_repository_impl.dart';
import '../../domain/entities/job.dart';
import '../../domain/entities/job_application.dart';
import '../../domain/repositories/job_repository.dart';

/// Current jobs-list filters. Held outside the results notifier so a chip tap
/// doesn't have to round-trip through an AsyncValue to be reflected in the UI.
final jobFiltersProvider = StateProvider<JobFilters>((ref) => const JobFilters());

/// Search results for the active filters. Re-runs whenever the filters change.
final jobsSearchProvider = FutureProvider<List<Job>>((ref) async {
  final filters = ref.watch(jobFiltersProvider);
  final result = await ref.watch(jobRepositoryProvider).search(filters);
  return result.when(success: (jobs) => jobs, failure: (e) => throw e);
});

final jobDetailProvider = FutureProvider.family<Job, String>((ref, id) async {
  final result = await ref.watch(jobRepositoryProvider).getById(id);
  return result.when(success: (job) => job, failure: (e) => throw e);
});

class ApplicationsNotifier extends AsyncNotifier<List<JobApplication>> {
  @override
  Future<List<JobApplication>> build() async {
    final result = await ref.read(jobRepositoryProvider).applications();
    return result.when(success: (apps) => apps, failure: (e) => throw e);
  }

  Future<void> refresh() async {
    state = const AsyncValue.loading();
    state = await AsyncValue.guard(() async {
      final result = await ref.read(jobRepositoryProvider).applications();
      return result.when(success: (apps) => apps, failure: (e) => throw e);
    });
  }

  /// [resumeUrl] is a stored document location, not a picked file name — see
  /// `JobRepository.apply`. Nothing in the app produces one yet.
  Future<Result<JobApplication, AppException>> apply({
    required String jobId,
    String? resumeUrl,
    String coverLetter = '',
  }) async {
    final result = await ref.read(jobRepositoryProvider).apply(
          jobId: jobId,
          resumeUrl: resumeUrl,
          coverLetter: coverLetter,
        );
    result.when(
      success: (application) {
        state = AsyncValue.data([
          application,
          ...(state.valueOrNull ?? const <JobApplication>[])
              .where((a) => a.jobId != jobId),
        ]);
      },
      failure: (_) {},
    );
    return result;
  }
}

final applicationsNotifierProvider =
    AsyncNotifierProvider<ApplicationsNotifier, List<JobApplication>>(
  ApplicationsNotifier.new,
);

/// jobId → application, so a job card can show "تم التقديم" without each card
/// querying on its own.
///
/// This is not the same signal as `Job.applied`: the map is empty until the
/// applications list loads and only covers the page it fetched, while
/// `Job.applied` is the server's own `hasApplied` but is stale for a job row
/// fetched before the person applied. Widgets take either.
final applicationsByJobProvider = Provider<Map<String, JobApplication>>((ref) {
  final apps = ref.watch(applicationsNotifierProvider).valueOrNull;
  if (apps == null) return const {};
  return {for (final a in apps) a.jobId: a};
});
