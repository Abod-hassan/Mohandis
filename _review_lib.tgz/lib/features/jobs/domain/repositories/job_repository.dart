import 'package:flutter_mobile_template/core/base/base_repository.dart';
import 'package:flutter_mobile_template/core/error/app_exception.dart';
import 'package:flutter_mobile_template/core/error/result.dart';

import '../entities/job.dart';
import '../entities/job_application.dart';

/// Search filters for the jobs list.
///
/// A null [workMode] is "الكل", and it means the key is left out of the
/// `JobFilter` body entirely — there is no server-side value for "any", so
/// sending one would narrow the list to a single workplace type. The
/// translation to the wire lives in `JobRepositoryImpl`; this stays a plain
/// value object so the domain layer keeps no knowledge of the API shape.
class JobFilters {
  const JobFilters({this.query = '', this.workMode});

  final String query;
  final WorkMode? workMode;

  JobFilters copyWith({
    String? query,
    WorkMode? workMode,
    bool clearWorkMode = false,
  }) {
    return JobFilters(
      query: query ?? this.query,
      workMode: clearWorkMode ? null : (workMode ?? this.workMode),
    );
  }
}

abstract class JobRepository extends BaseRepository<Job> {
  Future<Result<List<Job>, AppException>> search(JobFilters filters);

  /// The signed-in person's own applications, newest first.
  Future<Result<List<JobApplication>, AppException>> applications();

  /// Applies to [jobId] and returns the application row that was created.
  ///
  /// [resumeUrl] is a stored location, not a picked file name: the backend
  /// column is `ResumeUrl` and the poster's applicant list renders it as a
  /// link. The app has no document upload yet, so callers pass null and the
  /// key is omitted rather than writing a bare file name that resolves to
  /// nothing.
  Future<Result<JobApplication, AppException>> apply({
    required String jobId,
    String? resumeUrl,
    String coverLetter,
  });
}
