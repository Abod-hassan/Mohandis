import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:flutter_mobile_template/core/api/api_client.dart';
import 'package:flutter_mobile_template/core/api/endpoints.dart';
import 'package:flutter_mobile_template/core/error/app_exception.dart';
import 'package:flutter_mobile_template/core/error/result.dart';
import 'package:flutter_mobile_template/core/providers.dart';

import '../../domain/entities/dashboard_summary.dart';
import '../../domain/repositories/dashboard_repository.dart';
import '../dtos/dashboard_summary_dto.dart';

class DashboardRepositoryImpl implements DashboardRepository {
  DashboardRepositoryImpl({required ApiClient apiClient}) : _api = apiClient;

  final ApiClient _api;

  @override
  Future<Result<DashboardSummary, AppException>> summary() async {
    try {
      final res = await _api.dio.get<Map<String, dynamic>>(EndPoints.dashboard);
      return Result.success(
        DashboardSummaryDto.fromJson(res.data ?? const {}).toDomain(),
      );
    } on DioException catch (e) {
      final mapped = e.error;
      if (mapped is AppException) return Result.failure(mapped);
      final status = e.response?.statusCode;
      return Result.failure(
        UnknownException(
          'Dashboard request failed [${e.type.name}${status != null ? ' · $status' : ''}] ${EndPoints.dashboard}',
          cause: e,
        ),
      );
    } catch (e, s) {
      return Result.failure(
        UnknownException('Dashboard parse failed', cause: e, stackTrace: s),
      );
    }
  }
}

final dashboardRepositoryProvider = Provider<DashboardRepository>((ref) {
  return DashboardRepositoryImpl(apiClient: ref.watch(apiClientProvider));
});
