import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_ar.dart';
import 'app_localizations_en.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'generated/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale)
    : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations)!;
  }

  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates =
      <LocalizationsDelegate<dynamic>>[
        delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('ar'),
    Locale('en'),
  ];

  /// Product name shown in the OS task switcher.
  ///
  /// In ar, this message translates to:
  /// **'رنق'**
  String get appTitle;

  /// No description provided for @actionRetry.
  ///
  /// In ar, this message translates to:
  /// **'إعادة المحاولة'**
  String get actionRetry;

  /// No description provided for @actionCancel.
  ///
  /// In ar, this message translates to:
  /// **'إلغاء'**
  String get actionCancel;

  /// No description provided for @actionSave.
  ///
  /// In ar, this message translates to:
  /// **'حفظ'**
  String get actionSave;

  /// No description provided for @actionDone.
  ///
  /// In ar, this message translates to:
  /// **'تم'**
  String get actionDone;

  /// No description provided for @actionContinue.
  ///
  /// In ar, this message translates to:
  /// **'متابعة'**
  String get actionContinue;

  /// No description provided for @actionSend.
  ///
  /// In ar, this message translates to:
  /// **'إرسال'**
  String get actionSend;

  /// No description provided for @actionAccept.
  ///
  /// In ar, this message translates to:
  /// **'قبول'**
  String get actionAccept;

  /// No description provided for @actionIgnore.
  ///
  /// In ar, this message translates to:
  /// **'تجاهل'**
  String get actionIgnore;

  /// No description provided for @actionChange.
  ///
  /// In ar, this message translates to:
  /// **'تغيير'**
  String get actionChange;

  /// No description provided for @comingSoon.
  ///
  /// In ar, this message translates to:
  /// **'قريباً'**
  String get comingSoon;

  /// No description provided for @optionalSuffix.
  ///
  /// In ar, this message translates to:
  /// **'(اختياري)'**
  String get optionalSuffix;

  /// No description provided for @genericError.
  ///
  /// In ar, this message translates to:
  /// **'حدث خطأ غير متوقع. حاول مرة أخرى.'**
  String get genericError;

  /// No description provided for @emptyTitle.
  ///
  /// In ar, this message translates to:
  /// **'لا يوجد شيء هنا بعد'**
  String get emptyTitle;

  /// No description provided for @themeToggleToDark.
  ///
  /// In ar, this message translates to:
  /// **'التبديل إلى المظهر الداكن'**
  String get themeToggleToDark;

  /// No description provided for @themeToggleToLight.
  ///
  /// In ar, this message translates to:
  /// **'التبديل إلى المظهر الفاتح'**
  String get themeToggleToLight;

  /// Onboarding hero headline.
  ///
  /// In ar, this message translates to:
  /// **'حيث تلتقي المسارات المهنية.'**
  String get authHeroTitle;

  /// No description provided for @authHeroBody.
  ///
  /// In ar, this message translates to:
  /// **'ابنِ ملفك المهني، وسّع شبكتك، شارك أعمالك، واعثر على دورك المهني القادم — في مكان واحد هادئ واحترافي.'**
  String get authHeroBody;

  /// No description provided for @authStatProfessionalsValue.
  ///
  /// In ar, this message translates to:
  /// **'+١٢ مليون'**
  String get authStatProfessionalsValue;

  /// No description provided for @authStatProfessionalsLabel.
  ///
  /// In ar, this message translates to:
  /// **'مختص'**
  String get authStatProfessionalsLabel;

  /// No description provided for @authStatJobsValue.
  ///
  /// In ar, this message translates to:
  /// **'٢٤٠ ألف'**
  String get authStatJobsValue;

  /// No description provided for @authStatJobsLabel.
  ///
  /// In ar, this message translates to:
  /// **'وظيفة شاغرة'**
  String get authStatJobsLabel;

  /// No description provided for @authStatTrustValue.
  ///
  /// In ar, this message translates to:
  /// **'٩٨٪'**
  String get authStatTrustValue;

  /// No description provided for @authStatTrustLabel.
  ///
  /// In ar, this message translates to:
  /// **'درجة الثقة'**
  String get authStatTrustLabel;

  /// No description provided for @authGetStarted.
  ///
  /// In ar, this message translates to:
  /// **'لنبدأ'**
  String get authGetStarted;

  /// No description provided for @authSignIn.
  ///
  /// In ar, this message translates to:
  /// **'تسجيل الدخول'**
  String get authSignIn;

  /// No description provided for @authCreateAccount.
  ///
  /// In ar, this message translates to:
  /// **'إنشاء حساب'**
  String get authCreateAccount;

  /// No description provided for @authContinueWith.
  ///
  /// In ar, this message translates to:
  /// **'أو تابع عبر'**
  String get authContinueWith;

  /// No description provided for @authGoogle.
  ///
  /// In ar, this message translates to:
  /// **'جوجل'**
  String get authGoogle;

  /// No description provided for @authApple.
  ///
  /// In ar, this message translates to:
  /// **'آبل'**
  String get authApple;

  /// No description provided for @authTerms.
  ///
  /// In ar, this message translates to:
  /// **'بمتابعتك فإنك توافق على شروط الاستخدام وسياسة الخصوصية الخاصة برنق'**
  String get authTerms;

  /// No description provided for @authWelcomeBack.
  ///
  /// In ar, this message translates to:
  /// **'أهلاً بعودتك، {name} 👋'**
  String authWelcomeBack(String name);

  /// No description provided for @navHome.
  ///
  /// In ar, this message translates to:
  /// **'الرئيسية'**
  String get navHome;

  /// No description provided for @navReels.
  ///
  /// In ar, this message translates to:
  /// **'ريلز'**
  String get navReels;

  /// No description provided for @navDashboard.
  ///
  /// In ar, this message translates to:
  /// **'لوحتي'**
  String get navDashboard;

  /// No description provided for @navJobs.
  ///
  /// In ar, this message translates to:
  /// **'الوظائف'**
  String get navJobs;

  /// No description provided for @navNetwork.
  ///
  /// In ar, this message translates to:
  /// **'شبكتي'**
  String get navNetwork;

  /// No description provided for @topBarSearchHint.
  ///
  /// In ar, this message translates to:
  /// **'ابحث عن أشخاص أو وظائف أو وسوم'**
  String get topBarSearchHint;

  /// No description provided for @feedYourStory.
  ///
  /// In ar, this message translates to:
  /// **'قصتك'**
  String get feedYourStory;

  /// No description provided for @feedComposerHint.
  ///
  /// In ar, this message translates to:
  /// **'شارك تحديثاً أو فكرة…'**
  String get feedComposerHint;

  /// No description provided for @feedCaughtUp.
  ///
  /// In ar, this message translates to:
  /// **'لقد اطّلعت على كل الجديد ✓'**
  String get feedCaughtUp;

  /// No description provided for @feedRepostedBy.
  ///
  /// In ar, this message translates to:
  /// **'أعاد {name} النشر'**
  String feedRepostedBy(String name);

  /// No description provided for @postActionLike.
  ///
  /// In ar, this message translates to:
  /// **'إعجاب'**
  String get postActionLike;

  /// No description provided for @postActionComment.
  ///
  /// In ar, this message translates to:
  /// **'تعليق'**
  String get postActionComment;

  /// No description provided for @postActionRepost.
  ///
  /// In ar, this message translates to:
  /// **'إعادة نشر'**
  String get postActionRepost;

  /// No description provided for @postActionSave.
  ///
  /// In ar, this message translates to:
  /// **'حفظ'**
  String get postActionSave;

  /// No description provided for @postCommentsCount.
  ///
  /// In ar, this message translates to:
  /// **'{count} تعليق'**
  String postCommentsCount(String count);

  /// No description provided for @postRepostsCount.
  ///
  /// In ar, this message translates to:
  /// **'{count} إعادة نشر'**
  String postRepostsCount(String count);

  /// No description provided for @postLikesCount.
  ///
  /// In ar, this message translates to:
  /// **'{count} إعجاب'**
  String postLikesCount(String count);

  /// No description provided for @postViewJob.
  ///
  /// In ar, this message translates to:
  /// **'عرض الوظيفة والتقديم ←'**
  String get postViewJob;

  /// No description provided for @postDetailTitle.
  ///
  /// In ar, this message translates to:
  /// **'المنشور'**
  String get postDetailTitle;

  /// No description provided for @postAddComment.
  ///
  /// In ar, this message translates to:
  /// **'أضف تعليقاً…'**
  String get postAddComment;

  /// No description provided for @postReply.
  ///
  /// In ar, this message translates to:
  /// **'رد'**
  String get postReply;

  /// No description provided for @postLikeWithCount.
  ///
  /// In ar, this message translates to:
  /// **'إعجاب · {count}'**
  String postLikeWithCount(String count);

  /// No description provided for @visibilityPublic.
  ///
  /// In ar, this message translates to:
  /// **'عام'**
  String get visibilityPublic;

  /// No description provided for @visibilityFollowers.
  ///
  /// In ar, this message translates to:
  /// **'المتابعون'**
  String get visibilityFollowers;

  /// No description provided for @visibilityPrivate.
  ///
  /// In ar, this message translates to:
  /// **'خاص'**
  String get visibilityPrivate;

  /// No description provided for @visibilityEveryoneLabel.
  ///
  /// In ar, this message translates to:
  /// **'الجميع'**
  String get visibilityEveryoneLabel;

  /// No description provided for @visibilityFollowersOnlyLabel.
  ///
  /// In ar, this message translates to:
  /// **'المتابعون فقط'**
  String get visibilityFollowersOnlyLabel;

  /// No description provided for @visibilityOnlyMeLabel.
  ///
  /// In ar, this message translates to:
  /// **'أنا فقط'**
  String get visibilityOnlyMeLabel;

  /// No description provided for @composerTitle.
  ///
  /// In ar, this message translates to:
  /// **'منشور جديد'**
  String get composerTitle;

  /// No description provided for @composerPublish.
  ///
  /// In ar, this message translates to:
  /// **'نشر'**
  String get composerPublish;

  /// No description provided for @composerHint.
  ///
  /// In ar, this message translates to:
  /// **'شارك تحديثاً أو فكرة أو فرصة…'**
  String get composerHint;

  /// No description provided for @toastSavedToItems.
  ///
  /// In ar, this message translates to:
  /// **'حُفظ في عناصرك'**
  String get toastSavedToItems;

  /// No description provided for @toastReposted.
  ///
  /// In ar, this message translates to:
  /// **'أُعيد النشر لمتابعيك'**
  String get toastReposted;

  /// No description provided for @toastPosted.
  ///
  /// In ar, this message translates to:
  /// **'تم نشر المنشور ✓'**
  String get toastPosted;

  /// No description provided for @toastSavedToReels.
  ///
  /// In ar, this message translates to:
  /// **'حُفظ في ريلزك'**
  String get toastSavedToReels;

  /// No description provided for @toastProfileUpdated.
  ///
  /// In ar, this message translates to:
  /// **'تم تحديث الملف ✓'**
  String get toastProfileUpdated;

  /// No description provided for @toastApplicationSent.
  ///
  /// In ar, this message translates to:
  /// **'تم إرسال الطلب ✓'**
  String get toastApplicationSent;

  /// No description provided for @toastConnectRequestSent.
  ///
  /// In ar, this message translates to:
  /// **'أُرسل طلب التواصل إلى {name}'**
  String toastConnectRequestSent(String name);

  /// No description provided for @toastConnected.
  ///
  /// In ar, this message translates to:
  /// **'تم التواصل مع {name}'**
  String toastConnected(String name);

  /// No description provided for @toastFollowing.
  ///
  /// In ar, this message translates to:
  /// **'تتابع الآن {name}'**
  String toastFollowing(String name);

  /// No description provided for @toastUnfollowed.
  ///
  /// In ar, this message translates to:
  /// **'تم إلغاء المتابعة'**
  String get toastUnfollowed;

  /// No description provided for @storyReplyTo.
  ///
  /// In ar, this message translates to:
  /// **'رد على {name}…'**
  String storyReplyTo(String name);

  /// No description provided for @storyPostedAgo.
  ///
  /// In ar, this message translates to:
  /// **'قبل {time}'**
  String storyPostedAgo(String time);

  /// No description provided for @reelsTitle.
  ///
  /// In ar, this message translates to:
  /// **'ريلز'**
  String get reelsTitle;

  /// No description provided for @reelFollow.
  ///
  /// In ar, this message translates to:
  /// **'متابعة'**
  String get reelFollow;

  /// No description provided for @reelShare.
  ///
  /// In ar, this message translates to:
  /// **'مشاركة'**
  String get reelShare;

  /// No description provided for @reelPlays.
  ///
  /// In ar, this message translates to:
  /// **'{count} مشاهدة'**
  String reelPlays(String count);

  /// No description provided for @profileOpenToWork.
  ///
  /// In ar, this message translates to:
  /// **'متاح للعمل'**
  String get profileOpenToWork;

  /// No description provided for @profileHiring.
  ///
  /// In ar, this message translates to:
  /// **'نتوظّف'**
  String get profileHiring;

  /// No description provided for @profileConnections.
  ///
  /// In ar, this message translates to:
  /// **'اتصالاً'**
  String get profileConnections;

  /// No description provided for @profileFollowers.
  ///
  /// In ar, this message translates to:
  /// **'متابعاً'**
  String get profileFollowers;

  /// No description provided for @profileEdit.
  ///
  /// In ar, this message translates to:
  /// **'تعديل الملف'**
  String get profileEdit;

  /// No description provided for @profileFollow.
  ///
  /// In ar, this message translates to:
  /// **'متابعة'**
  String get profileFollow;

  /// No description provided for @profileUnfollow.
  ///
  /// In ar, this message translates to:
  /// **'إلغاء المتابعة'**
  String get profileUnfollow;

  /// No description provided for @profileConnect.
  ///
  /// In ar, this message translates to:
  /// **'إضافة'**
  String get profileConnect;

  /// No description provided for @profileAbout.
  ///
  /// In ar, this message translates to:
  /// **'نبذة'**
  String get profileAbout;

  /// No description provided for @profileDownloadCv.
  ///
  /// In ar, this message translates to:
  /// **'تنزيل السيرة الذاتية'**
  String get profileDownloadCv;

  /// No description provided for @profileExperience.
  ///
  /// In ar, this message translates to:
  /// **'الخبرات'**
  String get profileExperience;

  /// No description provided for @profileEducation.
  ///
  /// In ar, this message translates to:
  /// **'التعليم'**
  String get profileEducation;

  /// No description provided for @profileSkills.
  ///
  /// In ar, this message translates to:
  /// **'المهارات'**
  String get profileSkills;

  /// No description provided for @profileEndorsements.
  ///
  /// In ar, this message translates to:
  /// **'{count} تزكية'**
  String profileEndorsements(String count);

  /// No description provided for @profileEndorse.
  ///
  /// In ar, this message translates to:
  /// **'+ تزكية'**
  String get profileEndorse;

  /// No description provided for @editProfileTitle.
  ///
  /// In ar, this message translates to:
  /// **'تعديل الملف'**
  String get editProfileTitle;

  /// No description provided for @editProfileFullName.
  ///
  /// In ar, this message translates to:
  /// **'الاسم الكامل'**
  String get editProfileFullName;

  /// No description provided for @editProfileHeadline.
  ///
  /// In ar, this message translates to:
  /// **'المسمى المهني'**
  String get editProfileHeadline;

  /// No description provided for @editProfileIndustry.
  ///
  /// In ar, this message translates to:
  /// **'القطاع'**
  String get editProfileIndustry;

  /// No description provided for @editProfileLocation.
  ///
  /// In ar, this message translates to:
  /// **'الموقع'**
  String get editProfileLocation;

  /// No description provided for @editProfileAbout.
  ///
  /// In ar, this message translates to:
  /// **'نبذة'**
  String get editProfileAbout;

  /// No description provided for @editProfileOpenToWorkTitle.
  ///
  /// In ar, this message translates to:
  /// **'متاح للعمل'**
  String get editProfileOpenToWorkTitle;

  /// No description provided for @editProfileOpenToWorkSubtitle.
  ///
  /// In ar, this message translates to:
  /// **'أظهر لجهات التوظيف أنك متاح'**
  String get editProfileOpenToWorkSubtitle;

  /// No description provided for @editProfilePrivateTitle.
  ///
  /// In ar, this message translates to:
  /// **'ملف خاص'**
  String get editProfilePrivateTitle;

  /// No description provided for @editProfilePrivateSubtitle.
  ///
  /// In ar, this message translates to:
  /// **'وافق على المتابعين قبل رؤية منشوراتك'**
  String get editProfilePrivateSubtitle;

  /// No description provided for @networkTitle.
  ///
  /// In ar, this message translates to:
  /// **'شبكتي'**
  String get networkTitle;

  /// No description provided for @networkRequests.
  ///
  /// In ar, this message translates to:
  /// **'طلبات التواصل'**
  String get networkRequests;

  /// No description provided for @networkSuggestions.
  ///
  /// In ar, this message translates to:
  /// **'أشخاص قد تعرفهم'**
  String get networkSuggestions;

  /// No description provided for @networkMutual.
  ///
  /// In ar, this message translates to:
  /// **'{count} معارف مشتركة'**
  String networkMutual(String count);

  /// No description provided for @networkAdd.
  ///
  /// In ar, this message translates to:
  /// **'+ إضافة'**
  String get networkAdd;

  /// No description provided for @searchHint.
  ///
  /// In ar, this message translates to:
  /// **'ابحث في رنق'**
  String get searchHint;

  /// No description provided for @searchTabTop.
  ///
  /// In ar, this message translates to:
  /// **'الأهم'**
  String get searchTabTop;

  /// No description provided for @searchTabPeople.
  ///
  /// In ar, this message translates to:
  /// **'أشخاص'**
  String get searchTabPeople;

  /// No description provided for @searchTabJobs.
  ///
  /// In ar, this message translates to:
  /// **'وظائف'**
  String get searchTabJobs;

  /// No description provided for @searchTabTags.
  ///
  /// In ar, this message translates to:
  /// **'وسوم'**
  String get searchTabTags;

  /// No description provided for @searchTrendingTags.
  ///
  /// In ar, this message translates to:
  /// **'الوسوم الرائجة'**
  String get searchTrendingTags;

  /// No description provided for @searchSectionPeople.
  ///
  /// In ar, this message translates to:
  /// **'أشخاص'**
  String get searchSectionPeople;

  /// No description provided for @searchNoResults.
  ///
  /// In ar, this message translates to:
  /// **'لا نتائج مطابقة لبحثك'**
  String get searchNoResults;

  /// No description provided for @searchPostsCount.
  ///
  /// In ar, this message translates to:
  /// **'{count} منشور'**
  String searchPostsCount(String count);

  /// No description provided for @notificationsTitle.
  ///
  /// In ar, this message translates to:
  /// **'الإشعارات'**
  String get notificationsTitle;

  /// No description provided for @notificationsMarkAllRead.
  ///
  /// In ar, this message translates to:
  /// **'تعليم الكل كمقروء'**
  String get notificationsMarkAllRead;

  /// No description provided for @notificationsNowConnected.
  ///
  /// In ar, this message translates to:
  /// **'أصبح على تواصل معك'**
  String get notificationsNowConnected;

  /// No description provided for @messagesTitle.
  ///
  /// In ar, this message translates to:
  /// **'الرسائل'**
  String get messagesTitle;

  /// No description provided for @messagesSearchHint.
  ///
  /// In ar, this message translates to:
  /// **'بحث في الرسائل'**
  String get messagesSearchHint;

  /// No description provided for @messagesYouPrefix.
  ///
  /// In ar, this message translates to:
  /// **'أنت: '**
  String get messagesYouPrefix;

  /// No description provided for @threadMembers.
  ///
  /// In ar, this message translates to:
  /// **'{count} أعضاء'**
  String threadMembers(String count);

  /// No description provided for @threadInputHint.
  ///
  /// In ar, this message translates to:
  /// **'اكتب رسالة…'**
  String get threadInputHint;

  /// No description provided for @threadToday.
  ///
  /// In ar, this message translates to:
  /// **'اليوم'**
  String get threadToday;

  /// No description provided for @threadRead.
  ///
  /// In ar, this message translates to:
  /// **'تمت القراءة'**
  String get threadRead;

  /// No description provided for @threadJustNow.
  ///
  /// In ar, this message translates to:
  /// **'الآن'**
  String get threadJustNow;

  /// No description provided for @jobsTitle.
  ///
  /// In ar, this message translates to:
  /// **'الوظائف'**
  String get jobsTitle;

  /// No description provided for @jobsMyApplications.
  ///
  /// In ar, this message translates to:
  /// **'طلباتي'**
  String get jobsMyApplications;

  /// No description provided for @jobsSearchHint.
  ///
  /// In ar, this message translates to:
  /// **'المسمى أو الشركة أو الموقع'**
  String get jobsSearchHint;

  /// No description provided for @jobsFilterAll.
  ///
  /// In ar, this message translates to:
  /// **'الكل'**
  String get jobsFilterAll;

  /// No description provided for @jobsFilterRemote.
  ///
  /// In ar, this message translates to:
  /// **'عن بُعد'**
  String get jobsFilterRemote;

  /// No description provided for @jobsFilterHybrid.
  ///
  /// In ar, this message translates to:
  /// **'هجين'**
  String get jobsFilterHybrid;

  /// No description provided for @jobsFilterOnsite.
  ///
  /// In ar, this message translates to:
  /// **'من المقر'**
  String get jobsFilterOnsite;

  /// No description provided for @jobsEmpty.
  ///
  /// In ar, this message translates to:
  /// **'لا توجد وظائف مطابقة للفلاتر'**
  String get jobsEmpty;

  /// No description provided for @jobTypeFullTime.
  ///
  /// In ar, this message translates to:
  /// **'دوام كامل'**
  String get jobTypeFullTime;

  /// No description provided for @jobTypePartTime.
  ///
  /// In ar, this message translates to:
  /// **'دوام جزئي'**
  String get jobTypePartTime;

  /// No description provided for @jobTypeContract.
  ///
  /// In ar, this message translates to:
  /// **'عقد'**
  String get jobTypeContract;

  /// No description provided for @jobTypeInternship.
  ///
  /// In ar, this message translates to:
  /// **'تدريب'**
  String get jobTypeInternship;

  /// No description provided for @jobPostedAgo.
  ///
  /// In ar, this message translates to:
  /// **'قبل {time}'**
  String jobPostedAgo(String time);

  /// No description provided for @jobApplicants.
  ///
  /// In ar, this message translates to:
  /// **'{count} متقدماً'**
  String jobApplicants(String count);

  /// No description provided for @jobApplied.
  ///
  /// In ar, this message translates to:
  /// **'تم التقديم'**
  String get jobApplied;

  /// No description provided for @jobDetailTitle.
  ///
  /// In ar, this message translates to:
  /// **'تفاصيل الوظيفة'**
  String get jobDetailTitle;

  /// No description provided for @jobSalaryRange.
  ///
  /// In ar, this message translates to:
  /// **'نطاق الراتب'**
  String get jobSalaryRange;

  /// No description provided for @jobAboutSection.
  ///
  /// In ar, this message translates to:
  /// **'عن الوظيفة'**
  String get jobAboutSection;

  /// No description provided for @jobRequirementsSection.
  ///
  /// In ar, this message translates to:
  /// **'ما نبحث عنه'**
  String get jobRequirementsSection;

  /// No description provided for @jobSkillsSection.
  ///
  /// In ar, this message translates to:
  /// **'المهارات'**
  String get jobSkillsSection;

  /// No description provided for @jobApplyNow.
  ///
  /// In ar, this message translates to:
  /// **'قدّم الآن'**
  String get jobApplyNow;

  /// No description provided for @jobApplicationStatus.
  ///
  /// In ar, this message translates to:
  /// **'الطلب: {status}'**
  String jobApplicationStatus(String status);

  /// No description provided for @applyTitle.
  ///
  /// In ar, this message translates to:
  /// **'التقديم'**
  String get applyTitle;

  /// No description provided for @applyResumeSection.
  ///
  /// In ar, this message translates to:
  /// **'سيرتك الذاتية'**
  String get applyResumeSection;

  /// No description provided for @applyResumeUploaded.
  ///
  /// In ar, this message translates to:
  /// **'تم الرفع · {size}'**
  String applyResumeUploaded(String size);

  /// No description provided for @applyCoverLetterSection.
  ///
  /// In ar, this message translates to:
  /// **'خطاب التقديم'**
  String get applyCoverLetterSection;

  /// No description provided for @applyCoverHint.
  ///
  /// In ar, this message translates to:
  /// **'أضف ملاحظة لفريق التوظيف…'**
  String get applyCoverHint;

  /// No description provided for @applyReviewSection.
  ///
  /// In ar, this message translates to:
  /// **'مراجعة وإرسال'**
  String get applyReviewSection;

  /// No description provided for @applyApplicantLabel.
  ///
  /// In ar, this message translates to:
  /// **'المتقدم'**
  String get applyApplicantLabel;

  /// No description provided for @applyResumeLabel.
  ///
  /// In ar, this message translates to:
  /// **'السيرة الذاتية'**
  String get applyResumeLabel;

  /// No description provided for @applyNoCoverLetter.
  ///
  /// In ar, this message translates to:
  /// **'لم تتم إضافة خطاب تقديم.'**
  String get applyNoCoverLetter;

  /// No description provided for @applySubmit.
  ///
  /// In ar, this message translates to:
  /// **'إرسال الطلب'**
  String get applySubmit;

  /// No description provided for @applyDoneTitle.
  ///
  /// In ar, this message translates to:
  /// **'تم إرسال طلبك!'**
  String get applyDoneTitle;

  /// No description provided for @applyDoneBody.
  ///
  /// In ar, this message translates to:
  /// **'تم إرسال طلبك لوظيفة {title} في {company}. يمكنك متابعة حالته من صفحة طلباتي.'**
  String applyDoneBody(String title, String company);

  /// No description provided for @myApplicationsTitle.
  ///
  /// In ar, this message translates to:
  /// **'طلباتي'**
  String get myApplicationsTitle;

  /// No description provided for @myApplicationsEmpty.
  ///
  /// In ar, this message translates to:
  /// **'لم تقدّم على أي وظيفة بعد'**
  String get myApplicationsEmpty;

  /// No description provided for @applicationStepSubmitted.
  ///
  /// In ar, this message translates to:
  /// **'الإرسال'**
  String get applicationStepSubmitted;

  /// No description provided for @applicationStepReview.
  ///
  /// In ar, this message translates to:
  /// **'المراجعة'**
  String get applicationStepReview;

  /// No description provided for @applicationStepShortlist.
  ///
  /// In ar, this message translates to:
  /// **'الاختيار'**
  String get applicationStepShortlist;

  /// No description provided for @applicationStepInterview.
  ///
  /// In ar, this message translates to:
  /// **'المقابلة'**
  String get applicationStepInterview;

  /// No description provided for @applicationStepDecision.
  ///
  /// In ar, this message translates to:
  /// **'القرار'**
  String get applicationStepDecision;

  /// No description provided for @applicationStatusSubmitted.
  ///
  /// In ar, this message translates to:
  /// **'تم الإرسال'**
  String get applicationStatusSubmitted;

  /// No description provided for @applicationStatusInReview.
  ///
  /// In ar, this message translates to:
  /// **'قيد المراجعة'**
  String get applicationStatusInReview;

  /// No description provided for @applicationStatusShortlisted.
  ///
  /// In ar, this message translates to:
  /// **'القائمة المختصرة'**
  String get applicationStatusShortlisted;

  /// No description provided for @applicationStatusInterview.
  ///
  /// In ar, this message translates to:
  /// **'مقابلة'**
  String get applicationStatusInterview;

  /// No description provided for @applicationStatusAccepted.
  ///
  /// In ar, this message translates to:
  /// **'مقبول'**
  String get applicationStatusAccepted;

  /// No description provided for @applicationStatusRejected.
  ///
  /// In ar, this message translates to:
  /// **'مرفوض'**
  String get applicationStatusRejected;

  /// No description provided for @dashboardGreeting.
  ///
  /// In ar, this message translates to:
  /// **'مساءً الخير'**
  String get dashboardGreeting;

  /// No description provided for @dashboardContinueLearning.
  ///
  /// In ar, this message translates to:
  /// **'أكمل التعلّم'**
  String get dashboardContinueLearning;

  /// No description provided for @dashboardLectureProgress.
  ///
  /// In ar, this message translates to:
  /// **'المحاضرة {current} من {total} · نظري'**
  String dashboardLectureProgress(String current, String total);

  /// No description provided for @dashboardStatCourses.
  ///
  /// In ar, this message translates to:
  /// **'دورات نشطة'**
  String get dashboardStatCourses;

  /// No description provided for @dashboardStatHours.
  ///
  /// In ar, this message translates to:
  /// **'ساعة تعلّم'**
  String get dashboardStatHours;

  /// No description provided for @dashboardStatCertificates.
  ///
  /// In ar, this message translates to:
  /// **'شهادات'**
  String get dashboardStatCertificates;

  /// No description provided for @dashboardSectionLearning.
  ///
  /// In ar, this message translates to:
  /// **'التعلّم'**
  String get dashboardSectionLearning;

  /// No description provided for @dashboardSectionServices.
  ///
  /// In ar, this message translates to:
  /// **'الخدمات'**
  String get dashboardSectionServices;

  /// No description provided for @dashboardSectionTools.
  ///
  /// In ar, this message translates to:
  /// **'أدواتي'**
  String get dashboardSectionTools;

  /// No description provided for @dashboardNewBadge.
  ///
  /// In ar, this message translates to:
  /// **'{count} جديد'**
  String dashboardNewBadge(String count);

  /// No description provided for @dashboardTheory.
  ///
  /// In ar, this message translates to:
  /// **'محاضرات نظرية'**
  String get dashboardTheory;

  /// No description provided for @dashboardTheorySubtitle.
  ///
  /// In ar, this message translates to:
  /// **'دروس ومفاهيم أساسية'**
  String get dashboardTheorySubtitle;

  /// No description provided for @dashboardPractical.
  ///
  /// In ar, this message translates to:
  /// **'محاضرات عملية'**
  String get dashboardPractical;

  /// No description provided for @dashboardPracticalSubtitle.
  ///
  /// In ar, this message translates to:
  /// **'تطبيقات وأمثلة عملية'**
  String get dashboardPracticalSubtitle;

  /// No description provided for @dashboardTraining.
  ///
  /// In ar, this message translates to:
  /// **'تدريب وتطوير'**
  String get dashboardTraining;

  /// No description provided for @dashboardTrainingSubtitle.
  ///
  /// In ar, this message translates to:
  /// **'برامج تطوير المهارات'**
  String get dashboardTrainingSubtitle;

  /// No description provided for @dashboardEngy.
  ///
  /// In ar, this message translates to:
  /// **'المهندسة إنجي'**
  String get dashboardEngy;

  /// No description provided for @dashboardEngySubtitle.
  ///
  /// In ar, this message translates to:
  /// **'مساعدتك الذكية للاستشارات'**
  String get dashboardEngySubtitle;

  /// No description provided for @dashboardEngyBadge.
  ///
  /// In ar, this message translates to:
  /// **'AI'**
  String get dashboardEngyBadge;

  /// No description provided for @dashboardLegalRequest.
  ///
  /// In ar, this message translates to:
  /// **'طلب استشارة قانونية'**
  String get dashboardLegalRequest;

  /// No description provided for @dashboardLegalRequestSubtitle.
  ///
  /// In ar, this message translates to:
  /// **'خطوات حل النزاعات القانونية'**
  String get dashboardLegalRequestSubtitle;

  /// No description provided for @dashboardLegalAffairs.
  ///
  /// In ar, this message translates to:
  /// **'الشؤون القانونية'**
  String get dashboardLegalAffairs;

  /// No description provided for @dashboardLegalAffairsSubtitle.
  ///
  /// In ar, this message translates to:
  /// **'حقوق المهندس والقوانين'**
  String get dashboardLegalAffairsSubtitle;

  /// No description provided for @dashboardNotes.
  ///
  /// In ar, this message translates to:
  /// **'ملاحظاتي'**
  String get dashboardNotes;

  /// No description provided for @dashboardNotesSubtitle.
  ///
  /// In ar, this message translates to:
  /// **'ملاحظاتك الشخصية'**
  String get dashboardNotesSubtitle;

  /// No description provided for @dashboardLibrary.
  ///
  /// In ar, this message translates to:
  /// **'المكتبة الهندسية'**
  String get dashboardLibrary;

  /// No description provided for @dashboardLibrarySubtitle.
  ///
  /// In ar, this message translates to:
  /// **'مراجع وأكواد ومواصفات'**
  String get dashboardLibrarySubtitle;

  /// No description provided for @dashboardOpening.
  ///
  /// In ar, this message translates to:
  /// **'جارٍ فتح {item}'**
  String dashboardOpening(String item);

  /// No description provided for @dashboardEngyGreeting.
  ///
  /// In ar, this message translates to:
  /// **'مرحباً، أنا إنجي — كيف أساعدك؟'**
  String get dashboardEngyGreeting;

  /// No description provided for @authSignInTitle.
  ///
  /// In ar, this message translates to:
  /// **'تسجيل الدخول'**
  String get authSignInTitle;

  /// No description provided for @authSignUpTitle.
  ///
  /// In ar, this message translates to:
  /// **'إنشاء حساب جديد'**
  String get authSignUpTitle;

  /// No description provided for @authUserName.
  ///
  /// In ar, this message translates to:
  /// **'اسم المستخدم'**
  String get authUserName;

  /// Helper text under the username field at sign-up.
  ///
  /// In ar, this message translates to:
  /// **'بالأحرف اللاتينية أو الأرقام'**
  String get authUserNameHint;

  /// No description provided for @authPassword.
  ///
  /// In ar, this message translates to:
  /// **'كلمة المرور'**
  String get authPassword;

  /// No description provided for @authFullName.
  ///
  /// In ar, this message translates to:
  /// **'الاسم الكامل'**
  String get authFullName;

  /// No description provided for @authFullNameHint.
  ///
  /// In ar, this message translates to:
  /// **'كما تريد أن يظهر في ملفك'**
  String get authFullNameHint;

  /// No description provided for @authPhone.
  ///
  /// In ar, this message translates to:
  /// **'رقم الهاتف'**
  String get authPhone;

  /// No description provided for @authAccountType.
  ///
  /// In ar, this message translates to:
  /// **'نوع الحساب'**
  String get authAccountType;

  /// No description provided for @authAccountIndividual.
  ///
  /// In ar, this message translates to:
  /// **'فرد'**
  String get authAccountIndividual;

  /// No description provided for @authAccountCompany.
  ///
  /// In ar, this message translates to:
  /// **'شركة'**
  String get authAccountCompany;

  /// No description provided for @authSubmitSignIn.
  ///
  /// In ar, this message translates to:
  /// **'دخول'**
  String get authSubmitSignIn;

  /// No description provided for @authSubmitSignUp.
  ///
  /// In ar, this message translates to:
  /// **'إنشاء الحساب'**
  String get authSubmitSignUp;

  /// No description provided for @authSwitchToSignUp.
  ///
  /// In ar, this message translates to:
  /// **'ليس لديك حساب؟ أنشئ حساباً'**
  String get authSwitchToSignUp;

  /// No description provided for @authSwitchToSignIn.
  ///
  /// In ar, this message translates to:
  /// **'لديك حساب بالفعل؟ سجّل الدخول'**
  String get authSwitchToSignIn;

  /// No description provided for @authRequiredField.
  ///
  /// In ar, this message translates to:
  /// **'هذا الحقل مطلوب'**
  String get authRequiredField;

  /// No description provided for @authPasswordTooShort.
  ///
  /// In ar, this message translates to:
  /// **'كلمة المرور ٦ أحرف على الأقل'**
  String get authPasswordTooShort;

  /// No description provided for @authUserNameTooShort.
  ///
  /// In ar, this message translates to:
  /// **'اسم المستخدم ٣ أحرف على الأقل'**
  String get authUserNameTooShort;

  /// No description provided for @authPhoneInvalid.
  ///
  /// In ar, this message translates to:
  /// **'أدخل رقم هاتف صحيح'**
  String get authPhoneInvalid;

  /// No description provided for @authAccountCreated.
  ///
  /// In ar, this message translates to:
  /// **'تم إنشاء حسابك، أهلاً بك {name} 🎉'**
  String authAccountCreated(String name);

  /// No description provided for @setupTitle.
  ///
  /// In ar, this message translates to:
  /// **'أكمل ملفك'**
  String get setupTitle;

  /// No description provided for @setupSubtitle.
  ///
  /// In ar, this message translates to:
  /// **'عرّف الآخرين بنفسك — يمكنك تعديل كل شيء لاحقاً.'**
  String get setupSubtitle;

  /// No description provided for @setupSubtitleCompany.
  ///
  /// In ar, this message translates to:
  /// **'عرّف الآخرين بشركتك — يمكنك تعديل كل شيء لاحقاً.'**
  String get setupSubtitleCompany;

  /// No description provided for @setupHeadline.
  ///
  /// In ar, this message translates to:
  /// **'المسمّى المهني'**
  String get setupHeadline;

  /// No description provided for @setupHeadlineHint.
  ///
  /// In ar, this message translates to:
  /// **'مهندس برمجيات في…'**
  String get setupHeadlineHint;

  /// No description provided for @setupHeadlineHintCompany.
  ///
  /// In ar, this message translates to:
  /// **'ما الذي تقدّمه شركتك؟'**
  String get setupHeadlineHintCompany;

  /// No description provided for @setupAbout.
  ///
  /// In ar, this message translates to:
  /// **'نبذة'**
  String get setupAbout;

  /// No description provided for @setupAboutHint.
  ///
  /// In ar, this message translates to:
  /// **'بضعة أسطر عن خبرتك واهتماماتك'**
  String get setupAboutHint;

  /// No description provided for @setupAboutHintCompany.
  ///
  /// In ar, this message translates to:
  /// **'بضعة أسطر عن نشاط الشركة'**
  String get setupAboutHintCompany;

  /// No description provided for @setupLocation.
  ///
  /// In ar, this message translates to:
  /// **'الموقع'**
  String get setupLocation;

  /// No description provided for @setupLocationHint.
  ///
  /// In ar, this message translates to:
  /// **'بغداد، العراق'**
  String get setupLocationHint;

  /// No description provided for @setupIndustry.
  ///
  /// In ar, this message translates to:
  /// **'المجال'**
  String get setupIndustry;

  /// No description provided for @setupIndustryHint.
  ///
  /// In ar, this message translates to:
  /// **'التقنية، الهندسة، الرعاية الصحية…'**
  String get setupIndustryHint;

  /// No description provided for @setupWebsite.
  ///
  /// In ar, this message translates to:
  /// **'الموقع الإلكتروني'**
  String get setupWebsite;

  /// No description provided for @setupOpenToWork.
  ///
  /// In ar, this message translates to:
  /// **'متاح لفرص عمل'**
  String get setupOpenToWork;

  /// No description provided for @setupOpenToWorkSubtitle.
  ///
  /// In ar, this message translates to:
  /// **'يظهر شارة على ملفك'**
  String get setupOpenToWorkSubtitle;

  /// No description provided for @setupSave.
  ///
  /// In ar, this message translates to:
  /// **'متابعة'**
  String get setupSave;

  /// No description provided for @setupSkip.
  ///
  /// In ar, this message translates to:
  /// **'تخطٍّ الآن'**
  String get setupSkip;

  /// No description provided for @setupSaved.
  ///
  /// In ar, this message translates to:
  /// **'تم حفظ ملفك 🎉'**
  String get setupSaved;

  /// No description provided for @authGender.
  ///
  /// In ar, this message translates to:
  /// **'الجنس'**
  String get authGender;

  /// No description provided for @authGenderMale.
  ///
  /// In ar, this message translates to:
  /// **'ذكر'**
  String get authGenderMale;

  /// No description provided for @authGenderFemale.
  ///
  /// In ar, this message translates to:
  /// **'أنثى'**
  String get authGenderFemale;

  /// No description provided for @authPhoto.
  ///
  /// In ar, this message translates to:
  /// **'صورة الملف'**
  String get authPhoto;

  /// No description provided for @authPhotoPick.
  ///
  /// In ar, this message translates to:
  /// **'اختر صورة'**
  String get authPhotoPick;

  /// No description provided for @authPhotoChange.
  ///
  /// In ar, this message translates to:
  /// **'تغيير الصورة'**
  String get authPhotoChange;

  /// No description provided for @authPhotoRemove.
  ///
  /// In ar, this message translates to:
  /// **'إزالة'**
  String get authPhotoRemove;

  /// No description provided for @authPhotoUploading.
  ///
  /// In ar, this message translates to:
  /// **'جارٍ رفع الصورة…'**
  String get authPhotoUploading;

  /// No description provided for @authGenderRequired.
  ///
  /// In ar, this message translates to:
  /// **'اختر الجنس'**
  String get authGenderRequired;

  /// No description provided for @profileConnectSent.
  ///
  /// In ar, this message translates to:
  /// **'تم إرسال الطلب'**
  String get profileConnectSent;

  /// No description provided for @profileConnectAccept.
  ///
  /// In ar, this message translates to:
  /// **'قبول الطلب'**
  String get profileConnectAccept;

  /// No description provided for @profileConnected.
  ///
  /// In ar, this message translates to:
  /// **'متصل'**
  String get profileConnected;

  /// No description provided for @profileFollowRequested.
  ///
  /// In ar, this message translates to:
  /// **'بانتظار الموافقة'**
  String get profileFollowRequested;

  /// No description provided for @toastConnectRequestCancelled.
  ///
  /// In ar, this message translates to:
  /// **'تم سحب الطلب'**
  String get toastConnectRequestCancelled;

  /// No description provided for @toastConnectionRemoved.
  ///
  /// In ar, this message translates to:
  /// **'تمت إزالة الاتصال'**
  String get toastConnectionRemoved;

  /// No description provided for @toastConnectAccepted.
  ///
  /// In ar, this message translates to:
  /// **'تم قبول الطلب'**
  String get toastConnectAccepted;

  /// No description provided for @networkAddSent.
  ///
  /// In ar, this message translates to:
  /// **'تم الإرسال'**
  String get networkAddSent;
}

class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) =>
      <String>['ar', 'en'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {
  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'ar':
      return AppLocalizationsAr();
    case 'en':
      return AppLocalizationsEn();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.',
  );
}
