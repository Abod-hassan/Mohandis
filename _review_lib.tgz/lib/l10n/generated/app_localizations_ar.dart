// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Arabic (`ar`).
class AppLocalizationsAr extends AppLocalizations {
  AppLocalizationsAr([String locale = 'ar']) : super(locale);

  @override
  String get appTitle => 'رنق';

  @override
  String get actionRetry => 'إعادة المحاولة';

  @override
  String get actionCancel => 'إلغاء';

  @override
  String get actionSave => 'حفظ';

  @override
  String get actionDone => 'تم';

  @override
  String get actionContinue => 'متابعة';

  @override
  String get actionSend => 'إرسال';

  @override
  String get actionAccept => 'قبول';

  @override
  String get actionIgnore => 'تجاهل';

  @override
  String get actionChange => 'تغيير';

  @override
  String get comingSoon => 'قريباً';

  @override
  String get optionalSuffix => '(اختياري)';

  @override
  String get genericError => 'حدث خطأ غير متوقع. حاول مرة أخرى.';

  @override
  String get emptyTitle => 'لا يوجد شيء هنا بعد';

  @override
  String get themeToggleToDark => 'التبديل إلى المظهر الداكن';

  @override
  String get themeToggleToLight => 'التبديل إلى المظهر الفاتح';

  @override
  String get authHeroTitle => 'حيث تلتقي المسارات المهنية.';

  @override
  String get authHeroBody =>
      'ابنِ ملفك المهني، وسّع شبكتك، شارك أعمالك، واعثر على دورك المهني القادم — في مكان واحد هادئ واحترافي.';

  @override
  String get authStatProfessionalsValue => '+١٢ مليون';

  @override
  String get authStatProfessionalsLabel => 'مختص';

  @override
  String get authStatJobsValue => '٢٤٠ ألف';

  @override
  String get authStatJobsLabel => 'وظيفة شاغرة';

  @override
  String get authStatTrustValue => '٩٨٪';

  @override
  String get authStatTrustLabel => 'درجة الثقة';

  @override
  String get authGetStarted => 'لنبدأ';

  @override
  String get authSignIn => 'تسجيل الدخول';

  @override
  String get authCreateAccount => 'إنشاء حساب';

  @override
  String get authContinueWith => 'أو تابع عبر';

  @override
  String get authGoogle => 'جوجل';

  @override
  String get authApple => 'آبل';

  @override
  String get authTerms =>
      'بمتابعتك فإنك توافق على شروط الاستخدام وسياسة الخصوصية الخاصة برنق';

  @override
  String authWelcomeBack(String name) {
    return 'أهلاً بعودتك، $name 👋';
  }

  @override
  String get navHome => 'الرئيسية';

  @override
  String get navReels => 'ريلز';

  @override
  String get navDashboard => 'لوحتي';

  @override
  String get navJobs => 'الوظائف';

  @override
  String get navNetwork => 'شبكتي';

  @override
  String get topBarSearchHint => 'ابحث عن أشخاص أو وظائف أو وسوم';

  @override
  String get feedYourStory => 'قصتك';

  @override
  String get feedComposerHint => 'شارك تحديثاً أو فكرة…';

  @override
  String get feedCaughtUp => 'لقد اطّلعت على كل الجديد ✓';

  @override
  String feedRepostedBy(String name) {
    return 'أعاد $name النشر';
  }

  @override
  String get postActionLike => 'إعجاب';

  @override
  String get postActionComment => 'تعليق';

  @override
  String get postActionRepost => 'إعادة نشر';

  @override
  String get postActionSave => 'حفظ';

  @override
  String postCommentsCount(String count) {
    return '$count تعليق';
  }

  @override
  String postRepostsCount(String count) {
    return '$count إعادة نشر';
  }

  @override
  String postLikesCount(String count) {
    return '$count إعجاب';
  }

  @override
  String get postViewJob => 'عرض الوظيفة والتقديم ←';

  @override
  String get postDetailTitle => 'المنشور';

  @override
  String get postAddComment => 'أضف تعليقاً…';

  @override
  String get postReply => 'رد';

  @override
  String postLikeWithCount(String count) {
    return 'إعجاب · $count';
  }

  @override
  String get visibilityPublic => 'عام';

  @override
  String get visibilityFollowers => 'المتابعون';

  @override
  String get visibilityPrivate => 'خاص';

  @override
  String get visibilityEveryoneLabel => 'الجميع';

  @override
  String get visibilityFollowersOnlyLabel => 'المتابعون فقط';

  @override
  String get visibilityOnlyMeLabel => 'أنا فقط';

  @override
  String get composerTitle => 'منشور جديد';

  @override
  String get composerPublish => 'نشر';

  @override
  String get composerHint => 'شارك تحديثاً أو فكرة أو فرصة…';

  @override
  String get toastSavedToItems => 'حُفظ في عناصرك';

  @override
  String get toastReposted => 'أُعيد النشر لمتابعيك';

  @override
  String get toastPosted => 'تم نشر المنشور ✓';

  @override
  String get toastSavedToReels => 'حُفظ في ريلزك';

  @override
  String get toastProfileUpdated => 'تم تحديث الملف ✓';

  @override
  String get toastApplicationSent => 'تم إرسال الطلب ✓';

  @override
  String toastConnectRequestSent(String name) {
    return 'أُرسل طلب التواصل إلى $name';
  }

  @override
  String toastConnected(String name) {
    return 'تم التواصل مع $name';
  }

  @override
  String toastFollowing(String name) {
    return 'تتابع الآن $name';
  }

  @override
  String get toastUnfollowed => 'تم إلغاء المتابعة';

  @override
  String storyReplyTo(String name) {
    return 'رد على $name…';
  }

  @override
  String storyPostedAgo(String time) {
    return 'قبل $time';
  }

  @override
  String get reelsTitle => 'ريلز';

  @override
  String get reelFollow => 'متابعة';

  @override
  String get reelShare => 'مشاركة';

  @override
  String reelPlays(String count) {
    return '$count مشاهدة';
  }

  @override
  String get profileOpenToWork => 'متاح للعمل';

  @override
  String get profileHiring => 'نتوظّف';

  @override
  String get profileConnections => 'اتصالاً';

  @override
  String get profileFollowers => 'متابعاً';

  @override
  String get profileEdit => 'تعديل الملف';

  @override
  String get profileFollow => 'متابعة';

  @override
  String get profileUnfollow => 'إلغاء المتابعة';

  @override
  String get profileConnect => 'إضافة';

  @override
  String get profileAbout => 'نبذة';

  @override
  String get profileDownloadCv => 'تنزيل السيرة الذاتية';

  @override
  String get profileExperience => 'الخبرات';

  @override
  String get profileEducation => 'التعليم';

  @override
  String get profileSkills => 'المهارات';

  @override
  String profileEndorsements(String count) {
    return '$count تزكية';
  }

  @override
  String get profileEndorse => '+ تزكية';

  @override
  String get editProfileTitle => 'تعديل الملف';

  @override
  String get editProfileFullName => 'الاسم الكامل';

  @override
  String get editProfileHeadline => 'المسمى المهني';

  @override
  String get editProfileIndustry => 'القطاع';

  @override
  String get editProfileLocation => 'الموقع';

  @override
  String get editProfileAbout => 'نبذة';

  @override
  String get editProfileOpenToWorkTitle => 'متاح للعمل';

  @override
  String get editProfileOpenToWorkSubtitle => 'أظهر لجهات التوظيف أنك متاح';

  @override
  String get editProfilePrivateTitle => 'ملف خاص';

  @override
  String get editProfilePrivateSubtitle =>
      'وافق على المتابعين قبل رؤية منشوراتك';

  @override
  String get networkTitle => 'شبكتي';

  @override
  String get networkRequests => 'طلبات التواصل';

  @override
  String get networkSuggestions => 'أشخاص قد تعرفهم';

  @override
  String networkMutual(String count) {
    return '$count معارف مشتركة';
  }

  @override
  String get networkAdd => '+ إضافة';

  @override
  String get searchHint => 'ابحث في رنق';

  @override
  String get searchTabTop => 'الأهم';

  @override
  String get searchTabPeople => 'أشخاص';

  @override
  String get searchTabJobs => 'وظائف';

  @override
  String get searchTabTags => 'وسوم';

  @override
  String get searchTrendingTags => 'الوسوم الرائجة';

  @override
  String get searchSectionPeople => 'أشخاص';

  @override
  String get searchNoResults => 'لا نتائج مطابقة لبحثك';

  @override
  String searchPostsCount(String count) {
    return '$count منشور';
  }

  @override
  String get notificationsTitle => 'الإشعارات';

  @override
  String get notificationsMarkAllRead => 'تعليم الكل كمقروء';

  @override
  String get notificationsNowConnected => 'أصبح على تواصل معك';

  @override
  String get messagesTitle => 'الرسائل';

  @override
  String get messagesSearchHint => 'بحث في الرسائل';

  @override
  String get messagesYouPrefix => 'أنت: ';

  @override
  String threadMembers(String count) {
    return '$count أعضاء';
  }

  @override
  String get threadInputHint => 'اكتب رسالة…';

  @override
  String get threadToday => 'اليوم';

  @override
  String get threadRead => 'تمت القراءة';

  @override
  String get threadJustNow => 'الآن';

  @override
  String get jobsTitle => 'الوظائف';

  @override
  String get jobsMyApplications => 'طلباتي';

  @override
  String get jobsSearchHint => 'المسمى أو الشركة أو الموقع';

  @override
  String get jobsFilterAll => 'الكل';

  @override
  String get jobsFilterRemote => 'عن بُعد';

  @override
  String get jobsFilterHybrid => 'هجين';

  @override
  String get jobsFilterOnsite => 'من المقر';

  @override
  String get jobsEmpty => 'لا توجد وظائف مطابقة للفلاتر';

  @override
  String get jobTypeFullTime => 'دوام كامل';

  @override
  String get jobTypePartTime => 'دوام جزئي';

  @override
  String get jobTypeContract => 'عقد';

  @override
  String get jobTypeInternship => 'تدريب';

  @override
  String jobPostedAgo(String time) {
    return 'قبل $time';
  }

  @override
  String jobApplicants(String count) {
    return '$count متقدماً';
  }

  @override
  String get jobApplied => 'تم التقديم';

  @override
  String get jobDetailTitle => 'تفاصيل الوظيفة';

  @override
  String get jobSalaryRange => 'نطاق الراتب';

  @override
  String get jobAboutSection => 'عن الوظيفة';

  @override
  String get jobRequirementsSection => 'ما نبحث عنه';

  @override
  String get jobSkillsSection => 'المهارات';

  @override
  String get jobApplyNow => 'قدّم الآن';

  @override
  String jobApplicationStatus(String status) {
    return 'الطلب: $status';
  }

  @override
  String get applyTitle => 'التقديم';

  @override
  String get applyResumeSection => 'سيرتك الذاتية';

  @override
  String applyResumeUploaded(String size) {
    return 'تم الرفع · $size';
  }

  @override
  String get applyCoverLetterSection => 'خطاب التقديم';

  @override
  String get applyCoverHint => 'أضف ملاحظة لفريق التوظيف…';

  @override
  String get applyReviewSection => 'مراجعة وإرسال';

  @override
  String get applyApplicantLabel => 'المتقدم';

  @override
  String get applyResumeLabel => 'السيرة الذاتية';

  @override
  String get applyNoCoverLetter => 'لم تتم إضافة خطاب تقديم.';

  @override
  String get applySubmit => 'إرسال الطلب';

  @override
  String get applyDoneTitle => 'تم إرسال طلبك!';

  @override
  String applyDoneBody(String title, String company) {
    return 'تم إرسال طلبك لوظيفة $title في $company. يمكنك متابعة حالته من صفحة طلباتي.';
  }

  @override
  String get myApplicationsTitle => 'طلباتي';

  @override
  String get myApplicationsEmpty => 'لم تقدّم على أي وظيفة بعد';

  @override
  String get applicationStepSubmitted => 'الإرسال';

  @override
  String get applicationStepReview => 'المراجعة';

  @override
  String get applicationStepShortlist => 'الاختيار';

  @override
  String get applicationStepInterview => 'المقابلة';

  @override
  String get applicationStepDecision => 'القرار';

  @override
  String get applicationStatusSubmitted => 'تم الإرسال';

  @override
  String get applicationStatusInReview => 'قيد المراجعة';

  @override
  String get applicationStatusShortlisted => 'القائمة المختصرة';

  @override
  String get applicationStatusInterview => 'مقابلة';

  @override
  String get applicationStatusAccepted => 'مقبول';

  @override
  String get applicationStatusRejected => 'مرفوض';

  @override
  String get dashboardGreeting => 'مساءً الخير';

  @override
  String get dashboardContinueLearning => 'أكمل التعلّم';

  @override
  String dashboardLectureProgress(String current, String total) {
    return 'المحاضرة $current من $total · نظري';
  }

  @override
  String get dashboardStatCourses => 'دورات نشطة';

  @override
  String get dashboardStatHours => 'ساعة تعلّم';

  @override
  String get dashboardStatCertificates => 'شهادات';

  @override
  String get dashboardSectionLearning => 'التعلّم';

  @override
  String get dashboardSectionServices => 'الخدمات';

  @override
  String get dashboardSectionTools => 'أدواتي';

  @override
  String dashboardNewBadge(String count) {
    return '$count جديد';
  }

  @override
  String get dashboardTheory => 'محاضرات نظرية';

  @override
  String get dashboardTheorySubtitle => 'دروس ومفاهيم أساسية';

  @override
  String get dashboardPractical => 'محاضرات عملية';

  @override
  String get dashboardPracticalSubtitle => 'تطبيقات وأمثلة عملية';

  @override
  String get dashboardTraining => 'تدريب وتطوير';

  @override
  String get dashboardTrainingSubtitle => 'برامج تطوير المهارات';

  @override
  String get dashboardEngy => 'المهندسة إنجي';

  @override
  String get dashboardEngySubtitle => 'مساعدتك الذكية للاستشارات';

  @override
  String get dashboardEngyBadge => 'AI';

  @override
  String get dashboardLegalRequest => 'طلب استشارة قانونية';

  @override
  String get dashboardLegalRequestSubtitle => 'خطوات حل النزاعات القانونية';

  @override
  String get dashboardLegalAffairs => 'الشؤون القانونية';

  @override
  String get dashboardLegalAffairsSubtitle => 'حقوق المهندس والقوانين';

  @override
  String get dashboardNotes => 'ملاحظاتي';

  @override
  String get dashboardNotesSubtitle => 'ملاحظاتك الشخصية';

  @override
  String get dashboardLibrary => 'المكتبة الهندسية';

  @override
  String get dashboardLibrarySubtitle => 'مراجع وأكواد ومواصفات';

  @override
  String dashboardOpening(String item) {
    return 'جارٍ فتح $item';
  }

  @override
  String get dashboardEngyGreeting => 'مرحباً، أنا إنجي — كيف أساعدك؟';

  @override
  String get authSignInTitle => 'تسجيل الدخول';

  @override
  String get authSignUpTitle => 'إنشاء حساب جديد';

  @override
  String get authUserName => 'اسم المستخدم';

  @override
  String get authUserNameHint => 'بالأحرف اللاتينية أو الأرقام';

  @override
  String get authPassword => 'كلمة المرور';

  @override
  String get authFullName => 'الاسم الكامل';

  @override
  String get authFullNameHint => 'كما تريد أن يظهر في ملفك';

  @override
  String get authPhone => 'رقم الهاتف';

  @override
  String get authAccountType => 'نوع الحساب';

  @override
  String get authAccountIndividual => 'فرد';

  @override
  String get authAccountCompany => 'شركة';

  @override
  String get authSubmitSignIn => 'دخول';

  @override
  String get authSubmitSignUp => 'إنشاء الحساب';

  @override
  String get authSwitchToSignUp => 'ليس لديك حساب؟ أنشئ حساباً';

  @override
  String get authSwitchToSignIn => 'لديك حساب بالفعل؟ سجّل الدخول';

  @override
  String get authRequiredField => 'هذا الحقل مطلوب';

  @override
  String get authPasswordTooShort => 'كلمة المرور ٦ أحرف على الأقل';

  @override
  String get authUserNameTooShort => 'اسم المستخدم ٣ أحرف على الأقل';

  @override
  String get authPhoneInvalid => 'أدخل رقم هاتف صحيح';

  @override
  String authAccountCreated(String name) {
    return 'تم إنشاء حسابك، أهلاً بك $name 🎉';
  }

  @override
  String get setupTitle => 'أكمل ملفك';

  @override
  String get setupSubtitle => 'عرّف الآخرين بنفسك — يمكنك تعديل كل شيء لاحقاً.';

  @override
  String get setupSubtitleCompany =>
      'عرّف الآخرين بشركتك — يمكنك تعديل كل شيء لاحقاً.';

  @override
  String get setupHeadline => 'المسمّى المهني';

  @override
  String get setupHeadlineHint => 'مهندس برمجيات في…';

  @override
  String get setupHeadlineHintCompany => 'ما الذي تقدّمه شركتك؟';

  @override
  String get setupAbout => 'نبذة';

  @override
  String get setupAboutHint => 'بضعة أسطر عن خبرتك واهتماماتك';

  @override
  String get setupAboutHintCompany => 'بضعة أسطر عن نشاط الشركة';

  @override
  String get setupLocation => 'الموقع';

  @override
  String get setupLocationHint => 'بغداد، العراق';

  @override
  String get setupIndustry => 'المجال';

  @override
  String get setupIndustryHint => 'التقنية، الهندسة، الرعاية الصحية…';

  @override
  String get setupWebsite => 'الموقع الإلكتروني';

  @override
  String get setupOpenToWork => 'متاح لفرص عمل';

  @override
  String get setupOpenToWorkSubtitle => 'يظهر شارة على ملفك';

  @override
  String get setupSave => 'متابعة';

  @override
  String get setupSkip => 'تخطٍّ الآن';

  @override
  String get setupSaved => 'تم حفظ ملفك 🎉';

  @override
  String get authGender => 'الجنس';

  @override
  String get authGenderMale => 'ذكر';

  @override
  String get authGenderFemale => 'أنثى';

  @override
  String get authPhoto => 'صورة الملف';

  @override
  String get authPhotoPick => 'اختر صورة';

  @override
  String get authPhotoChange => 'تغيير الصورة';

  @override
  String get authPhotoRemove => 'إزالة';

  @override
  String get authPhotoUploading => 'جارٍ رفع الصورة…';

  @override
  String get authGenderRequired => 'اختر الجنس';

  @override
  String get profileConnectSent => 'تم إرسال الطلب';

  @override
  String get profileConnectAccept => 'قبول الطلب';

  @override
  String get profileConnected => 'متصل';

  @override
  String get profileFollowRequested => 'بانتظار الموافقة';

  @override
  String get toastConnectRequestCancelled => 'تم سحب الطلب';

  @override
  String get toastConnectionRemoved => 'تمت إزالة الاتصال';

  @override
  String get toastConnectAccepted => 'تم قبول الطلب';

  @override
  String get networkAddSent => 'تم الإرسال';
}
