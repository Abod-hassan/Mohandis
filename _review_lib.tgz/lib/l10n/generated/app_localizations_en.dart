// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get appTitle => 'Rung';

  @override
  String get actionRetry => 'Try again';

  @override
  String get actionCancel => 'Cancel';

  @override
  String get actionSave => 'Save';

  @override
  String get actionDone => 'Done';

  @override
  String get actionContinue => 'Continue';

  @override
  String get actionSend => 'Send';

  @override
  String get actionAccept => 'Accept';

  @override
  String get actionIgnore => 'Ignore';

  @override
  String get actionChange => 'Change';

  @override
  String get comingSoon => 'Coming soon';

  @override
  String get optionalSuffix => '(optional)';

  @override
  String get genericError => 'Something went wrong. Please try again.';

  @override
  String get emptyTitle => 'Nothing here yet';

  @override
  String get themeToggleToDark => 'Switch to dark theme';

  @override
  String get themeToggleToLight => 'Switch to light theme';

  @override
  String get authHeroTitle => 'Where professional paths meet.';

  @override
  String get authHeroBody =>
      'Build your professional profile, grow your network, share your work, and find your next role — all in one calm, professional place.';

  @override
  String get authStatProfessionalsValue => '12M+';

  @override
  String get authStatProfessionalsLabel => 'professionals';

  @override
  String get authStatJobsValue => '240k';

  @override
  String get authStatJobsLabel => 'open roles';

  @override
  String get authStatTrustValue => '98%';

  @override
  String get authStatTrustLabel => 'trust score';

  @override
  String get authGetStarted => 'Get started';

  @override
  String get authSignIn => 'Sign in';

  @override
  String get authCreateAccount => 'Create account';

  @override
  String get authContinueWith => 'or continue with';

  @override
  String get authGoogle => 'Google';

  @override
  String get authApple => 'Apple';

  @override
  String get authTerms =>
      'By continuing you agree to Rung\'s Terms of Use and Privacy Policy';

  @override
  String authWelcomeBack(String name) {
    return 'Welcome back, $name 👋';
  }

  @override
  String get navHome => 'Home';

  @override
  String get navReels => 'Reels';

  @override
  String get navDashboard => 'My panel';

  @override
  String get navJobs => 'Jobs';

  @override
  String get navNetwork => 'Network';

  @override
  String get topBarSearchHint => 'Search people, jobs, or tags';

  @override
  String get feedYourStory => 'Your story';

  @override
  String get feedComposerHint => 'Share an update or idea…';

  @override
  String get feedCaughtUp => 'You\'re all caught up ✓';

  @override
  String feedRepostedBy(String name) {
    return '$name reposted';
  }

  @override
  String get postActionLike => 'Like';

  @override
  String get postActionComment => 'Comment';

  @override
  String get postActionRepost => 'Repost';

  @override
  String get postActionSave => 'Save';

  @override
  String postCommentsCount(String count) {
    return '$count comments';
  }

  @override
  String postRepostsCount(String count) {
    return '$count reposts';
  }

  @override
  String postLikesCount(String count) {
    return '$count likes';
  }

  @override
  String get postViewJob => 'View job and apply →';

  @override
  String get postDetailTitle => 'Post';

  @override
  String get postAddComment => 'Add a comment…';

  @override
  String get postReply => 'Reply';

  @override
  String postLikeWithCount(String count) {
    return 'Like · $count';
  }

  @override
  String get visibilityPublic => 'Public';

  @override
  String get visibilityFollowers => 'Followers';

  @override
  String get visibilityPrivate => 'Private';

  @override
  String get visibilityEveryoneLabel => 'Everyone';

  @override
  String get visibilityFollowersOnlyLabel => 'Followers only';

  @override
  String get visibilityOnlyMeLabel => 'Only me';

  @override
  String get composerTitle => 'New post';

  @override
  String get composerPublish => 'Post';

  @override
  String get composerHint => 'Share an update, an idea, or an opportunity…';

  @override
  String get toastSavedToItems => 'Saved to your items';

  @override
  String get toastReposted => 'Reposted to your followers';

  @override
  String get toastPosted => 'Post published ✓';

  @override
  String get toastSavedToReels => 'Saved to your reels';

  @override
  String get toastProfileUpdated => 'Profile updated ✓';

  @override
  String get toastApplicationSent => 'Application sent ✓';

  @override
  String toastConnectRequestSent(String name) {
    return 'Connection request sent to $name';
  }

  @override
  String toastConnected(String name) {
    return 'Connected with $name';
  }

  @override
  String toastFollowing(String name) {
    return 'Now following $name';
  }

  @override
  String get toastUnfollowed => 'Unfollowed';

  @override
  String storyReplyTo(String name) {
    return 'Reply to $name…';
  }

  @override
  String storyPostedAgo(String time) {
    return '$time ago';
  }

  @override
  String get reelsTitle => 'Reels';

  @override
  String get reelFollow => 'Follow';

  @override
  String get reelShare => 'Share';

  @override
  String reelPlays(String count) {
    return '$count views';
  }

  @override
  String get profileOpenToWork => 'Open to work';

  @override
  String get profileHiring => 'Hiring';

  @override
  String get profileConnections => 'connections';

  @override
  String get profileFollowers => 'followers';

  @override
  String get profileEdit => 'Edit profile';

  @override
  String get profileFollow => 'Follow';

  @override
  String get profileUnfollow => 'Unfollow';

  @override
  String get profileConnect => 'Connect';

  @override
  String get profileAbout => 'About';

  @override
  String get profileDownloadCv => 'Download résumé';

  @override
  String get profileExperience => 'Experience';

  @override
  String get profileEducation => 'Education';

  @override
  String get profileSkills => 'Skills';

  @override
  String profileEndorsements(String count) {
    return '$count endorsements';
  }

  @override
  String get profileEndorse => '+ Endorse';

  @override
  String get editProfileTitle => 'Edit profile';

  @override
  String get editProfileFullName => 'Full name';

  @override
  String get editProfileHeadline => 'Headline';

  @override
  String get editProfileIndustry => 'Industry';

  @override
  String get editProfileLocation => 'Location';

  @override
  String get editProfileAbout => 'About';

  @override
  String get editProfileOpenToWorkTitle => 'Open to work';

  @override
  String get editProfileOpenToWorkSubtitle =>
      'Show recruiters that you\'re available';

  @override
  String get editProfilePrivateTitle => 'Private profile';

  @override
  String get editProfilePrivateSubtitle =>
      'Approve followers before they see your posts';

  @override
  String get networkTitle => 'My network';

  @override
  String get networkRequests => 'Connection requests';

  @override
  String get networkSuggestions => 'People you may know';

  @override
  String networkMutual(String count) {
    return '$count mutual connections';
  }

  @override
  String get networkAdd => '+ Connect';

  @override
  String get searchHint => 'Search Rung';

  @override
  String get searchTabTop => 'Top';

  @override
  String get searchTabPeople => 'People';

  @override
  String get searchTabJobs => 'Jobs';

  @override
  String get searchTabTags => 'Tags';

  @override
  String get searchTrendingTags => 'Trending tags';

  @override
  String get searchSectionPeople => 'People';

  @override
  String get searchNoResults => 'No results match your search';

  @override
  String searchPostsCount(String count) {
    return '$count posts';
  }

  @override
  String get notificationsTitle => 'Notifications';

  @override
  String get notificationsMarkAllRead => 'Mark all as read';

  @override
  String get notificationsNowConnected => 'is now connected with you';

  @override
  String get messagesTitle => 'Messages';

  @override
  String get messagesSearchHint => 'Search messages';

  @override
  String get messagesYouPrefix => 'You: ';

  @override
  String threadMembers(String count) {
    return '$count members';
  }

  @override
  String get threadInputHint => 'Write a message…';

  @override
  String get threadToday => 'Today';

  @override
  String get threadRead => 'Read';

  @override
  String get threadJustNow => 'Now';

  @override
  String get jobsTitle => 'Jobs';

  @override
  String get jobsMyApplications => 'My applications';

  @override
  String get jobsSearchHint => 'Title, company, or location';

  @override
  String get jobsFilterAll => 'All';

  @override
  String get jobsFilterRemote => 'Remote';

  @override
  String get jobsFilterHybrid => 'Hybrid';

  @override
  String get jobsFilterOnsite => 'On-site';

  @override
  String get jobsEmpty => 'No jobs match these filters';

  @override
  String get jobTypeFullTime => 'Full-time';

  @override
  String get jobTypePartTime => 'Part-time';

  @override
  String get jobTypeContract => 'Contract';

  @override
  String get jobTypeInternship => 'Internship';

  @override
  String jobPostedAgo(String time) {
    return '$time ago';
  }

  @override
  String jobApplicants(String count) {
    return '$count applicants';
  }

  @override
  String get jobApplied => 'Applied';

  @override
  String get jobDetailTitle => 'Job details';

  @override
  String get jobSalaryRange => 'Salary range';

  @override
  String get jobAboutSection => 'About the role';

  @override
  String get jobRequirementsSection => 'What we\'re looking for';

  @override
  String get jobSkillsSection => 'Skills';

  @override
  String get jobApplyNow => 'Apply now';

  @override
  String jobApplicationStatus(String status) {
    return 'Application: $status';
  }

  @override
  String get applyTitle => 'Apply';

  @override
  String get applyResumeSection => 'Your résumé';

  @override
  String applyResumeUploaded(String size) {
    return 'Uploaded · $size';
  }

  @override
  String get applyCoverLetterSection => 'Cover letter';

  @override
  String get applyCoverHint => 'Add a note for the hiring team…';

  @override
  String get applyReviewSection => 'Review and submit';

  @override
  String get applyApplicantLabel => 'Applicant';

  @override
  String get applyResumeLabel => 'Résumé';

  @override
  String get applyNoCoverLetter => 'No cover letter added.';

  @override
  String get applySubmit => 'Submit application';

  @override
  String get applyDoneTitle => 'Your application is in!';

  @override
  String applyDoneBody(String title, String company) {
    return 'Your application for $title at $company has been sent. Track its status from My applications.';
  }

  @override
  String get myApplicationsTitle => 'My applications';

  @override
  String get myApplicationsEmpty => 'You haven\'t applied to any job yet';

  @override
  String get applicationStepSubmitted => 'Submitted';

  @override
  String get applicationStepReview => 'Reviewed';

  @override
  String get applicationStepShortlist => 'Shortlisted';

  @override
  String get applicationStepInterview => 'Interview';

  @override
  String get applicationStepDecision => 'Decision';

  @override
  String get applicationStatusSubmitted => 'Submitted';

  @override
  String get applicationStatusInReview => 'In review';

  @override
  String get applicationStatusShortlisted => 'Shortlisted';

  @override
  String get applicationStatusInterview => 'Interview';

  @override
  String get applicationStatusAccepted => 'Accepted';

  @override
  String get applicationStatusRejected => 'Rejected';

  @override
  String get dashboardGreeting => 'Good evening';

  @override
  String get dashboardContinueLearning => 'Continue learning';

  @override
  String dashboardLectureProgress(String current, String total) {
    return 'Lecture $current of $total · theory';
  }

  @override
  String get dashboardStatCourses => 'active courses';

  @override
  String get dashboardStatHours => 'learning hours';

  @override
  String get dashboardStatCertificates => 'certificates';

  @override
  String get dashboardSectionLearning => 'Learning';

  @override
  String get dashboardSectionServices => 'Services';

  @override
  String get dashboardSectionTools => 'My tools';

  @override
  String dashboardNewBadge(String count) {
    return '$count new';
  }

  @override
  String get dashboardTheory => 'Theory lectures';

  @override
  String get dashboardTheorySubtitle => 'Core lessons and concepts';

  @override
  String get dashboardPractical => 'Practical lectures';

  @override
  String get dashboardPracticalSubtitle => 'Applications and worked examples';

  @override
  String get dashboardTraining => 'Training and development';

  @override
  String get dashboardTrainingSubtitle => 'Skill-development programmes';

  @override
  String get dashboardEngy => 'Engineer Engy';

  @override
  String get dashboardEngySubtitle => 'Your smart consulting assistant';

  @override
  String get dashboardEngyBadge => 'AI';

  @override
  String get dashboardLegalRequest => 'Request legal advice';

  @override
  String get dashboardLegalRequestSubtitle =>
      'Steps for resolving legal disputes';

  @override
  String get dashboardLegalAffairs => 'Legal affairs';

  @override
  String get dashboardLegalAffairsSubtitle =>
      'Engineers\' rights and regulations';

  @override
  String get dashboardNotes => 'My notes';

  @override
  String get dashboardNotesSubtitle => 'Your personal notes';

  @override
  String get dashboardLibrary => 'Engineering library';

  @override
  String get dashboardLibrarySubtitle =>
      'References, codes, and specifications';

  @override
  String dashboardOpening(String item) {
    return 'Opening $item';
  }

  @override
  String get dashboardEngyGreeting => 'Hi, I\'m Engy — how can I help?';

  @override
  String get authSignInTitle => 'Sign in';

  @override
  String get authSignUpTitle => 'Create an account';

  @override
  String get authUserName => 'Username';

  @override
  String get authUserNameHint => 'Latin letters or numbers';

  @override
  String get authPassword => 'Password';

  @override
  String get authFullName => 'Full name';

  @override
  String get authFullNameHint => 'As it should appear on your profile';

  @override
  String get authPhone => 'Phone number';

  @override
  String get authAccountType => 'Account type';

  @override
  String get authAccountIndividual => 'Individual';

  @override
  String get authAccountCompany => 'Company';

  @override
  String get authSubmitSignIn => 'Sign in';

  @override
  String get authSubmitSignUp => 'Create account';

  @override
  String get authSwitchToSignUp => 'No account yet? Create one';

  @override
  String get authSwitchToSignIn => 'Already have an account? Sign in';

  @override
  String get authRequiredField => 'This field is required';

  @override
  String get authPasswordTooShort => 'Password must be at least 6 characters';

  @override
  String get authUserNameTooShort => 'Username must be at least 3 characters';

  @override
  String get authPhoneInvalid => 'Enter a valid phone number';

  @override
  String authAccountCreated(String name) {
    return 'Account created — welcome, $name 🎉';
  }

  @override
  String get setupTitle => 'Complete your profile';

  @override
  String get setupSubtitle =>
      'Introduce yourself — you can change any of this later.';

  @override
  String get setupSubtitleCompany =>
      'Introduce your company — you can change any of this later.';

  @override
  String get setupHeadline => 'Headline';

  @override
  String get setupHeadlineHint => 'Software engineer at…';

  @override
  String get setupHeadlineHintCompany => 'What does your company do?';

  @override
  String get setupAbout => 'About';

  @override
  String get setupAboutHint =>
      'A few lines about your experience and interests';

  @override
  String get setupAboutHintCompany => 'A few lines about what the company does';

  @override
  String get setupLocation => 'Location';

  @override
  String get setupLocationHint => 'Baghdad, Iraq';

  @override
  String get setupIndustry => 'Industry';

  @override
  String get setupIndustryHint => 'Technology, engineering, healthcare…';

  @override
  String get setupWebsite => 'Website';

  @override
  String get setupOpenToWork => 'Open to work';

  @override
  String get setupOpenToWorkSubtitle => 'Shows a badge on your profile';

  @override
  String get setupSave => 'Continue';

  @override
  String get setupSkip => 'Skip for now';

  @override
  String get setupSaved => 'Your profile is saved 🎉';

  @override
  String get authGender => 'Gender';

  @override
  String get authGenderMale => 'Male';

  @override
  String get authGenderFemale => 'Female';

  @override
  String get authPhoto => 'Profile photo';

  @override
  String get authPhotoPick => 'Pick a photo';

  @override
  String get authPhotoChange => 'Change photo';

  @override
  String get authPhotoRemove => 'Remove';

  @override
  String get authPhotoUploading => 'Uploading photo…';

  @override
  String get authGenderRequired => 'Choose a gender';

  @override
  String get profileConnectSent => 'Request sent';

  @override
  String get profileConnectAccept => 'Accept request';

  @override
  String get profileConnected => 'Connected';

  @override
  String get profileFollowRequested => 'Requested';

  @override
  String get toastConnectRequestCancelled => 'Request withdrawn';

  @override
  String get toastConnectionRemoved => 'Connection removed';

  @override
  String get toastConnectAccepted => 'Request accepted';

  @override
  String get networkAddSent => 'Sent';
}
