import '../bootstrap.dart';
import '../core/config/app_config.dart';
import '../core/config/bunny_storage_config.dart';
import '../core/config/environment.dart';

/// Dev runs against a locally-hosted API.
///
/// `useMockData: false` is what puts the app on real repositories — with it
/// true, `bootstrap` applies `mockOverrides()` and every wired endpoint is
/// bypassed, however correct the repository is.
///
/// **Base URL.** The iOS simulator shares the Mac's network stack, so
/// `localhost` reaches the host process directly. Two things follow from that:
///
///   * The port is the ASP.NET **https** profile from the host's
///     `launchSettings.json` — check it there if requests don't land.
///   * The dev certificate is not in the simulator's trust store even after
///     `dotnet dev-certs https --trust`, so `ApiClient` accepts it for loopback
///     hosts in debug dev builds only. Plain `http://localhost:<port>` works
///     too — `Info.plist` allows local networking.
///
/// Other targets: Android emulator → `http://10.0.2.2:<port>`; a physical
/// device → the Mac's LAN IP, with the host bound to `0.0.0.0` rather than
/// `localhost`.
Future<void> main() => bootstrap(
      AppConfig(
        environment: Environment.dev,
        appName: 'مهندس (Dev)',
        apiBaseUrl: 'https://localhost:7199',
        enableLogging: true,
        useMockData: false,
        // Fill these in from Bunny → Storage → FTP & API Access. `zone` is the
        // storage zone name, `accessKey` its read-WRITE password, and `host`
        // the region endpoint (bare `storage.bunnycdn.com` only for
        // Falkenstein — otherwise `ny.`, `la.`, `sg.`, `syd.`, `uk.`, `se.`,
        // `br.`, `jh.`). Until the key is replaced the photo control stays
        // hidden and registration simply sends no imageUrl.
        bunnyStorage: const BunnyStorageConfig(
          zone: '',
          accessKey: 'REPLACE_WITH_BUNNY_STORAGE_PASSWORD',
          host: 'storage.bunnycdn.com',
          folder: 'avatars',
        ),
      ),
    );
